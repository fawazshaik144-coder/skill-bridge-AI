/**
 * SkillBridge AI - Interactive Frontend Logic
 * Supports:
 * 1. Signature Feature: Job Readiness Simulator ("What If I Improve?")
 * 2. Assessment Quiz Navigation & Selection
 * 3. AI Job Parser Preview
 * 4. Resume Upload Enhancement
 */

document.addEventListener('DOMContentLoaded', () => {
    initQuizInteractions();
    initSimulator();
    initAIJobParser();
});

// =============================================================================
// 1. QUIZ OPTION SELECTOR
// =============================================================================
function initQuizInteractions() {
    const quizOptions = document.querySelectorAll('.quiz-option');
    quizOptions.forEach(option => {
        option.addEventListener('click', function () {
            const radio = this.querySelector('input[type="radio"]');
            if (radio) {
                radio.checked = true;
                const parentGroup = this.closest('.quiz-question-card');
                if (parentGroup) {
                    parentGroup.querySelectorAll('.quiz-option').forEach(opt => opt.classList.remove('selected'));
                }
                this.classList.add('selected');
            }
        });
    });
}

// =============================================================================
// 2. SIGNATURE FEATURE: JOB READINESS SIMULATOR ("What If I Improve?")
// =============================================================================
function initSimulator() {
    const simContainer = document.getElementById('readiness-simulator');
    if (!simContainer) return;

    const jobId = simContainer.dataset.jobId;
    const initialMatch = parseInt(simContainer.dataset.initialMatch || 72, 10);
    const sliders = simContainer.querySelectorAll('.sim-slider');
    const projectedDisplay = document.getElementById('projected-match-display');
    const projectedCircle = document.getElementById('projected-gauge-circle');
    const deltaBadge = document.getElementById('match-delta-badge');
    const explanationText = document.getElementById('sim-explanation-text');

    // Parse weights and base requirements from data attributes
    function recalculate() {
        const simulatedScores = {};
        sliders.forEach(slider => {
            const skillName = slider.dataset.skill;
            const val = parseInt(slider.value, 10);
            simulatedScores[skillName] = val;
            
            // Update individual label
            const labelVal = document.getElementById(`val-${slider.id}`);
            if (labelVal) {
                labelVal.textContent = val;
            }
        });

        // Fast API call to calculate exact projected match
        fetch('/api/simulate-match', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                job_id: jobId,
                simulated_scores: simulatedScores
            })
        })
        .then(res => res.json())
        .then(data => {
            if (data && data.match_score !== undefined) {
                const newScore = data.match_score;
                if (projectedDisplay) {
                    projectedDisplay.textContent = `${newScore}%`;
                }
                if (projectedCircle) {
                    const radius = 70;
                    const circumference = 2 * Math.PI * radius; // ~439.82
                    const offset = circumference - (newScore / 100) * circumference;
                    projectedCircle.style.strokeDashoffset = offset;
                }
                if (deltaBadge) {
                    const diff = newScore - initialMatch;
                    if (diff > 0) {
                        deltaBadge.className = 'badge bg-success text-white px-3 py-2 rounded-pill fs-6';
                        deltaBadge.innerHTML = `<i class="bi bi-arrow-up-right me-1"></i> +${diff}% Improvement Projected`;
                    } else if (diff === 0) {
                        deltaBadge.className = 'badge bg-secondary text-white px-3 py-2 rounded-pill fs-6';
                        deltaBadge.innerHTML = `Baseline Match (${newScore}%)`;
                    } else {
                        deltaBadge.className = 'badge bg-warning text-dark px-3 py-2 rounded-pill fs-6';
                        deltaBadge.innerHTML = `${diff}% Projected`;
                    }
                }
                if (explanationText && data.ai_explanation) {
                    explanationText.textContent = data.ai_explanation;
                }
            }
        })
        .catch(err => {
            console.error('Simulation error:', err);
        });
    }

    sliders.forEach(slider => {
        slider.addEventListener('input', recalculate);
    });

    // Run once on load to sync initial state
    recalculate();
}

// =============================================================================
// 3. AI JOB DESCRIPTION PARSER (Employer Job Creation)
// =============================================================================
function initAIJobParser() {
    const parseBtn = document.getElementById('ai-parse-btn');
    const descInput = document.getElementById('job-description-input');
    const titleInput = document.getElementById('job-title-input');
    const skillsTableBody = document.getElementById('skills-table-body');
    const parseStatus = document.getElementById('ai-parse-status');

    if (!parseBtn || !descInput || !skillsTableBody) return;

    parseBtn.addEventListener('click', () => {
        const text = descInput.value.trim();
        const title = titleInput ? titleInput.value.trim() : 'Software Role';

        if (!text) {
            alert('Please enter or paste a job description first.');
            return;
        }

        if (parseStatus) {
            parseStatus.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>AI is extracting capability requirements...';
            parseStatus.classList.remove('d-none');
        }
        parseBtn.disabled = true;

        fetch('/api/parse-job-description', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ description: text, title: title })
        })
        .then(res => res.json())
        .then(data => {
            if (parseStatus) parseStatus.classList.add('d-none');
            parseBtn.disabled = false;

            if (data && data.skills && data.skills.length > 0) {
                skillsTableBody.innerHTML = '';
                data.skills.forEach(skill => {
                    addSkillRow(skill.name, skill.required_score, skill.weight);
                });
            }
        })
        .catch(err => {
            console.error('Job parsing error:', err);
            if (parseStatus) parseStatus.classList.add('d-none');
            parseBtn.disabled = false;
        });
    });

    const addManualRowBtn = document.getElementById('add-manual-skill-btn');
    if (addManualRowBtn) {
        addManualRowBtn.addEventListener('click', () => {
            addSkillRow('New Skill', 60, 1.2);
        });
    }

    function addSkillRow(name, score, weight) {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>
                <input type="text" name="skill_name" class="form-control form-control-sm" value="${name}" required>
            </td>
            <td>
                <input type="number" name="required_score" class="form-control form-control-sm" value="${score}" min="10" max="100" required>
            </td>
            <td>
                <select name="skill_weight" class="form-select form-select-sm">
                    <option value="1.0" ${weight <= 1.0 ? 'selected' : ''}>Standard (1.0x)</option>
                    <option value="1.2" ${weight > 1.0 && weight <= 1.3 ? 'selected' : ''}>Important (1.2x)</option>
                    <option value="1.5" ${weight > 1.3 && weight <= 1.6 ? 'selected' : ''}>High (1.5x)</option>
                    <option value="1.8" ${weight > 1.6 ? 'selected' : ''}>Critical (1.8x)</option>
                </select>
            </td>
            <td class="text-center">
                <button type="button" class="btn btn-sm btn-outline-danger" onclick="this.closest('tr').remove()">
                    <i class="bi bi-trash"></i>
                </button>
            </td>
        `;
        skillsTableBody.appendChild(tr);
    }
}
