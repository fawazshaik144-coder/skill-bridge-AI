import os
import unittest
import json
from app import app, db
from models import User, Skill, Job, JobSkill, Application
from services.ai_service import ai_service
from services.matching_service import matching_service
from seed_data import seed_database

class SkillBridgeTestCase(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.client = app.test_client()
        with app.app_context():
            db.create_all()
            seed_database()

    def test_01_seed_data_loaded(self):
        with app.app_context():
            cand = User.query.filter_by(email="demo.candidate@example.com").first()
            self.assertIsNotNone(cand, "Demo candidate should exist")
            self.assertTrue(cand.check_password("demo123"), "Password check for candidate")
            
            emp = User.query.filter_by(email="demo.employer@example.com").first()
            self.assertIsNotNone(emp, "Demo employer should exist")
            self.assertTrue(emp.check_password("demo123"), "Password check for employer")

            jobs = Job.query.all()
            self.assertGreaterEqual(len(jobs), 5, "At least 5 jobs should be seeded")

            demo_skills = cand.skills.all()
            self.assertGreaterEqual(len(demo_skills), 5, "Demo candidate should have at least 5 skills")
            print("[PASS] Test 01: Database & Seed Data Verification Passed")

    def test_02_ai_service_fallback(self):
        # Test resume extraction
        resume_sample = "Experienced in Python, Flask, SQL, REST APIs, Git. B.Tech Computer Science 2024."
        extracted = ai_service.extract_resume_skills(resume_sample)
        self.assertIn("skills", extracted)
        self.assertIn("education", extracted)
        self.assertTrue(len(extracted["skills"]) > 0)

        # Test assessment questions
        questions = ai_service.generate_assessment_questions("Python", "Intermediate")
        self.assertEqual(len(questions), 5, "Must generate exactly 5 questions")
        self.assertIn("options", questions[0])

        # Test grading
        answers = {"1": 1, "2": 1, "3": 1, "4": 1, "5": 1}
        grade_res = ai_service.evaluate_assessment("Python", questions, answers)
        self.assertGreaterEqual(grade_res["score"], 70)
        self.assertIn(grade_res["level"], ["Intermediate", "Advanced"])

        # Test job parser
        parsed_job = ai_service.parse_job_description("Looking for junior developer with Python, SQL, Git.")
        self.assertIn("skills", parsed_job)
        self.assertTrue(len(parsed_job["skills"]) > 0)

        # Test roadmap generator
        roadmap = ai_service.generate_personalized_roadmap(
            "Junior Backend Developer",
            [{"name": "Python", "score": 85}],
            [{"name": "REST API", "required": 60}],
            [{"name": "REST API", "required": 60, "candidate_score": 42}]
        )
        self.assertIn("steps", roadmap)
        self.assertEqual(len(roadmap["steps"]), 4)
        print("[PASS] Test 02: AI Service Fallback & Deterministic Output Passed")

    def test_03_matching_and_simulation(self):
        with app.app_context():
            cand = User.query.filter_by(email="demo.candidate@example.com").first()
            job = Job.query.filter_by(title="Junior Backend Developer").first()
            self.assertIsNotNone(job)

            # Calculate baseline match
            baseline = matching_service.calculate_job_match(cand, job)
            score = baseline["match_score"]
            print(f"  [Matching] Baseline Demo Candidate match: {score}%")
            self.assertTrue(68 <= score <= 76, f"Expected baseline around 71-72%, got {score}%")

            # Check identified gaps
            gap_names = [g["name"].lower() for g in baseline["skill_gaps"]]
            self.assertTrue("rest api" in gap_names or "git" in gap_names, "Should identify REST API or Git as gaps")

            # Simulate improvement (REST API 42 -> 65, Git 35 -> 55)
            simulated = {"rest api": 65, "git": 55}
            projected = matching_service.calculate_job_match(cand, job, simulated_skills=simulated)
            proj_score = projected["match_score"]
            print(f"  [Matching] Simulated (REST API 42->65, Git 35->55) projected match: {proj_score}%")
            self.assertTrue(86 <= proj_score <= 94, f"Expected projected match around 89-92%, got {proj_score}%")
            self.assertGreater(proj_score, score)
            print("[PASS] Test 03: Capability Matching & Simulator Recalculation Passed (71% -> 92%)")

    def test_04_routes_and_controllers(self):
        # Public index
        res = self.client.get('/')
        self.assertEqual(res.status_code, 200)

        # Login page
        res = self.client.get('/login')
        self.assertEqual(res.status_code, 200)

        # 1-Click Demo Candidate Login
        res = self.client.get('/demo-login/candidate', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Aditya Sen", res.data)
        self.assertIn(b"Job Readiness Score", res.data)

        # Candidate pages
        res = self.client.get('/candidate/skills')
        self.assertEqual(res.status_code, 200)

        res = self.client.get('/candidate/profile')
        self.assertEqual(res.status_code, 200)

        res = self.client.get('/candidate/jobs')
        self.assertEqual(res.status_code, 200)

        with app.app_context():
            job = Job.query.filter_by(title="Junior Backend Developer").first()
            job_id = job.id

        res = self.client.get(f'/candidate/jobs/{job_id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Capability Matrix Comparison", res.data)

        res = self.client.get(f'/candidate/roadmap/{job_id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Your Path to Job Readiness", res.data)

        res = self.client.get(f'/candidate/simulation/{job_id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Job Readiness Simulator", res.data)

        # Simulator AJAX API
        res = self.client.post('/api/simulate-match', json={
            "job_id": job_id,
            "simulated_scores": {"rest api": 65, "git": 55}
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertIn("match_score", data)
        self.assertGreaterEqual(data["match_score"], 86)

        # Switch to Demo Employer
        res = self.client.get('/demo-login/employer', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Hiring & Capability Pipeline", res.data)

        res = self.client.get('/employer/jobs/create')
        self.assertEqual(res.status_code, 200)

        res = self.client.get(f'/employer/jobs/{job_id}/candidates')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Ranked Candidates", res.data)

        with app.app_context():
            cand = User.query.filter_by(email="demo.candidate@example.com").first()
            cand_id = cand.id

        res = self.client.get(f'/employer/candidates/{cand_id}/job/{job_id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"AI Candidate Capability Summary", res.data)

        print("[PASS] Test 04: All Core Candidate & Employer Routes Verified")

if __name__ == '__main__':
    unittest.main()
