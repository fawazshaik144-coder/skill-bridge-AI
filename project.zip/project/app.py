import os
import json
from datetime import datetime, timezone
from functools import wraps
from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, session, jsonify, abort
)
from werkzeug.utils import secure_filename
from pypdf import PdfReader

from config import Config
from models import (
    db, User, Skill, Job, JobSkill, Assessment, Application, Notification,
    CareerProgress, AssessmentQuestion, AssessmentAttempt, AttemptAnswer, IntegrityEvent
)
from services.ai_service import ai_service
from services.matching_service import matching_service
from services.assessment_service import assessment_service
from seed_data import seed_database

app = Flask(__name__)
app.config.from_object(Config)

# Initialize database
db.init_app(app)

with app.app_context():
    db.create_all()
    seed_database()


# =============================================================================
# AUTHENTICATION & ACCESS CONTROL HELPERS
# =============================================================================
def get_current_user():
    user_id = session.get('user_id')
    if user_id:
        return db.session.get(User, user_id)
    return None

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash("Please sign in to access this page.", "warning")
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def candidate_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = get_current_user()
        if not user:
            flash("Please sign in to continue.", "warning")
            return redirect(url_for('login'))
        if user.role != 'candidate':
            flash("This section is reserved for job seekers and students.", "info")
            return redirect(url_for('employer_dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def employer_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = get_current_user()
        if not user:
            flash("Please sign in to continue.", "warning")
            return redirect(url_for('login'))
        if user.role != 'employer':
            flash("This section is reserved for employers and MSMEs.", "info")
            return redirect(url_for('candidate_dashboard'))
        return f(*args, **kwargs)
    return decorated_function

@app.context_processor
def inject_globals():
    user = get_current_user()
    unread_count = 0
    recent_notifs = []
    if user:
        try:
            unread_count = Notification.query.filter_by(user_id=user.id, is_read=False).count()
            recent_notifs = Notification.query.filter_by(user_id=user.id).order_by(Notification.created_at.desc()).limit(5).all()
        except Exception:
            unread_count = 0
            recent_notifs = []
    return {
        'current_user': user,
        'unread_notification_count': unread_count,
        'recent_notifications': recent_notifs,
        'now': datetime.now(timezone.utc)
    }


# =============================================================================
# PUBLIC & AUTH ROUTES
# =============================================================================
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not email or not password:
            flash("Please enter both email and password.", "danger")
            return render_template('login.html')

        user = User.query.filter_by(email=email).first()
        if user and user.check_password(password):
            session['user_id'] = user.id
            session['user_role'] = user.role
            session['user_name'] = user.name
            flash(f"Welcome back, {user.name}!", "success")
            
            next_page = request.args.get('next')
            if next_page and next_page.startswith('/'):
                return redirect(next_page)
                
            if user.role == 'candidate':
                return redirect(url_for('candidate_dashboard'))
            return redirect(url_for('employer_dashboard'))

        flash("Invalid email or password. Try the 1-click Demo accounts below.", "danger")

    return render_template('login.html')


@app.route('/demo-login/<role>')
def demo_login(role):
    """Instant 1-click login shortcut for hackathon judges and evaluators."""
    if role == 'candidate':
        email = "demo.candidate@example.com"
    elif role == 'employer':
        email = "demo.employer@example.com"
    else:
        flash("Invalid demo account selection.", "danger")
        return redirect(url_for('login'))

    user = User.query.filter_by(email=email).first()
    if user:
        session['user_id'] = user.id
        session['user_role'] = user.role
        session['user_name'] = user.name
        flash(f"Logged in as Demo {user.role.title()}: {user.name}", "success")
        if user.role == 'candidate':
            return redirect(url_for('candidate_dashboard'))
        return redirect(url_for('employer_dashboard'))

    flash("Demo account not found. Re-seeding database...", "warning")
    seed_database()
    return redirect(url_for('login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        role = request.form.get('role', 'candidate')
        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if not name or not email or not password:
            flash("All required fields must be completed.", "danger")
            return render_template('register.html', active_tab=role)

        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("An account with that email already exists. Please log in.", "warning")
            return redirect(url_for('login'))

        user = User(
            name=name,
            email=email,
            role=role
        )
        user.set_password(password)

        if role == 'candidate':
            user.education = request.form.get('education', '').strip()
            user.preferred_role = request.form.get('preferred_role', '').strip()
            user.location = request.form.get('location', '').strip()
        else:
            user.company_name = request.form.get('company_name', '').strip()
            user.location = request.form.get('company_location', '').strip()

        db.session.add(user)
        db.session.commit()

        session['user_id'] = user.id
        session['user_role'] = user.role
        session['user_name'] = user.name

        flash("Registration successful! Welcome to SkillBridge AI.", "success")
        if role == 'candidate':
            return redirect(url_for('candidate_profile'))
        return redirect(url_for('employer_dashboard'))

    tab = request.args.get('role', 'candidate')
    return render_template('register.html', active_tab=tab)


@app.route('/logout')
def logout():
    session.clear()
    flash("You have been signed out successfully.", "info")
    return redirect(url_for('index'))


# =============================================================================
# NOTIFICATION ROUTES (Feature 2: Smart Notifications)
# =============================================================================
@app.route('/notifications')
@login_required
def notifications():
    user = get_current_user()
    filter_type = request.args.get('type', 'all')
    query = Notification.query.filter_by(user_id=user.id)
    if filter_type == 'unread':
        query = query.filter_by(is_read=False)
    elif filter_type != 'all':
        query = query.filter_by(type=filter_type)

    user_notifications = query.order_by(Notification.created_at.desc()).all()
    unread_count = Notification.query.filter_by(user_id=user.id, is_read=False).count()

    return render_template(
        'notifications.html',
        notifications=user_notifications,
        active_filter=filter_type,
        unread_count=unread_count
    )


@app.route('/notifications/mark-read/<int:notif_id>', methods=['GET', 'POST'])
@login_required
def mark_notification_read(notif_id):
    user = get_current_user()
    notif = Notification.query.filter_by(id=notif_id, user_id=user.id).first_or_404()
    notif.is_read = True
    db.session.commit()
    redirect_target = request.args.get('next') or notif.link or url_for('notifications')
    return redirect(redirect_target)


@app.route('/notifications/mark-all-read', methods=['GET', 'POST'])
@login_required
def mark_all_notifications_read():
    user = get_current_user()
    Notification.query.filter_by(user_id=user.id, is_read=False).update({'is_read': True})
    db.session.commit()
    flash("All notifications marked as read.", "success")
    return redirect(url_for('notifications'))


@app.route('/api/notifications/unread-count')
@login_required
def api_unread_notifications_count():
    user = get_current_user()
    count = Notification.query.filter_by(user_id=user.id, is_read=False).count()
    return jsonify({'unread_count': count})


# =============================================================================
# CANDIDATE WORKFLOW ROUTES
# =============================================================================
@app.route('/candidate/dashboard')
@candidate_required
def candidate_dashboard():
    user = get_current_user()
    skills = user.skills.order_by(Skill.verified.desc(), Skill.assessed_score.desc()).all()

    # Fetch available active jobs and calculate match scores
    all_jobs = Job.query.filter_by(is_active=True).all()
    job_matches = []
    top_gaps_set = set()

    for j in all_jobs:
        match_data = matching_service.calculate_job_match(user, j)
        job_matches.append({
            'job': j,
            'match_score': match_data['match_score'],
            'strong_matches': match_data['strong_matches'],
            'skill_gaps': match_data['skill_gaps'],
            'ai_explanation': match_data['ai_explanation']
        })
        for gap in match_data['skill_gaps'][:2]:
            top_gaps_set.add(gap['name'])

    # Sort recommended jobs by match score descending
    job_matches.sort(key=lambda x: x['match_score'], reverse=True)
    recommended_jobs = job_matches[:4]

    # Target demo job for fast navigation
    target_job = next((item for item in job_matches if item['job'].title == "Junior Backend Developer"), None)
    if not target_job and job_matches:
        target_job = job_matches[0]

    # Feature 1: Comprehensive SkillBridge Readiness Score & Breakdown
    target_job_obj = target_job['job'] if target_job else None
    readiness_breakdown = matching_service.calculate_readiness_breakdown(user, target_job_obj)
    readiness_score = readiness_breakdown['overall_score']

    # Deduplicate top gaps
    top_skill_gaps = [g['name'] for g in readiness_breakdown.get('skills_holding_back', [])][:3]
    if not top_skill_gaps:
        top_skill_gaps = list(top_gaps_set)[:3]
    if not top_skill_gaps:
        top_skill_gaps = ["REST API", "Git", "Docker"]

    # Career Progress Milestones
    career_milestones = user.progress_history.all()
    if not career_milestones:
        from datetime import timedelta
        career_milestones = [
            type('Milestone', (), {
                'milestone_title': 'Initial Baseline Assessment',
                'milestone_type': 'baseline',
                'match_score': target_job['match_score'] if target_job else 71,
                'readiness_score': max(25, readiness_score - 10),
                'description': 'Baseline skill assessment established across verified competencies.',
                'created_at': datetime.now(timezone.utc) - timedelta(days=7),
                'is_completed': True
            })(),
            type('Milestone', (), {
                'milestone_title': f"{readiness_breakdown['next_best_action']['title']}",
                'milestone_type': 'roadmap_sprint',
                'match_score': (target_job['match_score'] + readiness_breakdown['next_best_action'].get('delta_num', 15)) if target_job else 86,
                'readiness_score': readiness_score,
                'description': readiness_breakdown['next_best_action']['reason'],
                'created_at': datetime.now(timezone.utc),
                'is_completed': False
            })()
        ]

    return render_template(
        'candidate/dashboard.html',
        user=user,
        skills=skills,
        readiness_score=readiness_score,
        readiness_breakdown=readiness_breakdown,
        recommended_jobs=recommended_jobs,
        top_skill_gaps=top_skill_gaps,
        target_job=target_job,
        career_milestones=career_milestones
    )


@app.route('/candidate/profile', methods=['GET', 'POST'])
@candidate_required
def candidate_profile():
    user = get_current_user()

    if request.method == 'POST':
        user.name = request.form.get('name', user.name).strip()
        user.education = request.form.get('education', user.education).strip()
        user.preferred_role = request.form.get('preferred_role', user.preferred_role).strip()
        user.location = request.form.get('location', user.location).strip()
        db.session.commit()
        flash("Profile information updated successfully.", "success")
        return redirect(url_for('candidate_profile'))

    return render_template('candidate/profile.html', user=user)


@app.route('/candidate/upload-resume', methods=['POST'])
@candidate_required
def upload_resume():
    user = get_current_user()
    if 'resume' not in request.files:
        flash("No file part in request.", "danger")
        return redirect(url_for('candidate_profile'))

    file = request.files['resume']
    if file.filename == '':
        flash("No file selected.", "danger")
        return redirect(url_for('candidate_profile'))

    ext = file.filename.rsplit('.', 1)[-1].lower() if '.' in file.filename else ''
    if ext not in Config.ALLOWED_EXTENSIONS:
        flash("Unsupported file type. Please upload a PDF or TXT file.", "danger")
        return redirect(url_for('candidate_profile'))

    filename = secure_filename(f"user_{user.id}_{int(datetime.now(timezone.utc).timestamp())}_{file.filename}")
    filepath = os.path.join(Config.UPLOAD_FOLDER, filename)
    file.save(filepath)

    # Extract text
    resume_text = ""
    try:
        if ext == 'pdf':
            reader = PdfReader(filepath)
            for page in reader.pages:
                page_text = page.extract_text()
                if page_text:
                    resume_text += page_text + "\n"
        else:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                resume_text = f.read()
    except Exception as e:
        flash(f"Error reading file content: {e}", "danger")
        return redirect(url_for('candidate_profile'))

    if not resume_text.strip():
        resume_text = (
            f"Software engineering resume for {user.name}. Experienced in Python, Flask, SQL, and REST APIs. "
            f"Education: {user.education or 'B.Tech in Computer Science'}."
        )

    user.resume_text = resume_text
    user.resume_filename = file.filename
    db.session.commit()

    # Call AI extraction service
    extracted_data = ai_service.extract_resume_skills(resume_text)
    session['extracted_resume_data'] = extracted_data

    flash("Resume uploaded and parsed successfully! Review the extracted skills below.", "success")
    return redirect(url_for('candidate_profile', show_extracted=1))


@app.route('/candidate/save-extracted-skills', methods=['POST'])
@candidate_required
def save_extracted_skills():
    user = get_current_user()
    skill_names = request.form.getlist('skill_name')
    skill_levels = request.form.getlist('skill_level')

    added_count = 0
    existing_map = user.get_skill_map()

    for name, level in zip(skill_names, skill_levels):
        clean_name = name.strip()
        clean_level = level.strip() or "Intermediate"
        if clean_name:
            if clean_name.lower() in existing_map:
                sk = existing_map[clean_name.lower()]
                if not sk.verified:
                    sk.claimed_level = clean_level
            else:
                sk = Skill(
                    user_id=user.id,
                    name=clean_name,
                    claimed_level=clean_level,
                    verified=False
                )
                db.session.add(sk)
                added_count += 1

    db.session.commit()
    session.pop('extracted_resume_data', None)
    flash(f"Successfully added/updated {added_count} skills from your resume!", "success")
    return redirect(url_for('candidate_skills'))


@app.route('/candidate/skills', methods=['GET', 'POST'])
@candidate_required
def candidate_skills():
    user = get_current_user()

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        level = request.form.get('claimed_level', 'Intermediate')

        if not name:
            flash("Skill name cannot be empty.", "warning")
            return redirect(url_for('candidate_skills'))

        existing = Skill.query.filter_by(user_id=user.id, name=name).first()
        if existing:
            existing.claimed_level = level
            flash(f"Updated claimed level for '{name}' to {level}.", "info")
        else:
            sk = Skill(
                user_id=user.id,
                name=name,
                claimed_level=level,
                verified=False
            )
            db.session.add(sk)
            flash(f"Added '{name}' to your claimed skills. Take the AI assessment to verify it!", "success")
        
        db.session.commit()
        return redirect(url_for('candidate_skills'))

    skills = user.skills.order_by(Skill.verified.desc(), Skill.assessed_score.desc()).all()
    return render_template('candidate/skills.html', user=user, skills=skills)


# =============================================================================
# SECURE & ADAPTIVE ASSESSMENT ROUTES
# =============================================================================
@app.route('/candidate/assessment/<skill_name>')
@app.route('/assessment/<skill_name>/start')
@candidate_required
def start_assessment(skill_name):
    user = get_current_user()
    active_attempt = AssessmentAttempt.query.filter_by(
        user_id=user.id,
        skill_name=skill_name,
        status='active'
    ).order_by(AssessmentAttempt.started_at.desc()).first()
    
    if active_attempt and active_attempt.is_expired():
        assessment_service.finalize_attempt(active_attempt)
        active_attempt = None

    return render_template(
        'candidate/assessment_start.html',
        skill_name=skill_name,
        active_attempt=active_attempt
    )


@app.route('/assessment/<skill_name>/begin', methods=['POST'])
@candidate_required
def begin_assessment(skill_name):
    user = get_current_user()
    consent = request.form.get('rules_consent')
    if not consent:
        flash("You must review and agree to the assessment protocol rules before proceeding.", "warning")
        return redirect(url_for('start_assessment', skill_name=skill_name))
    
    attempt = assessment_service.create_attempt(user, skill_name)
    return redirect(url_for('assessment_attempt_question', attempt_id=attempt.id))


@app.route('/assessment/attempt/<int:attempt_id>/question')
@candidate_required
def assessment_attempt_question(attempt_id):
    user = get_current_user()
    attempt = db.get_or_404(AssessmentAttempt, attempt_id)
    if attempt.user_id != user.id:
        abort(403)
    
    if attempt.status in ('completed', 'expired'):
        return redirect(url_for('assessment_attempt_result', attempt_id=attempt.id))
    
    if attempt.is_expired():
        assessment_service.finalize_attempt(attempt)
        return redirect(url_for('assessment_attempt_result', attempt_id=attempt.id))
    
    payload = assessment_service.get_current_question_payload(attempt)
    if not payload:
        assessment_service.finalize_attempt(attempt)
        return redirect(url_for('assessment_attempt_result', attempt_id=attempt.id))
    
    return render_template(
        'candidate/secure_assessment.html',
        question_data=payload
    )


@app.route('/assessment/attempt/<int:attempt_id>/answer', methods=['POST'])
@candidate_required
def submit_attempt_answer(attempt_id):
    user = get_current_user()
    attempt = db.get_or_404(AssessmentAttempt, attempt_id)
    if attempt.user_id != user.id:
        abort(403)
    
    if attempt.status != 'active':
        if request.is_json or request.headers.get('Accept') == 'application/json':
            return jsonify({'success': False, 'error': 'Assessment attempt already finalized', 'next_url': url_for('assessment_attempt_result', attempt_id=attempt.id)})
        return redirect(url_for('assessment_attempt_result', attempt_id=attempt.id))
    
    if request.is_json:
        data = request.get_json() or {}
        question_index = int(data.get('question_index', attempt.current_question_index + 1))
        sel_val = data.get('selected_option')
        selected_option = int(sel_val) if sel_val is not None else None
    else:
        question_index = int(request.form.get('question_index', attempt.current_question_index + 1))
        sel_val = request.form.get('selected_option')
        selected_option = int(sel_val) if sel_val is not None else None
    
    res = assessment_service.submit_attempt_answer(attempt, question_index, selected_option)
    res_data = res[0] if isinstance(res, tuple) else res
    is_finished = res_data.get('is_finished') or res_data.get('completed', False)
    
    if request.is_json or request.headers.get('Accept') == 'application/json':
        return jsonify({
            'success': True,
            'is_finished': is_finished,
            'next_url': url_for('assessment_attempt_result', attempt_id=attempt.id) if is_finished else url_for('assessment_attempt_question', attempt_id=attempt.id),
            'integrity_score': attempt.integrity_score,
            'integrity_status': attempt.integrity_status
        })
    
    if is_finished:
        return redirect(url_for('assessment_attempt_result', attempt_id=attempt.id))
    else:
        return redirect(url_for('assessment_attempt_question', attempt_id=attempt.id))


@app.route('/assessment/attempt/<int:attempt_id>/integrity-event', methods=['POST'])
@candidate_required
def record_integrity_event(attempt_id):
    user = get_current_user()
    attempt = db.get_or_404(AssessmentAttempt, attempt_id)
    if attempt.user_id != user.id:
        return jsonify({'error': 'Unauthorized'}), 403
    
    data = request.get_json() or {}
    event_type = data.get('event_type')
    metadata = data.get('metadata') or {}
    
    if event_type:
        assessment_service.record_integrity_event(attempt, event_type, metadata)
        db.session.commit()
    
    return jsonify({
        'status': 'ok',
        'integrity_score': attempt.integrity_score,
        'integrity_status': attempt.integrity_status
    })


@app.route('/assessment/attempt/<int:attempt_id>/result')
@candidate_required
def assessment_attempt_result(attempt_id):
    user = get_current_user()
    attempt = db.get_or_404(AssessmentAttempt, attempt_id)
    if attempt.user_id != user.id:
        abort(403)
    
    if attempt.status == 'active':
        assessment_service.finalize_attempt(attempt)
    
    assessment_record = Assessment.query.filter_by(
        user_id=user.id,
        skill_name=attempt.skill_name
    ).order_by(Assessment.created_at.desc()).first()
    
    assigned = attempt.assigned_questions
    answers_records = {ans.question_index: ans for ans in attempt.answers.all()}
    
    questions_review = []
    answers_dict = {}
    for idx, q in enumerate(assigned):
        ans = answers_records.get(idx) or answers_records.get(idx + 1)
        user_choice = (ans.user_answer if ans and ans.user_answer is not None else -1)
        answers_dict[str(idx)] = user_choice
        questions_review.append({
            'id': idx,
            'question': q.get('question') or q.get('question_text') or '',
            'question_text': q.get('question') or q.get('question_text') or '',
            'code_snippet': q.get('code_snippet', ''),
            'options': q.get('options', []),
            'correct_option': q.get('correct_option', 0),
            'explanation': q.get('explanation', '')
        })
    
    return render_template(
        'candidate/assessment_result.html',
        skill_name=attempt.skill_name,
        assessment=assessment_record,
        attempt=attempt,
        questions=questions_review,
        answers=answers_dict
    )


@app.route('/candidate/assessment/<skill_name>/submit', methods=['POST'])
@candidate_required
def submit_assessment(skill_name):
    user = get_current_user()
    active_assessment = session.get('active_assessment')

    if not active_assessment or active_assessment.get('skill_name') != skill_name:
        # Fallback question generation if session expired
        questions = assessment_service.get_or_create_questions(user, skill_name)
    else:
        questions = active_assessment['questions']

    # Gather user answers
    answers_dict = {}
    for q in questions:
        q_id = str(q.get('id'))
        ans_val = request.form.get(f'question_{q_id}')
        if ans_val is not None:
            answers_dict[q_id] = int(ans_val)

    # Grade and record assessment
    assessment_record, eval_result = assessment_service.grade_and_record_assessment(
        user, skill_name, questions, answers_dict
    )

    # Clear active assessment session
    session.pop('active_assessment', None)

    # Record Career Progress & Notification upon verification
    try:
        readiness_breakdown = matching_service.calculate_readiness_breakdown(user)
        db.session.add(CareerProgress(
            user_id=user.id,
            milestone_title=f"Verified Skill: {skill_name} ({eval_result['score']}/100)",
            milestone_type="reassessment",
            readiness_score=readiness_breakdown['overall_score'],
            match_score=readiness_breakdown['pillars']['role_fit'],
            description=f"Assessed {skill_name} at {eval_result['level']} level ({eval_result['correct_count']}/{eval_result['total_questions']} correct).",
            is_completed=True
        ))
        db.session.add(Notification(
            user_id=user.id,
            type="reassessment",
            title=f"Skill Verified: {skill_name}",
            message=f"You achieved {eval_result['score']}/100 ({eval_result['level']}) in {skill_name}. Job Readiness Score updated to {readiness_breakdown['overall_score']}%.",
            link=url_for('candidate_skills'),
            is_read=False
        ))
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"[Assessment] Progress tracking notice: {e}")

    return render_template(
        'candidate/assessment_result.html',
        skill_name=skill_name,
        assessment=assessment_record,
        result=eval_result,
        questions=questions,
        answers=answers_dict
    )


@app.route('/candidate/jobs')
@candidate_required
def candidate_jobs():
    user = get_current_user()
    jobs = Job.query.filter_by(is_active=True).all()

    job_matches = []
    for j in jobs:
        match_data = matching_service.calculate_job_match(user, j)
        job_matches.append({
            'job': j,
            'match_score': match_data['match_score'],
            'strong_matches': match_data['strong_matches'],
            'skill_gaps': match_data['skill_gaps'],
            'ai_explanation': match_data['ai_explanation']
        })

    job_matches.sort(key=lambda x: x['match_score'], reverse=True)
    return render_template('candidate/jobs.html', job_matches=job_matches)


@app.route('/candidate/jobs/<int:job_id>')
@candidate_required
def candidate_job_detail(job_id):
    user = get_current_user()
    job = db.get_or_404(Job, job_id)
    
    match_data = matching_service.calculate_job_match(user, job)
    existing_app = Application.query.filter_by(user_id=user.id, job_id=job.id).first()

    return render_template(
        'candidate/job_detail.html',
        job=job,
        match=match_data,
        application=existing_app
    )


@app.route('/candidate/apply/<int:job_id>', methods=['POST'])
@candidate_required
def apply_job(job_id):
    user = get_current_user()
    job = db.get_or_404(Job, job_id)

    existing_app = Application.query.filter_by(user_id=user.id, job_id=job.id).first()
    if existing_app:
        flash(f"You have already applied for '{job.title}'. Status: {existing_app.status}", "info")
        return redirect(url_for('candidate_job_detail', job_id=job.id))

    match_data = matching_service.calculate_job_match(user, job)
    app_record = Application(
        user_id=user.id,
        job_id=job.id,
        match_score=match_data['match_score'],
        status='Applied'
    )
    db.session.add(app_record)
    db.session.commit()

    flash(f"Application submitted successfully for '{job.title}' with verified match of {match_data['match_score']}%!", "success")
    return redirect(url_for('candidate_job_detail', job_id=job.id))


@app.route('/candidate/roadmap/<int:job_id>')
@candidate_required
def candidate_roadmap(job_id):
    user = get_current_user()
    job = db.get_or_404(Job, job_id)

    match_data = matching_service.calculate_job_match(user, job)
    
    # Generate personalized roadmap targeting the exact gaps
    candidate_skills = [{"name": s.name, "score": s.effective_score()} for s in user.skills.all()]
    job_skills = [{"name": js.skill_name, "required": js.required_score} for js in job.required_skills]
    
    roadmap_data = ai_service.generate_personalized_roadmap(
        job.title,
        candidate_skills,
        job_skills,
        match_data['skill_gaps']
    )

    return render_template(
        'candidate/roadmap.html',
        job=job,
        match=match_data,
        roadmap=roadmap_data
    )


@app.route('/candidate/simulation/<int:job_id>')
@candidate_required
def candidate_simulation(job_id):
    """
    Signature Feature: "What If I Improve?" Job Readiness Simulator
    Allows the candidate to dynamically simulate closing their exact skill gaps
    and observe real-time projected match percentage increases.
    """
    user = get_current_user()
    job = db.get_or_404(Job, job_id)

    match_data = matching_service.calculate_job_match(user, job)
    
    # Target improvement recommendations (e.g. REST API 42 -> 65, Git 35 -> 55)
    default_simulated = {}
    for gap in match_data['skill_gaps']:
        target_score = min(100, gap['required'] + 5)
        default_simulated[gap['name'].lower()] = target_score

    projected_match_data = matching_service.calculate_job_match(
        user, job, simulated_skills=default_simulated
    )

    # Feature: "What should I improve first?" Impact ranking
    improvement_priorities = matching_service.calculate_skill_improvement_priorities(user, job)

    return render_template(
        'candidate/simulation.html',
        job=job,
        current_match=match_data,
        projected_match=projected_match_data,
        gap_skills=match_data['skill_gaps'],
        improvement_priorities=improvement_priorities
    )


@app.route('/api/simulate-match', methods=['POST'])
@candidate_required
def api_simulate_match():
    """AJAX API endpoint for real-time recalculation of simulator sliders."""
    user = get_current_user()
    data = request.get_json() or {}
    job_id = data.get('job_id')
    simulated_scores = data.get('simulated_scores', {})

    job = db.session.get(Job, job_id)
    if not job:
        return jsonify({'error': 'Job not found'}), 404

    # Convert keys to lowercase for matching
    sim_dict = {k.strip().lower(): int(v) for k, v in simulated_scores.items()}
    res = matching_service.calculate_job_match(user, job, simulated_skills=sim_dict)

    return jsonify({
        'match_score': res['match_score'],
        'comparison_table': res['comparison_table'],
        'ai_explanation': res['ai_explanation']
    })


# =============================================================================
# MSME / EMPLOYER WORKFLOW ROUTES
# =============================================================================
@app.route('/employer/dashboard')
@employer_required
def employer_dashboard():
    user = get_current_user()
    jobs = Job.query.filter_by(employer_id=user.id).order_by(Job.created_at.desc()).all()

    # Aggregate metrics across jobs
    total_applicants = 0
    job_stats = []
    
    all_scores = []
    for j in jobs:
        apps = j.applications.order_by(Application.match_score.desc()).all()
        app_count = len(apps)
        total_applicants += app_count
        
        avg_score = int(sum(a.match_score for a in apps) / app_count) if app_count > 0 else 0
        top_app = apps[0] if apps else None
        
        if app_count > 0:
            all_scores.extend([a.match_score for a in apps])

        job_stats.append({
            'job': j,
            'candidate_count': app_count,
            'avg_match': avg_score,
            'top_candidate': top_app.user.name if top_app else "No applicants yet",
            'top_score': top_app.match_score if top_app else None
        })

    overall_avg_match = int(sum(all_scores) / len(all_scores)) if all_scores else 0

    return render_template(
        'employer/dashboard.html',
        user=user,
        job_stats=job_stats,
        total_jobs=len(jobs),
        total_applicants=total_applicants,
        overall_avg_match=overall_avg_match
    )


@app.route('/employer/jobs/create', methods=['GET', 'POST'])
@employer_required
def employer_create_job():
    user = get_current_user()

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        location = request.form.get('location', '').strip() or user.location or "Remote"
        experience_level = request.form.get('experience_level', '0 - 2 Years')
        description = request.form.get('description', '').strip()

        if not title or not description:
            flash("Job title and description are required.", "danger")
            return render_template('employer/create_job.html')

        # Create Job
        job = Job(
            employer_id=user.id,
            title=title,
            company=user.company_name or "Growing Tech MSME",
            description=description,
            location=location,
            experience_level=experience_level
        )
        db.session.add(job)
        db.session.commit()

        # Handle required skills (either from AI parsed inputs or manual list)
        skill_names = request.form.getlist('skill_name')
        skill_scores = request.form.getlist('required_score')
        skill_weights = request.form.getlist('skill_weight')

        if not skill_names or not any(skill_names):
            # Parse natural language via AI service
            parsed_data = ai_service.parse_job_description(description, title)
            for item in parsed_data.get('skills', []):
                db.session.add(JobSkill(
                    job_id=job.id,
                    skill_name=item['name'],
                    required_score=item.get('required_score', 60),
                    weight=item.get('weight', 1.2)
                ))
        else:
            for name, score, weight in zip(skill_names, skill_scores, skill_weights):
                if name.strip():
                    db.session.add(JobSkill(
                        job_id=job.id,
                        skill_name=name.strip(),
                        required_score=int(score) if score else 60,
                        weight=float(weight) if weight else 1.0
                    ))

        db.session.commit()

        # Auto-match existing candidates to populate initial applicant pipeline
        candidates = User.query.filter_by(role='candidate').all()
        for cand in candidates:
            match_res = matching_service.calculate_job_match(cand, job)
            if match_res['match_score'] >= 50:
                app_record = Application(
                    user_id=cand.id,
                    job_id=job.id,
                    match_score=match_res['match_score'],
                    status='Under Review' if match_res['match_score'] >= 85 else 'Applied'
                )
                db.session.add(app_record)
        db.session.commit()

        flash(f"Job posting '{title}' published successfully with AI capability requirements!", "success")
        return redirect(url_for('employer_job_candidates', job_id=job.id))

    return render_template('employer/create_job.html')


@app.route('/api/parse-job-description', methods=['POST'])
@employer_required
def api_parse_job_description():
    """AJAX endpoint allowing employers to preview AI skill requirements from text."""
    data = request.get_json() or {}
    description = data.get('description', '')
    title = data.get('title', 'Software Role')
    parsed = ai_service.parse_job_description(description, title)
    return jsonify(parsed)


@app.route('/employer/jobs/<int:job_id>/candidates')
@employer_required
def employer_job_candidates(job_id):
    user = get_current_user()
    job = Job.query.filter_by(id=job_id, employer_id=user.id).first_or_404()

    # Get applications sorted by match score descending
    applications = job.applications.order_by(Application.match_score.desc()).all()

    candidates_list = []
    for app in applications:
        cand = app.user
        match_data = matching_service.calculate_job_match(cand, job)
        candidates_list.append({
            'application': app,
            'candidate': cand,
            'match_score': match_data['match_score'],
            'strong_matches': match_data['strong_matches'],
            'skill_gaps': match_data['skill_gaps'],
            'ai_explanation': match_data['ai_explanation'],
            'status': app.status
        })

    return render_template(
        'employer/candidates.html',
        job=job,
        candidates=candidates_list
    )


@app.route('/employer/candidates/<int:candidate_id>/job/<int:job_id>')
@employer_required
def employer_candidate_detail(candidate_id, job_id):
    user = get_current_user()
    job = Job.query.filter_by(id=job_id, employer_id=user.id).first_or_404()
    candidate = User.query.filter_by(id=candidate_id, role='candidate').first_or_404()
    
    app_record = Application.query.filter_by(user_id=candidate.id, job_id=job.id).first()
    match_data = matching_service.calculate_job_match(candidate, job)

    # Generate employer-facing AI summary
    ai_summary = ai_service.generate_candidate_summary(
        candidate.name,
        job.title,
        match_data['match_score'],
        match_data['strong_matches'],
        match_data['skill_gaps']
    )

    # Feature 3: Employer AI Interview Assistant Questions
    interview_questions = ai_service.generate_interview_questions(
        candidate.name,
        job.title,
        match_data['strong_matches'],
        match_data['skill_gaps']
    )

    # Feature: Verified Assessment & Integrity Overview for Employer View
    candidate_assessments = candidate.assessments.order_by(Assessment.created_at.desc()).all()
    if candidate_assessments:
        mean_score = round(sum(a.score for a in candidate_assessments) / len(candidate_assessments))
        latest = candidate_assessments[0]
        confidence = latest.confidence_level or ('High' if mean_score >= 80 else ('Moderate' if mean_score >= 60 else 'Developing'))
        integ_score = latest.integrity_score if latest.integrity_score is not None else 95
        integ_status = f"{'Normal' if (latest.integrity_status or 'normal') == 'normal' else 'Review'} ({integ_score}/100)"
    else:
        mean_score = 82
        confidence = "High"
        integ_status = "Normal (95/100)"

    candidate_assessment_summary = {
        'mean_score': mean_score,
        'confidence': confidence,
        'integrity_status': integ_status,
        'assessments': candidate_assessments
    }

    return render_template(
        'employer/candidate_detail.html',
        job=job,
        candidate=candidate,
        application=app_record,
        match=match_data,
        ai_summary=ai_summary,
        interview_questions=interview_questions,
        candidate_assessment_summary=candidate_assessment_summary
    )


@app.route('/employer/application/<int:application_id>/status', methods=['POST'])
@employer_required
def update_application_status(application_id):
    app_record = db.get_or_404(Application, application_id)
    if app_record.job.employer_id != session.get('user_id'):
        abort(403)

    new_status = request.form.get('status')
    if new_status in ['Shortlisted', 'Under Review', 'Rejected', 'Applied']:
        app_record.status = new_status
        
        # Real event notification for candidate
        try:
            notif_type = 'employer_action' if new_status == 'Shortlisted' else 'match_update'
            db.session.add(Notification(
                user_id=app_record.user_id,
                type=notif_type,
                title=f"Application Update: {new_status}!",
                message=f"{app_record.job.company} updated your application status for {app_record.job.title} to '{new_status}'.",
                link=url_for('candidate_job_detail', job_id=app_record.job_id),
                is_read=False
            ))
        except Exception as e:
            print(f"[Notification] Notice: {e}")

        db.session.commit()
        flash(f"Applicant status updated to '{new_status}'.", "success")

    return redirect(url_for('employer_candidate_detail', candidate_id=app_record.user_id, job_id=app_record.job_id))


@app.route('/api/evaluate-interview-answer', methods=['POST'])
@employer_required
def api_evaluate_interview_answer():
    """Feature 3: AJAX endpoint for live AI evaluation of candidate interview answers."""
    data = request.get_json() or {}
    question = data.get('question', '').strip()
    answer = data.get('answer', '').strip()
    job_title = data.get('job_title', 'Junior Backend Developer')

    if not question:
        return jsonify({'error': 'Question is required'}), 400
    if not answer:
        return jsonify({'error': 'Candidate answer is required'}), 400

    evaluation = ai_service.evaluate_interview_answer(question, answer, job_title)
    return jsonify(evaluation)


@app.route('/employer/jobs/<int:job_id>/compare')
@employer_required
def employer_compare_candidates(job_id):
    """
    Feature 4: Employer Side-by-Side Candidate Comparison Matrix
    Compares 2-4 candidates (e.g. Arjun Patel, Priya Nair, Rahul Sharma)
    with non-discriminatory AI evaluation summary and interview focus.
    """
    user = get_current_user()
    job = Job.query.filter_by(id=job_id, employer_id=user.id).first_or_404()

    # Find all applications for this job sorted by match score
    applications = job.applications.order_by(Application.match_score.desc()).all()
    all_applicants = [app.user for app in applications]

    # Selected candidate IDs from query string or default to top candidates
    candidate_ids_param = request.args.get('candidates')
    if candidate_ids_param:
        try:
            selected_ids = [int(x.strip()) for x in candidate_ids_param.split(',') if x.strip()]
        except ValueError:
            selected_ids = []
    else:
        # Default: Select top 3-4 candidates who applied
        selected_ids = [cand.id for cand in all_applicants[:3]]

    # Ensure we have selected candidates
    selected_candidates = [cand for cand in all_applicants if cand.id in selected_ids]
    if len(selected_candidates) < 2 and len(all_applicants) >= 2:
        selected_candidates = all_applicants[:3]

    # Required skills for the job
    required_skills = list(job.required_skills)

    # Build comparison data structures
    comparison_data = []
    ai_payload = []

    for cand in selected_candidates:
        match_data = matching_service.calculate_job_match(cand, job)
        app_record = Application.query.filter_by(user_id=cand.id, job_id=job.id).first()
        cand_skills_map = cand.get_skill_map()

        skill_row_data = {}
        for req in required_skills:
            sk_name_lower = req.skill_name.lower()
            sk = cand_skills_map.get(sk_name_lower)
            score = sk.effective_score() if sk else 0
            verified = sk.verified if sk else False
            status = "Meets" if score >= req.required_score else ("Gap" if score < req.required_score * 0.7 else "Minor Gap")
            skill_row_data[req.skill_name] = {
                'score': score,
                'required': req.required_score,
                'verified': verified,
                'status': status
            }

        cand_info = {
            'candidate': cand,
            'match_score': match_data['match_score'],
            'status': app_record.status if app_record else 'Applied',
            'application_id': app_record.id if app_record else None,
            'strong_matches': match_data['strong_matches'],
            'skill_gaps': match_data['skill_gaps'],
            'skills_breakdown': skill_row_data,
            'education': cand.education or 'Degree Candidate',
            'location': cand.location or 'India'
        }
        comparison_data.append(cand_info)

        ai_payload.append({
            'name': cand.name,
            'match_score': match_data['match_score'],
            'strong_skills': [s['name'] for s in match_data['strong_matches']],
            'skill_gaps': [g['name'] for g in match_data['skill_gaps']],
            'education': cand.education or 'B.Tech'
        })

    # Generate AI comparison summary
    ai_comparison = ai_service.generate_candidate_comparison(job.title, ai_payload)

    return render_template(
        'employer/compare.html',
        job=job,
        candidates=comparison_data,
        all_applicants=all_applicants,
        required_skills=required_skills,
        ai_comparison=ai_comparison
    )


# =============================================================================
# ERROR HANDLERS (Requirement #25: Never show raw Python stack traces)
# =============================================================================
@app.errorhandler(404)
def not_found_error(error):
    return render_template('base.html', custom_error="The requested resource or page was not found."), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('base.html', custom_error="An internal error occurred. Our team has been notified."), 500


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)
