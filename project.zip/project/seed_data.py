from datetime import datetime, timedelta, timezone
from models import db, User, Skill, Job, JobSkill, Assessment, Application, Notification, CareerProgress
import json

def reset_demo_candidate():
    """Resets the demo candidate's skills and status to the canonical hackathon story state."""
    cand = User.query.filter_by(email="demo.candidate@example.com").first()
    if not cand:
        return
    # Remove existing skills for demo candidate
    Skill.query.filter_by(user_id=cand.id).delete()
    
    canonical_skills = [
        {"name": "Python", "claimed_level": "Intermediate", "assessed_score": 85, "assessed_level": "Intermediate", "verified": True},
        {"name": "SQL", "claimed_level": "Intermediate", "assessed_score": 78, "assessed_level": "Intermediate", "verified": True},
        {"name": "Flask", "claimed_level": "Intermediate", "assessed_score": 72, "assessed_level": "Intermediate", "verified": True},
        {"name": "REST API", "claimed_level": "Basic", "assessed_score": 42, "assessed_level": "Basic", "verified": True},
        {"name": "Git", "claimed_level": "Beginner", "assessed_score": 35, "assessed_level": "Beginner", "verified": True},
    ]
    for sk in canonical_skills:
        db.session.add(Skill(
            user_id=cand.id,
            name=sk["name"],
            claimed_level=sk["claimed_level"],
            assessed_score=sk["assessed_score"],
            assessed_level=sk["assessed_level"],
            verified=sk["verified"],
            last_assessed_at=datetime.now(timezone.utc) - timedelta(days=2)
        ))
    
    # Also reset application status for Junior Backend Developer to 'Applied'
    job = Job.query.filter_by(title="Junior Backend Developer").first()
    if job:
        app_record = Application.query.filter_by(user_id=cand.id, job_id=job.id).first()
        if app_record:
            app_record.status = "Applied"
            app_record.match_score = 71

    # Ensure Career Progress records exist for demo candidate
    CareerProgress.query.filter_by(user_id=cand.id).delete()
    p1 = CareerProgress(
        user_id=cand.id,
        milestone_title="Initial Baseline Assessment",
        milestone_type="baseline",
        readiness_score=68,
        match_score=71,
        description="Assessed Python (85), SQL (78), Flask (72), REST API (42), Git (35). Baseline match established at 71%.",
        is_completed=True,
        created_at=datetime.now(timezone.utc) - timedelta(days=14)
    )
    p2 = CareerProgress(
        user_id=cand.id,
        milestone_title="Targeted REST API Sprint",
        milestone_type="roadmap_sprint",
        readiness_score=76,
        match_score=82,
        description="Completed 2-week personalized roadmap sprint on RESTful architecture, HTTP idempotency, and JWT auth.",
        is_completed=True,
        created_at=datetime.now(timezone.utc) - timedelta(days=4)
    )
    p3 = CareerProgress(
        user_id=cand.id,
        milestone_title="Reassessment Verified: REST API & Git",
        milestone_type="reassessment",
        readiness_score=84,
        match_score=89,
        description="AI verified score increases in REST API (65) and Git (55). Overall job match elevated to 89%.",
        is_completed=True,
        created_at=datetime.now(timezone.utc) - timedelta(hours=8)
    )
    db.session.add_all([p1, p2, p3])

    # Ensure Notifications exist for demo candidate
    Notification.query.filter_by(user_id=cand.id).delete()
    notifs = [
        Notification(
            user_id=cand.id,
            type="match_update",
            title="New Role Matched: Junior Backend Developer",
            message="TechNova Solutions posted Junior Backend Developer with a 71% verified match to your skills.",
            link=f"/candidate/jobs/{job.id if job else 1}",
            is_read=False,
            created_at=datetime.now(timezone.utc) - timedelta(hours=2)
        ),
        Notification(
            user_id=cand.id,
            type="skill_gap",
            title="Skill Gap Alert: REST API (+15% Match Gain)",
            message="Your highest-ROI improvement is REST API. Raising your score from 42 to 60 boosts your match to 86%.",
            link=f"/candidate/simulation/{job.id if job else 1}",
            is_read=False,
            created_at=datetime.now(timezone.utc) - timedelta(hours=6)
        ),
        Notification(
            user_id=cand.id,
            type="roadmap",
            title="Personalized Roadmap Ready",
            message="A custom 4-step upskilling roadmap for Junior Backend Developer has been generated.",
            link=f"/candidate/roadmap/{job.id if job else 1}",
            is_read=False,
            created_at=datetime.now(timezone.utc) - timedelta(days=1)
        ),
        Notification(
            user_id=cand.id,
            type="employer_action",
            title="Application Status Updated",
            message="TechNova Solutions has reviewed your application for Junior Backend Developer.",
            link=f"/candidate/jobs/{job.id if job else 1}",
            is_read=True,
            created_at=datetime.now(timezone.utc) - timedelta(days=2)
        )
    ]
    db.session.add_all(notifs)
    
    db.session.commit()
    print("[Seed] Reset demo candidate to canonical hackathon state.")


def seed_database(force=False):
    """Seeds the database with rich, realistic hackathon demo data if empty or forced."""
    if force:
        db.drop_all()
        db.create_all()
    elif User.query.filter_by(email="demo.candidate@example.com").first():
        reset_demo_candidate()
        return

    print("[Seed] Initializing SkillBridge AI demo data...")

    # 1. CREATE EMPLOYERS
    employer_demo = User(
        name="Vikram Mehta",
        email="demo.employer@example.com",
        role="employer",
        company_name="TechNova Solutions",
        location="Chennai, India"
    )
    employer_demo.set_password("demo123")
    db.session.add(employer_demo)

    employer_2 = User(
        name="Pooja Kulkarni",
        email="pooja@apexcloud.io",
        role="employer",
        company_name="Apex Cloud Systems",
        location="Pune, India"
    )
    employer_2.set_password("demo123")
    db.session.add(employer_2)

    employer_3 = User(
        name="Dr. Sandeep Verma",
        email="sandeep@datapulse.ai",
        role="employer",
        company_name="DataPulse Analytics",
        location="Hyderabad, India"
    )
    employer_3.set_password("demo123")
    db.session.add(employer_3)

    db.session.commit()

    # 2. CREATE DEMO CANDIDATE (Core Hackathon Story Persona)
    candidate_demo = User(
        name="Aditya Sen",
        email="demo.candidate@example.com",
        role="candidate",
        education="B.Tech in Computer Science, 2024",
        preferred_role="Junior Backend Developer",
        location="Chennai, India",
        resume_text=(
            "ADITYA SEN - Aspiring Backend Developer\n"
            "Email: demo.candidate@example.com | Chennai, India\n\n"
            "EDUCATION:\n"
            "B.Tech in Computer Science & Engineering, 2020 - 2024 (CGPA: 8.4/10)\n\n"
            "TECHNICAL SKILLS:\n"
            "- Languages: Python, SQL, Basics of JavaScript\n"
            "- Frameworks & Web: Flask, Jinja2, HTML/CSS, Bootstrap\n"
            "- Tools & APIs: REST API concepts, Git version control, Postman, SQLite\n\n"
            "ACADEMIC PROJECTS:\n"
            "1. Inventory Management REST API - Built with Flask & SQLite. Implemented JWT authentication and CRUD endpoints.\n"
            "2. Student Performance Predictor - Applied regression in Python and built a simple interactive dashboard.\n\n"
            "WORK EXPERIENCE:\n"
            "Software Intern at Local Tech Hub (3 months) - Assisted in writing Python scripts and updating SQL database schemas."
        )
    )
    candidate_demo.set_password("demo123")
    db.session.add(candidate_demo)
    db.session.commit()

    # Candidate Demo Skills (Exact Hackathon Demo Profile)
    demo_skills = [
        {"name": "Python", "claimed_level": "Intermediate", "assessed_score": 85, "assessed_level": "Intermediate", "verified": True},
        {"name": "SQL", "claimed_level": "Intermediate", "assessed_score": 78, "assessed_level": "Intermediate", "verified": True},
        {"name": "Flask", "claimed_level": "Intermediate", "assessed_score": 72, "assessed_level": "Intermediate", "verified": True},
        {"name": "REST API", "claimed_level": "Basic", "assessed_score": 42, "assessed_level": "Basic", "verified": True},
        {"name": "Git", "claimed_level": "Beginner", "assessed_score": 35, "assessed_level": "Beginner", "verified": True},
    ]

    for sk_data in demo_skills:
        sk = Skill(
            user_id=candidate_demo.id,
            name=sk_data["name"],
            claimed_level=sk_data["claimed_level"],
            assessed_score=sk_data["assessed_score"],
            assessed_level=sk_data["assessed_level"],
            verified=sk_data["verified"],
            last_assessed_at=datetime.now(timezone.utc) - timedelta(days=2)
        )
        db.session.add(sk)

    # 3. CREATE ADDITIONAL CANDIDATES FOR RANKING
    candidates_data = [
        {
            "name": "Rahul Sharma",
            "email": "rahul.sharma@example.com",
            "education": "B.Tech CSE, NIT Trichy",
            "location": "Chennai, India",
            "preferred_role": "Backend Engineer",
            "skills": [
                ("Python", 92, "Advanced"), ("SQL", 88, "Advanced"),
                ("Flask", 85, "Advanced"), ("REST API", 82, "Intermediate"), ("Git", 80, "Intermediate")
            ]
        },
        {
            "name": "Arjun Patel",
            "email": "arjun.patel@example.com",
            "education": "B.E. Computer Engineering, Pune",
            "location": "Bangalore, India",
            "preferred_role": "Junior Backend Developer",
            "skills": [
                ("Python", 88, "Advanced"), ("SQL", 82, "Intermediate"),
                ("Flask", 80, "Intermediate"), ("REST API", 78, "Intermediate"), ("Git", 70, "Intermediate")
            ]
        },
        {
            "name": "Priya Nair",
            "email": "priya.nair@example.com",
            "education": "B.Tech CSE, BITS Pilani",
            "location": "Bangalore, India",
            "preferred_role": "Backend Engineer",
            "skills": [
                ("Python", 90, "Advanced"), ("SQL", 80, "Intermediate"),
                ("Flask", 78, "Intermediate"), ("REST API", 75, "Intermediate"), ("Git", 82, "Intermediate")
            ]
        },
        {
            "name": "Fawaz Ahmed",
            "email": "fawaz.ahmed@example.com",
            "education": "B.Tech IT, Anna University",
            "location": "Chennai, India",
            "preferred_role": "Python Developer",
            "skills": [
                ("Python", 85, "Intermediate"), ("SQL", 75, "Intermediate"),
                ("Flask", 75, "Intermediate"), ("REST API", 70, "Intermediate"), ("Git", 65, "Basic")
            ]
        },
        {
            "name": "Karthik Raman",
            "email": "karthik.raman@example.com",
            "education": "B.Sc Computer Science",
            "location": "Coimbatore, India",
            "preferred_role": "Software Trainee",
            "skills": [
                ("Python", 80, "Intermediate"), ("SQL", 70, "Intermediate"),
                ("Flask", 68, "Basic"), ("REST API", 55, "Basic"), ("Git", 45, "Basic")
            ]
        }
    ]

    extra_candidate_objs = []
    for cd in candidates_data:
        c_user = User(
            name=cd["name"],
            email=cd["email"],
            role="candidate",
            education=cd["education"],
            location=cd["location"],
            preferred_role=cd["preferred_role"]
        )
        c_user.set_password("demo123")
        db.session.add(c_user)
        db.session.commit()
        extra_candidate_objs.append((c_user, cd["skills"]))

        for s_name, s_score, s_lvl in cd["skills"]:
            sk = Skill(
                user_id=c_user.id,
                name=s_name,
                claimed_level=s_lvl,
                assessed_score=s_score,
                assessed_level=s_lvl,
                verified=True,
                last_assessed_at=datetime.now(timezone.utc) - timedelta(days=5)
            )
            db.session.add(sk)

    db.session.commit()

    # 4. CREATE JOBS
    # Target Demo Job: Junior Backend Developer at TechNova Solutions
    job_target = Job(
        employer_id=employer_demo.id,
        title="Junior Backend Developer",
        company="TechNova Solutions",
        location="Chennai",
        experience_level="0 - 2 Years",
        description=(
            "TechNova Solutions is a rapidly growing B2B SaaS startup. We are seeking a passionate "
            "Junior Backend Developer to help build scalable microservices and robust RESTful APIs. "
            "You will write modular Python code, manage relational SQL schemas, build Flask web services, "
            "and collaborate using Git in an Agile sprint environment."
        )
    )
    db.session.add(job_target)
    db.session.commit()

    target_requirements = [
        {"skill_name": "Python", "required_score": 70, "weight": 1.5},
        {"skill_name": "SQL", "required_score": 60, "weight": 1.2},
        {"skill_name": "Flask", "required_score": 60, "weight": 1.2},
        {"skill_name": "REST API", "required_score": 60, "weight": 1.8},
        {"skill_name": "Git", "required_score": 50, "weight": 1.5}
    ]
    for req in target_requirements:
        js = JobSkill(
            job_id=job_target.id,
            skill_name=req["skill_name"],
            required_score=req["required_score"],
            weight=req["weight"]
        )
        db.session.add(js)

    # 4 Additional Diverse Jobs
    job_2 = Job(
        employer_id=employer_3.id,
        title="Junior Python Developer",
        company="DataPulse Analytics",
        location="Hyderabad",
        experience_level="0 - 1 Year",
        description="Looking for an energetic Junior Python Developer to process high-volume tabular datasets, write clean automated ETL pipelines, and support our analytics dashboards."
    )
    db.session.add(job_2)
    db.session.commit()
    for req in [
        {"skill_name": "Python", "required_score": 75, "weight": 1.6},
        {"skill_name": "SQL", "required_score": 65, "weight": 1.4},
        {"skill_name": "Git", "required_score": 50, "weight": 1.0}
    ]:
        db.session.add(JobSkill(job_id=job_2.id, **req))

    job_3 = Job(
        employer_id=employer_2.id,
        title="Frontend Developer",
        company="Apex Cloud Systems",
        location="Pune",
        experience_level="1 - 3 Years",
        description="Build responsive, high-performance UI components for our FinTech dashboard using modern JavaScript, React, and RESTful API integration."
    )
    db.session.add(job_3)
    db.session.commit()
    for req in [
        {"skill_name": "JavaScript", "required_score": 75, "weight": 1.5},
        {"skill_name": "React", "required_score": 70, "weight": 1.5},
        {"skill_name": "REST API", "required_score": 60, "weight": 1.2},
        {"skill_name": "Git", "required_score": 55, "weight": 1.0}
    ]:
        db.session.add(JobSkill(job_id=job_3.id, **req))

    job_4 = Job(
        employer_id=employer_demo.id,
        title="Full Stack Developer",
        company="TechNova Solutions",
        location="Bangalore / Hybrid",
        experience_level="1 - 3 Years",
        description="Seeking an adaptable full-stack engineer proficient in Python/Flask backend and JavaScript frontend interfaces to spearhead new product features."
    )
    db.session.add(job_4)
    db.session.commit()
    for req in [
        {"skill_name": "Python", "required_score": 75, "weight": 1.4},
        {"skill_name": "Flask", "required_score": 65, "weight": 1.2},
        {"skill_name": "JavaScript", "required_score": 65, "weight": 1.2},
        {"skill_name": "SQL", "required_score": 65, "weight": 1.1},
        {"skill_name": "Git", "required_score": 55, "weight": 1.0}
    ]:
        db.session.add(JobSkill(job_id=job_4.id, **req))

    job_5 = Job(
        employer_id=employer_3.id,
        title="AI/ML Intern",
        company="DataPulse Analytics",
        location="Remote",
        experience_level="Fresher / Student",
        description="Exciting internship working on NLP and tabular machine learning models. Ideal for candidates with strong Python fundamentals, mathematical curiosity, and data analysis skills."
    )
    db.session.add(job_5)
    db.session.commit()
    for req in [
        {"skill_name": "Python", "required_score": 80, "weight": 1.6},
        {"skill_name": "SQL", "required_score": 60, "weight": 1.1},
        {"skill_name": "Machine Learning", "required_score": 65, "weight": 1.5},
        {"skill_name": "Git", "required_score": 50, "weight": 1.0}
    ]:
        db.session.add(JobSkill(job_id=job_5.id, **req))

    # 5. PRE-LINK APPLICATIONS FOR DEMO JOB (Junior Backend Developer)
    # This ensures the employer ranking screen immediately shows candidates sorted by match score!
    applications_data = [
        {"user": extra_candidate_objs[0][0], "match_score": 94, "status": "Shortlisted"},  # Rahul Sharma
        {"user": extra_candidate_objs[1][0], "match_score": 91, "status": "Under Review"},  # Arjun Patel
        {"user": extra_candidate_objs[2][0], "match_score": 88, "status": "Under Review"},  # Priya Nair
        {"user": extra_candidate_objs[3][0], "match_score": 87, "status": "Under Review"},  # Fawaz Ahmed
        {"user": extra_candidate_objs[4][0], "match_score": 79, "status": "Applied"},       # Karthik Raman
        {"user": candidate_demo, "match_score": 72, "status": "Applied"}                   # Aditya Sen
    ]

    for app_info in applications_data:
        app = Application(
            user_id=app_info["user"].id,
            job_id=job_target.id,
            match_score=app_info["match_score"],
            status=app_info["status"],
            created_at=datetime.now(timezone.utc) - timedelta(hours=12)
        )
        db.session.add(app)

    # 6. SEED NOTIFICATIONS FOR DEMO EMPLOYER
    emp_notifs = [
        Notification(
            user_id=employer_demo.id,
            type="employer_action",
            title="Candidate Pipeline Ready: Junior Backend Developer",
            message="6 candidates evaluated and ranked by explainable capability match. Top match: Rahul Sharma (94%).",
            link=f"/employer/jobs/{job_target.id}/candidates",
            is_read=False,
            created_at=datetime.now(timezone.utc) - timedelta(hours=1)
        ),
        Notification(
            user_id=employer_demo.id,
            type="match_update",
            title="Shortlist Decision Confirmed",
            message="Rahul Sharma has been marked as Shortlisted for Junior Backend Developer.",
            link=f"/employer/jobs/{job_target.id}/candidates",
            is_read=True,
            created_at=datetime.now(timezone.utc) - timedelta(hours=5)
        ),
        Notification(
            user_id=employer_demo.id,
            type="reassessment",
            title="Candidate Capability Update",
            message="Candidate Aditya Sen has verified improved skill proficiency in REST API.",
            link=f"/employer/candidates/{candidate_demo.id}/job/{job_target.id}",
            is_read=False,
            created_at=datetime.now(timezone.utc) - timedelta(hours=9)
        )
    ]
    db.session.add_all(emp_notifs)

    db.session.commit()
    print("[Seed] Successfully seeded SkillBridge AI demo data!")


if __name__ == "__main__":
    from app import app
    with app.app_context():
        db.create_all()
        seed_database()
