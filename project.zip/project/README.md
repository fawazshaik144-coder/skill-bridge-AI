# SkillBridge AI 🚀
> **Prove your skills. Find your fit. Become job-ready.**

SkillBridge AI is an AI-powered capability-to-employment workforce platform connecting skilled youth and students with MSMEs and growing startups.

---

## 🎯 The Core Paradigm: Continuous Capability Loop

Traditional recruitment is a broken keyword lottery:
```
Resume ➔ Keyword Filter ➔ "You aren't qualified" (Rejection without explanation)
```

**SkillBridge AI replaces this with a continuous, explainable capability loop:**
```
Claimed Skills
      ↓
AI Skill Assessment (5 questions: MCQ, code output, debug, scenarios)
      ↓
Assessed / Verified Capability Profile (0 - 100 score + level brackets)
      ↓
AI Job Matching (Explainable weighted scoring)
      ↓
Explainable Skill Gaps ("Why you match" vs "What you're missing")
      ↓
Personalized Upskilling Roadmap (4 actionable milestones targeting exact gaps)
      ↓
⭐ "What If I Improve?" Job Readiness Simulator (Interactive dynamic sliders)
      ↓
Skill Reassessment & Verified Profile Boost (e.g. 72% ➔ 89%)
      ↓
MSME Hiring & Shortlisting (Direct capability-ranked applicant pipeline)
```

---

## 🔑 Demo Credentials (Pre-Seeded & Ready)

The database automatically initializes and seeds on first launch:

| Persona | Email | Password | Role / Highlight |
| :--- | :--- | :--- | :--- |
| **Demo Candidate** | `demo.candidate@example.com` | `demo123` | Aditya Sen (Python 85, SQL 78, Flask 72, REST API 42, Git 35) |
| **Demo MSME Employer** | `demo.employer@example.com` | `demo123` | Vikram Mehta (TechNova Solutions - Junior Backend Developer) |

> 💡 **Hackathon 1-Click Fast Track**: The top notification bar and login page include **1-Click Demo Login** buttons to immediately test both candidate and employer workflows without typing credentials!

---

## 🛠️ Tech Stack & Architecture

- **Backend**: Python 3.12, Flask 3.0, Flask-SQLAlchemy 3.1, Werkzeug (PBKDF2 SHA-256 password hashing)
- **Database**: SQLite (`instance/skillbridge.db`) with automatic table creation and demo seeding
- **AI Engine**: Centralized in `services/ai_service.py`
  - Supports live **OpenAI API** (`OPENAI_API_KEY` in `.env`)
  - **Graceful Fallback Mode**: If the API key is not provided or unreachable, it seamlessly provides realistic deterministic mock data for resume parsing, assessment generation, grading, job requirement parsing, and roadmaps. The app **never crashes or displays missing key errors**.
- **Frontend**: HTML5, CSS3, JavaScript (ES6+), Bootstrap 5.3, Bootstrap Icons, custom modern SaaS dark-navy and violet visual identity.
- **Resume Processing**: `pypdf` for parsing PDF uploads, plus UTF-8 text fallback.

---

## 📂 Project Structure

```
skillbridge/
│
├── app.py                     # Flask application factory and all route controllers
├── config.py                  # App configuration, SQLite DB path, upload limits
├── models.py                  # SQLAlchemy models (User, Skill, Job, JobSkill, Assessment, Application)
├── seed_data.py               # Auto-seeder with 5 candidates, 5 jobs, 3 MSMEs, applications
├── requirements.txt           # Python dependencies
├── .env.example               # Environment variables template
├── .env                       # Active environment file
├── test_app.py                # Automated unit and integration test suite
├── test_e2e_flow.py           # End-to-end 12-step verification script
│
├── services/
│   ├── __init__.py
│   ├── ai_service.py          # Centralized LLM connector + robust fallback engine
│   ├── matching_service.py    # Weighted capability matching & simulation math
│   └── assessment_service.py  # Assessment generation, grading, and skill verification
│
├── templates/
│   ├── base.html              # Modern responsive navbar, flash alerts, footer
│   ├── index.html             # High-converting SaaS landing page with capability loop
│   ├── login.html             # Login form with 1-click Demo shortcuts
│   ├── register.html          # Candidate & MSME registration
│   │
│   ├── candidate/
│   │   ├── dashboard.html     # Circular readiness gauge, skills breakdown, recommended jobs
│   │   ├── profile.html       # Resume upload (PDF/TXT) with AI skill extraction preview
│   │   ├── skills.html        # Skill inventory (claimed vs verified) & assessment launch
│   │   ├── assessment.html    # 5-question interactive test with timer & code snippets
│   │   ├── assessment_result.html # Score (0-100), level bracket, strengths & growth areas
│   │   ├── jobs.html          # Job matches with capability tags and match percentages
│   │   ├── job_detail.html    # Side-by-side skill matrix, "Why you match" / "What's missing"
│   │   ├── roadmap.html       # 4-step personalized AI learning path targeting exact gaps
│   │   └── simulation.html    # ⭐ Signature Feature: "What If I Improve?" Simulator
│   │
│   └── employer/
│       ├── dashboard.html     # Active jobs, applicant counts, average pipeline match
│       ├── create_job.html    # Natural-language job description AI parser + manual editor
│       ├── candidates.html    # Candidates ranked strictly by explainable capability fit
│       └── candidate_detail.html # Candidate matrix, AI executive summary, Shortlist/Reject
│
├── static/
│   ├── css/
│   │   └── style.css          # Modern dark-navy & violet SaaS styling, cards, gauges
│   └── js/
│       └── main.js            # Real-time simulator math, quiz controls, AI job parser
│
└── uploads/                   # Secure storage for uploaded candidate resumes
```

---

## 🚀 Quick Setup & How to Run

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Environment Configuration (Optional)
A default `.env` file is already provided. If you want to test with live OpenAI:
```ini
OPENAI_API_KEY=your_openai_api_key_here
OPENAI_MODEL=gpt-4o-mini
```
*(If left blank, the app runs smoothly in realistic fallback mode).*

### 3. Run the Application
```bash
python app.py
```
Open your browser at:
👉 **`http://127.0.0.1:5000`**

The database and demo accounts are **seeded automatically** on first launch!

---

## 🧪 Verification & Automated Tests

Run the test suites at any time:
```bash
python test_app.py
python test_e2e_flow.py
```

Both tests verify:
- Database models and relationships
- Seed data loading and credentials
- AI service fallback mode output
- Explainable matching formula & simulation progression
- All 12 end-to-end user workflows
