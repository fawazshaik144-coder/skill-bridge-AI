from datetime import datetime, timezone
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import synonym
from werkzeug.security import generate_password_hash, check_password_hash
import json

def get_utc_now():
    return datetime.now(timezone.utc)

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(30), nullable=False, default='candidate')  # 'candidate' or 'employer'
    
    # Candidate specific profile fields
    education = db.Column(db.String(200), nullable=True)
    location = db.Column(db.String(120), nullable=True)
    preferred_role = db.Column(db.String(120), nullable=True)
    resume_text = db.Column(db.Text, nullable=True)
    resume_filename = db.Column(db.String(255), nullable=True)
    
    # Employer specific fields
    company_name = db.Column(db.String(150), nullable=True)
    
    created_at = db.Column(db.DateTime, default=get_utc_now)

    # Relationships
    skills = db.relationship('Skill', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    assessments = db.relationship('Assessment', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    applications = db.relationship('Application', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    jobs = db.relationship('Job', backref='employer', lazy='dynamic', cascade='all, delete-orphan')
    notifications = db.relationship('Notification', backref='user', lazy='dynamic', cascade='all, delete-orphan', order_by='desc(Notification.created_at)')
    progress_history = db.relationship('CareerProgress', backref='user', lazy='dynamic', cascade='all, delete-orphan', order_by='asc(CareerProgress.created_at)')
    assessment_attempts = db.relationship('AssessmentAttempt', backref='user', lazy='dynamic', cascade='all, delete-orphan', order_by='desc(AssessmentAttempt.created_at)')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def get_skill_map(self):
        """Returns a dict mapping skill_name.lower() to Skill object"""
        return {s.name.strip().lower(): s for s in self.skills.all()}

    def __repr__(self):
        return f"<User {self.email} ({self.role})>"


class Skill(db.Model):
    __tablename__ = 'skills'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    claimed_level = db.Column(db.String(50), default='Intermediate')  # Beginner, Basic, Intermediate, Advanced
    assessed_score = db.Column(db.Integer, default=0)                # 0 - 100
    assessed_level = db.Column(db.String(50), nullable=True)          # Beginner, Basic, Intermediate, Advanced
    verified = db.Column(db.Boolean, default=False)                   # True if AI assessed
    last_assessed_at = db.Column(db.DateTime, nullable=True)

    def effective_score(self):
        """Returns assessed score if verified, or a conservative estimate based on claimed level"""
        if self.verified and self.assessed_score > 0:
            return self.assessed_score
        # Conservative claimed score mapping
        mapping = {'Beginner': 35, 'Basic': 55, 'Intermediate': 70, 'Advanced': 85}
        return mapping.get(self.claimed_level, 50)

    def __repr__(self):
        return f"<Skill {self.name}: {self.assessed_score if self.verified else self.claimed_level}>"


class Job(db.Model):
    __tablename__ = 'jobs'

    id = db.Column(db.Integer, primary_key=True)
    employer_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    title = db.Column(db.String(150), nullable=False)
    company = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    location = db.Column(db.String(120), nullable=False)
    experience_level = db.Column(db.String(80), default='Entry Level / Junior')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=get_utc_now)

    # Relationships
    required_skills = db.relationship('JobSkill', backref='job', lazy='joined', cascade='all, delete-orphan')
    applications = db.relationship('Application', backref='job', lazy='dynamic', cascade='all, delete-orphan')

    def __repr__(self):
        return f"<Job {self.title} at {self.company}>"


class JobSkill(db.Model):
    __tablename__ = 'job_skills'

    id = db.Column(db.Integer, primary_key=True)
    job_id = db.Column(db.Integer, db.ForeignKey('jobs.id'), nullable=False, index=True)
    skill_name = db.Column(db.String(100), nullable=False)
    required_score = db.Column(db.Integer, default=60)  # 0 - 100
    weight = db.Column(db.Float, default=1.0)           # 1.0 = standard, 1.5 = high, 2.0 = critical

    def __repr__(self):
        return f"<JobSkill {self.skill_name} req={self.required_score} w={self.weight}>"


class Assessment(db.Model):
    __tablename__ = 'assessments'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    skill = db.Column(db.String(100), nullable=False)
    skill_name = synonym('skill')
    score = db.Column(db.Integer, nullable=False)       # 0 - 100
    level = db.Column(db.String(50), nullable=False)     # Beginner, Basic, Intermediate, Advanced
    questions_json = db.Column(db.Text, nullable=False)  # JSON serialized questions
    answers_json = db.Column(db.Text, nullable=True)    # JSON serialized candidate answers
    strong_areas = db.Column(db.Text, nullable=True)    # JSON list of strong areas
    weak_areas = db.Column(db.Text, nullable=True)      # JSON list of improvement areas
    integrity_score = db.Column(db.Integer, default=100) # 0 - 100
    integrity_status = db.Column(db.String(30), default='normal') # 'normal', 'review'
    confidence_level = db.Column(db.String(30), default='High')   # 'High', 'Moderate', 'Developing'
    adaptive_path_json = db.Column(db.Text, default='[]')
    created_at = db.Column(db.DateTime, default=get_utc_now)

    @property
    def adaptive_path(self):
        try:
            return json.loads(self.adaptive_path_json) if self.adaptive_path_json else []
        except Exception:
            return []

    @property
    def questions(self):
        try:
            return json.loads(self.questions_json)
        except Exception:
            return []

    @property
    def answers(self):
        try:
            return json.loads(self.answers_json) if self.answers_json else {}
        except Exception:
            return {}

    @property
    def strong_areas_list(self):
        try:
            return json.loads(self.strong_areas) if self.strong_areas else []
        except Exception:
            return []

    @property
    def weak_areas_list(self):
        try:
            return json.loads(self.weak_areas) if self.weak_areas else []
        except Exception:
            return []


class Application(db.Model):
    __tablename__ = 'applications'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    job_id = db.Column(db.Integer, db.ForeignKey('jobs.id'), nullable=False, index=True)
    match_score = db.Column(db.Integer, nullable=False)  # calculated match percentage at apply time
    status = db.Column(db.String(50), default='Applied') # Applied, Under Review, Shortlisted, Rejected
    created_at = db.Column(db.DateTime, default=get_utc_now)

    def __repr__(self):
        return f"<Application user={self.user_id} job={self.job_id} score={self.match_score}>"


class Notification(db.Model):
    __tablename__ = 'notifications'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    type = db.Column(db.String(50), nullable=False, default='info')  # 'match_update', 'skill_gap', 'roadmap', 'reassessment', 'employer_action'
    title = db.Column(db.String(150), nullable=False)
    message = db.Column(db.Text, nullable=False)
    link = db.Column(db.String(255), nullable=True)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=get_utc_now)

    def __repr__(self):
        return f"<Notification {self.id} user={self.user_id} title='{self.title}'>"


class CareerProgress(db.Model):
    __tablename__ = 'career_progress'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    milestone_title = db.Column(db.String(150), nullable=False)
    milestone_type = db.Column(db.String(50), default='assessment')  # 'baseline', 'roadmap_sprint', 'reassessment', 'shortlisted'
    readiness_score = db.Column(db.Integer, nullable=False)
    match_score = db.Column(db.Integer, nullable=False)
    description = db.Column(db.Text, nullable=True)
    is_completed = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=get_utc_now)

    def __repr__(self):
        return f"<CareerProgress {self.id} user={self.user_id} score={self.readiness_score}>"


class AssessmentQuestion(db.Model):
    __tablename__ = 'assessment_questions'

    id = db.Column(db.Integer, primary_key=True)
    skill_name = db.Column(db.String(100), nullable=False, index=True)
    question_text = db.Column(db.Text, nullable=False)
    question_type = db.Column(db.String(50), default='scenario')  # 'scenario', 'mcq', 'debugging', 'conceptual'
    difficulty = db.Column(db.String(20), default='medium')       # 'easy', 'medium', 'hard'
    category = db.Column(db.String(100), nullable=True)
    code_snippet = db.Column(db.Text, nullable=True)
    options_json = db.Column(db.Text, nullable=False)             # JSON list of options
    correct_answer = db.Column(db.Integer, nullable=False)        # 0-indexed integer
    explanation = db.Column(db.Text, nullable=True)
    evaluation_rubric = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=get_utc_now)

    @property
    def options(self):
        try:
            return json.loads(self.options_json) if self.options_json else []
        except Exception:
            return []

    def __repr__(self):
        return f"<AssessmentQuestion {self.id} skill={self.skill_name} diff={self.difficulty}>"


class AssessmentAttempt(db.Model):
    __tablename__ = 'assessment_attempts'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    skill_name = db.Column(db.String(100), nullable=False)
    assessment_id = db.Column(db.Integer, db.ForeignKey('assessments.id'), nullable=True)
    started_at = db.Column(db.DateTime, default=get_utc_now)
    expires_at = db.Column(db.DateTime, nullable=False)
    completed_at = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(30), default='active')           # 'active', 'completed', 'expired', 'invalidated'
    score = db.Column(db.Integer, nullable=True)                  # 0 - 100
    integrity_score = db.Column(db.Integer, default=100)          # 0 - 100
    integrity_status = db.Column(db.String(30), default='normal') # 'normal', 'review'
    current_question_index = db.Column(db.Integer, default=0)     # 0 to 4
    current_question_started_at = db.Column(db.DateTime, default=get_utc_now)
    question_time_limit = db.Column(db.Integer, default=60)       # 60s per question
    adaptive_path_json = db.Column(db.Text, default='[]')         # e.g. ["medium", "hard", "hard", "medium", "hard"]
    assigned_questions_json = db.Column(db.Text, default='[]')    # assigned question list
    created_at = db.Column(db.DateTime, default=get_utc_now)

    # Relationships
    answers = db.relationship('AttemptAnswer', backref='attempt', lazy='dynamic', cascade='all, delete-orphan', order_by='AttemptAnswer.question_index.asc()')
    integrity_events = db.relationship('IntegrityEvent', backref='attempt', lazy='dynamic', cascade='all, delete-orphan', order_by='IntegrityEvent.timestamp.desc()')

    @property
    def adaptive_path(self):
        try:
            return json.loads(self.adaptive_path_json) if self.adaptive_path_json else []
        except Exception:
            return []

    @property
    def assigned_questions(self):
        try:
            return json.loads(self.assigned_questions_json) if self.assigned_questions_json else []
        except Exception:
            return []

    @property
    def current_difficulty(self):
        path = self.adaptive_path
        if path:
            return path[-1]
        return "medium"

    def is_expired(self):
        if self.status in ('completed', 'expired', 'invalidated'):
            return True
        now = datetime.now(timezone.utc)
        if self.expires_at:
            exp = self.expires_at
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            return now > exp
        return False

    @property
    def confidence_level(self):
        if self.score is None:
            return "Pending"
        if self.score >= 80:
            return "High"
        elif self.score >= 60:
            return "Moderate"
        else:
            return "Developing"

    def __repr__(self):
        return f"<AssessmentAttempt {self.id} user={self.user_id} skill={self.skill_name} status={self.status}>"


class AttemptAnswer(db.Model):
    __tablename__ = 'attempt_answers'

    id = db.Column(db.Integer, primary_key=True)
    attempt_id = db.Column(db.Integer, db.ForeignKey('assessment_attempts.id'), nullable=False, index=True)
    question_id = db.Column(db.Integer, nullable=False)
    question_index = db.Column(db.Integer, nullable=False)
    user_answer = db.Column(db.Integer, nullable=True)            # selected option index
    is_correct = db.Column(db.Boolean, default=False)
    difficulty = db.Column(db.String(20), default='medium')
    time_taken_seconds = db.Column(db.Integer, default=0)
    answered_at = db.Column(db.DateTime, default=get_utc_now)

    @property
    def selected_option(self):
        return self.user_answer

    def __repr__(self):
        return f"<AttemptAnswer {self.id} attempt={self.attempt_id} q_idx={self.question_index} correct={self.is_correct}>"


class IntegrityEvent(db.Model):
    __tablename__ = 'integrity_events'

    id = db.Column(db.Integer, primary_key=True)
    attempt_id = db.Column(db.Integer, db.ForeignKey('assessment_attempts.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    event_type = db.Column(db.String(50), nullable=False)         # 'TAB_SWITCH', 'FULLSCREEN_EXIT', etc.
    timestamp = db.Column(db.DateTime, default=get_utc_now)
    metadata_json = db.Column(db.Text, nullable=True)

    @property
    def event_metadata(self):
        try:
            return json.loads(self.metadata_json) if self.metadata_json else {}
        except Exception:
            return {}

    def __repr__(self):
        return f"<IntegrityEvent {self.id} attempt={self.attempt_id} type={self.event_type}>"
