"""
generate_skillbridge_ppt.py
Generates the official, refined 16:9 widescreen PowerPoint presentation for SkillBridge AI
for the 6-Hour National-Level Youth Hackathon.
File generated: SkillBridge_AI_Hackathon_Presentation_Final_v2.pptx
"""

import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor

# Output filename
OUTPUT_PPTX = "SkillBridge_AI_Hackathon_Presentation_Final_v2.pptx"

# -------------------------------------------------------------
# Color Palette (Matching SkillBridge AI Web Application)
# -------------------------------------------------------------
COLOR_BG_DARK = RGBColor(15, 23, 42)         # #0f172a Deep Slate Navy
COLOR_CARD_BG = RGBColor(30, 41, 59)         # #1e293b Dark Slate Card
COLOR_CARD_ALT = RGBColor(24, 33, 47)        # #18212f Darker Alt Card
COLOR_CARD_BORDER = RGBColor(51, 65, 85)     # #334155 Subtle Slate Border

COLOR_PRIMARY = RGBColor(79, 70, 229)        # #4f46e5 Indigo Primary
COLOR_PRIMARY_LIGHT = RGBColor(99, 102, 241) # #6366f1 Indigo Accent
COLOR_EMERALD = RGBColor(16, 185, 129)       # #10b981 Emerald Verified
COLOR_AMBER = RGBColor(245, 158, 11)         # #f59e0b Amber Warning
COLOR_CYAN = RGBColor(14, 165, 233)          # #0ea5e9 Info Cyan
COLOR_ROSE = RGBColor(244, 63, 94)           # #f43f5e Rose / Gap

COLOR_TEXT_WHITE = RGBColor(255, 255, 255)
COLOR_TEXT_LIGHT = RGBColor(241, 245, 249)   # #f1f5f9
COLOR_TEXT_MUTED = RGBColor(148, 163, 184)   # #94a3b8
COLOR_TEXT_DIM = RGBColor(100, 116, 139)     # #64748b

FONT_HEADING = "Segoe UI"
FONT_BODY = "Segoe UI"
FONT_MONO = "Consolas"


def apply_slide_bg(slide):
    """Sets a solid dark navy background for the slide."""
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = COLOR_BG_DARK


def add_header(slide, title_text, subtitle_text, category_badge=None):
    """Adds a clean standard header block across slides without top hackathon badge."""
    # Main Slide Title
    title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.65), Inches(11.7), Inches(0.55))
    tf_t = title_box.text_frame
    tf_t.word_wrap = True
    tf_t.margin_left = tf_t.margin_top = tf_t.margin_right = tf_t.margin_bottom = 0
    p_t = tf_t.paragraphs[0]
    p_t.text = title_text
    p_t.font.name = FONT_HEADING
    p_t.font.size = Pt(21)
    p_t.font.bold = True
    p_t.font.color.rgb = COLOR_TEXT_WHITE

    # Subtitle
    if subtitle_text:
        sub_box = slide.shapes.add_textbox(Inches(0.8), Inches(1.22), Inches(11.7), Inches(0.38))
        tf_s = sub_box.text_frame
        tf_s.word_wrap = True
        tf_s.margin_left = tf_s.margin_top = tf_s.margin_right = tf_s.margin_bottom = 0
        p_s = tf_s.paragraphs[0]
        p_s.text = subtitle_text
        p_s.font.name = FONT_BODY
        p_s.font.size = Pt(11)
        p_s.font.color.rgb = COLOR_TEXT_MUTED


def add_card(slide, left, top, width, height, bg_color=COLOR_CARD_BG, border_color=COLOR_CARD_BORDER):
    """Creates a rounded rectangular card container."""
    shape = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
    shape.fill.solid()
    shape.fill.fore_color.rgb = bg_color
    shape.line.color.rgb = border_color
    shape.line.width = Pt(1)
    return shape


# -------------------------------------------------------------
# SLIDE BUILDERS (12 Distinct Slides - Each Answers Exactly 1 Question)
# -------------------------------------------------------------

def build_slide_1_title(prs):
    """Slide 1: What is SkillBridge AI?"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)

    # Main Product Name
    name_box = slide.shapes.add_textbox(Inches(1.0), Inches(1.30), Inches(11.33), Inches(1.0))
    tf_name = name_box.text_frame
    p_name = tf_name.paragraphs[0]
    p_name.text = "SkillBridge AI"
    p_name.font.name = FONT_HEADING
    p_name.font.size = Pt(46)
    p_name.font.bold = True
    p_name.font.color.rgb = COLOR_TEXT_WHITE

    # Tagline
    tagline_box = slide.shapes.add_textbox(Inches(1.0), Inches(2.35), Inches(11.33), Inches(0.5))
    tf_tagline = tagline_box.text_frame
    p_tagline = tf_tagline.paragraphs[0]
    p_tagline.text = "Prove your skills. Find your fit. Become job-ready."
    p_tagline.font.name = FONT_HEADING
    p_tagline.font.size = Pt(20)
    p_tagline.font.bold = True
    p_tagline.font.color.rgb = COLOR_EMERALD

    # Mission Statement Card
    add_card(slide, Inches(1.0), Inches(3.10), Inches(11.33), Inches(1.1), bg_color=COLOR_CARD_BG, border_color=COLOR_PRIMARY)
    tb_m = slide.shapes.add_textbox(Inches(1.2), Inches(3.22), Inches(10.9), Inches(0.85))
    tf_m = tb_m.text_frame
    tf_m.word_wrap = True
    p_m1 = tf_m.paragraphs[0]
    p_m1.text = "THE CORE CONCEPT"
    p_m1.font.name = FONT_MONO
    p_m1.font.size = Pt(10)
    p_m1.font.bold = True
    p_m1.font.color.rgb = COLOR_AMBER

    p_m2 = tf_m.add_paragraph()
    p_m2.text = "An AI-powered capability-to-employment platform connecting skilled youth with MSMEs & startups through verified skill assessments, explainable job matching, and closed-loop personalized upskilling."
    p_m2.font.name = FONT_BODY
    p_m2.font.size = Pt(11.5)
    p_m2.font.color.rgb = COLOR_TEXT_LIGHT
    p_m2.space_before = Pt(4)

    # 3 Connected Entities Flow
    entities = [
        ("CANDIDATE / YOUTH", "Self-taught & Tier-2/3 graduates looking to prove practical ability", COLOR_CYAN),
        ("SKILLBRIDGE AI", "Assesses real skills • Explains job gaps • Creates upskilling roadmaps", COLOR_EMERALD),
        ("MSME EMPLOYERS", "Growing businesses looking for verified talent without heavy screening overhead", COLOR_AMBER),
    ]
    card_w = Inches(3.55)
    card_gap = Inches(0.34)
    start_x = Inches(1.0)
    top_y = Inches(4.55)

    for i, (stitle, sdesc, col) in enumerate(entities):
        x = start_x + i * (card_w + card_gap)
        add_card(slide, x, top_y, card_w, Inches(1.5), bg_color=COLOR_CARD_ALT, border_color=COLOR_CARD_BORDER)
        
        tb = slide.shapes.add_textbox(x + Inches(0.18), top_y + Inches(0.18), card_w - Inches(0.36), Inches(1.15))
        tf = tb.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = stitle
        p.font.name = FONT_HEADING
        p.font.size = Pt(12)
        p.font.bold = True
        p.font.color.rgb = col

        p2 = tf.add_paragraph()
        p2.text = sdesc
        p2.font.name = FONT_BODY
        p2.font.size = Pt(9.5)
        p2.font.color.rgb = COLOR_TEXT_MUTED
        p2.space_before = Pt(6)

    # Footer
    fb = slide.shapes.add_textbox(Inches(1.0), Inches(6.55), Inches(11.33), Inches(0.35))
    tf_f = fb.text_frame
    p_f = tf_f.paragraphs[0]
    p_f.text = "SkillBridge AI • Capability-to-Employment Platform"
    p_f.font.name = FONT_MONO
    p_f.font.size = Pt(9)
    p_f.font.color.rgb = COLOR_TEXT_DIM


def build_slide_2_problem(prs):
    """Slide 2: What problem are we solving?"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)
    add_header(slide, "\"The problem isn't finding a job. It's proving you're ready for one.\"",
               "Hiring is broken for both sides because resumes measure claims, not demonstrated capability.",
               "WHAT PROBLEM ARE WE SOLVING?")

    col_w = Inches(5.65)
    col_h = Inches(4.2)
    top_y = Inches(1.85)

    # Left Column: Youth
    add_card(slide, Inches(0.8), top_y, col_w, col_h, bg_color=COLOR_CARD_BG, border_color=COLOR_AMBER)
    tb_l = slide.shapes.add_textbox(Inches(1.05), top_y + Inches(0.2), col_w - Inches(0.5), col_h - Inches(0.4))
    tf_l = tb_l.text_frame
    tf_l.word_wrap = True

    p_lh = tf_l.paragraphs[0]
    p_lh.text = "SKILLED YOUTH & GRADUATES"
    p_lh.font.name = FONT_HEADING
    p_lh.font.size = Pt(12)
    p_lh.font.bold = True
    p_lh.font.color.rgb = COLOR_AMBER

    p_lq = tf_l.add_paragraph()
    p_lq.text = "“I know these skills... but how do I prove it?”"
    p_lq.font.name = FONT_HEADING
    p_lq.font.size = Pt(14)
    p_lq.font.bold = True
    p_lq.font.color.rgb = COLOR_TEXT_WHITE
    p_lq.space_before = Pt(4)
    p_lq.space_after = Pt(10)

    points_youth = [
        ("Resume Claims Only:", "Self-reported buzzwords carry low credibility without an elite college brand."),
        ("No Proof of Ability:", "No accessible, standardized way to demonstrate practical coding & debugging."),
        ("Black-Box Rejections:", "Silent rejections give zero diagnostic feedback — candidates don't know what to improve.")
    ]
    for title, desc in points_youth:
        p = tf_l.add_paragraph()
        p.space_after = Pt(6)
        r1 = p.add_run()
        r1.text = "• " + title + " "
        r1.font.bold = True
        r1.font.size = Pt(10)
        r1.font.color.rgb = COLOR_TEXT_LIGHT
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(9.5)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    # Right Column: MSME
    add_card(slide, Inches(6.85), top_y, col_w, col_h, bg_color=COLOR_CARD_BG, border_color=COLOR_CYAN)
    tb_r = slide.shapes.add_textbox(Inches(7.1), top_y + Inches(0.2), col_w - Inches(0.5), col_h - Inches(0.4))
    tf_r = tb_r.text_frame
    tf_r.word_wrap = True

    p_rh = tf_r.paragraphs[0]
    p_rh.text = "MSMES & EARLY-STAGE STARTUPS"
    p_rh.font.name = FONT_HEADING
    p_rh.font.size = Pt(12)
    p_rh.font.bold = True
    p_rh.font.color.rgb = COLOR_CYAN

    p_rq = tf_r.add_paragraph()
    p_rq.text = "“Which candidate can actually do the work?”"
    p_rq.font.name = FONT_HEADING
    p_rq.font.size = Pt(14)
    p_rq.font.bold = True
    p_rq.font.color.rgb = COLOR_TEXT_WHITE
    p_rq.space_before = Pt(4)
    p_rq.space_after = Pt(10)

    points_msme = [
        ("Resume Overload:", "Flooded with hundreds of resumes claiming Python and React, but few can debug an API."),
        ("Limited Screening Bandwidth:", "Founders lack full-time technical interview panels or assessment software."),
        ("High Cost of Mismatch:", "Hiring the wrong entry-level candidate drains months of team productivity.")
    ]
    for title, desc in points_msme:
        p = tf_r.add_paragraph()
        p.space_after = Pt(6)
        r1 = p.add_run()
        r1.text = "• " + title + " "
        r1.font.bold = True
        r1.font.size = Pt(10)
        r1.font.color.rgb = COLOR_TEXT_LIGHT
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(9.5)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    # Bottom Callout: The Gap
    add_card(slide, Inches(0.8), Inches(6.25), Inches(11.7), Inches(0.75), bg_color=COLOR_CARD_ALT, border_color=COLOR_ROSE)
    tb_b = slide.shapes.add_textbox(Inches(1.0), Inches(6.32), Inches(11.3), Inches(0.6))
    tf_b = tb_b.text_frame
    p_b = tf_b.paragraphs[0]
    p_b.text = "THE CORE GAP:   CLAIMED SKILLS  ≠  DEMONSTRATED SKILLS"
    p_b.font.name = FONT_HEADING
    p_b.font.size = Pt(12)
    p_b.font.bold = True
    p_b.font.color.rgb = COLOR_ROSE
    p_b.alignment = PP_ALIGN.CENTER

    p_b2 = tf_b.add_paragraph()
    p_b2.text = "SkillBridge AI replaces resume self-reporting with objective, verified capability evidence."
    p_b2.font.name = FONT_BODY
    p_b2.font.size = Pt(9.5)
    p_b2.font.color.rgb = COLOR_TEXT_LIGHT
    p_b2.alignment = PP_ALIGN.CENTER
    p_b2.space_before = Pt(2)


def build_slide_3_solution(prs):
    """Slide 3: What is our solution?"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)
    add_header(slide, "Our Solution: The Closed-Loop Capability Pipeline",
               "A 7-stage workflow turning unverified claims into job-ready capability.",
               "WHAT IS OUR SOLUTION?")

    # 7 Big Pipeline Stages Across Slide
    stages = [
        ("01", "RESUME", "Upload PDF/TXT", COLOR_CYAN),
        ("02", "ASSESS", "Scenario Tests", COLOR_PRIMARY_LIGHT),
        ("03", "PROVE", "Verified Scores", COLOR_EMERALD),
        ("04", "MATCH", "Weighted Fit", COLOR_PRIMARY_LIGHT),
        ("05", "GAPS", "Itemized Deficits", COLOR_AMBER),
        ("06", "IMPROVE", "4-Step Roadmap", COLOR_CYAN),
        ("07", "REASSESS", "Unlock Fit", COLOR_EMERALD),
    ]

    card_w = Inches(1.47)
    card_gap = Inches(0.23)
    start_x = Inches(0.8)
    top_y = Inches(2.1)

    for i, (num, title, desc, col) in enumerate(stages):
        x = start_x + i * (card_w + card_gap)
        add_card(slide, x, top_y, card_w, Inches(2.2), bg_color=COLOR_CARD_BG, border_color=col)

        tb = slide.shapes.add_textbox(x + Inches(0.08), top_y + Inches(0.15), card_w - Inches(0.16), Inches(1.9))
        tf = tb.text_frame
        tf.word_wrap = True

        p_num = tf.paragraphs[0]
        p_num.text = num
        p_num.font.name = FONT_MONO
        p_num.font.size = Pt(13)
        p_num.font.bold = True
        p_num.font.color.rgb = col
        p_num.alignment = PP_ALIGN.CENTER

        p_t = tf.add_paragraph()
        p_t.text = title
        p_t.font.name = FONT_HEADING
        p_t.font.size = Pt(11)
        p_t.font.bold = True
        p_t.font.color.rgb = COLOR_TEXT_WHITE
        p_t.alignment = PP_ALIGN.CENTER
        p_t.space_before = Pt(6)

        p_d = tf.add_paragraph()
        p_d.text = desc
        p_d.font.name = FONT_BODY
        p_d.font.size = Pt(8.5)
        p_d.font.color.rgb = COLOR_TEXT_MUTED
        p_d.alignment = PP_ALIGN.CENTER
        p_d.space_before = Pt(6)

        # Arrow indicator between cards (except last)
        if i < 6:
            arrow_box = slide.shapes.add_textbox(x + card_w, top_y + Inches(0.9), card_gap, Inches(0.4))
            tf_a = arrow_box.text_frame
            tf_a.margin_left = tf_a.margin_top = tf_a.margin_right = tf_a.margin_bottom = 0
            pa = tf_a.paragraphs[0]
            pa.text = "►"
            pa.font.size = Pt(11)
            pa.font.color.rgb = COLOR_TEXT_DIM
            pa.alignment = PP_ALIGN.CENTER

    # Under-Pipeline Hero Statement Card
    add_card(slide, Inches(0.8), Inches(4.7), Inches(11.7), Inches(1.9), bg_color=COLOR_CARD_ALT, border_color=COLOR_EMERALD)
    tb_h = slide.shapes.add_textbox(Inches(1.1), Inches(4.9), Inches(11.1), Inches(1.5))
    tf_h = tb_h.text_frame
    tf_h.word_wrap = True

    p_hh = tf_h.paragraphs[0]
    p_hh.text = "“We don't stop at matching people to jobs.\nWe show them how to become ready for the job.”"
    p_hh.font.name = FONT_HEADING
    p_hh.font.size = Pt(17)
    p_hh.font.bold = True
    p_hh.font.color.rgb = COLOR_TEXT_WHITE
    p_hh.alignment = PP_ALIGN.CENTER

    p_hs = tf_h.add_paragraph()
    p_hs.text = "Traditional job boards treat rejection as a dead end. SkillBridge AI treats rejection as a diagnostic baseline — giving every candidate a clear path from 71% to 92% readiness."
    p_hs.font.name = FONT_BODY
    p_hs.font.size = Pt(10.5)
    p_hs.font.color.rgb = COLOR_TEXT_MUTED
    p_hs.alignment = PP_ALIGN.CENTER
    p_hs.space_before = Pt(8)


def build_slide_4_human_story(prs):
    """Slide 4: How it works for one candidate? (The Human Story - Arjun)"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)
    add_header(slide, "How It Works: Arjun's Path to 92% Job Readiness",
               "A concrete walkthrough: Candidate Arjun applying for Junior Backend Developer at TechNova Solutions.",
               "A CONCRETE CANDIDATE WALKTHROUGH")

    col_w = Inches(3.7)
    col_h = Inches(4.55)
    top_y = Inches(1.9)

    # Column 1: Arjun Claims vs Assessed
    add_card(slide, Inches(0.8), top_y, col_w, col_h)
    tb_1 = slide.shapes.add_textbox(Inches(0.95), top_y + Inches(0.15), col_w - Inches(0.3), col_h - Inches(0.3))
    tf_1 = tb_1.text_frame
    tf_1.word_wrap = True

    p_1h = tf_1.paragraphs[0]
    p_1h.text = "1. CLAIMED VS ASSESSED"
    p_1h.font.name = FONT_HEADING
    p_1h.font.size = Pt(11)
    p_1h.font.bold = True
    p_1h.font.color.rgb = COLOR_CYAN

    p_1c = tf_1.add_paragraph()
    p_1c.text = "Candidate: Arjun (Tier-3 B.Tech Grad)\nResume Claims: Python, SQL, Flask, REST API, Git"
    p_1c.font.name = FONT_BODY
    p_1c.font.size = Pt(9.5)
    p_1c.font.color.rgb = COLOR_TEXT_LIGHT
    p_1c.space_before = Pt(4)
    p_1c.space_after = Pt(8)

    skills_data = [
        ("Python", "85% (Advanced)", COLOR_EMERALD),
        ("SQL Database", "78% (Intermediate)", COLOR_EMERALD),
        ("Flask Framework", "72% (Intermediate)", COLOR_EMERALD),
        ("REST APIs", "42% (Needs Work)", COLOR_AMBER),
        ("Git / VCS", "35% (Beginner)", COLOR_ROSE),
    ]
    for sname, sscore, scol in skills_data:
        p = tf_1.add_paragraph()
        p.space_after = Pt(4)
        r1 = p.add_run()
        r1.text = sname + ": "
        r1.font.bold = True
        r1.font.size = Pt(9.5)
        r1.font.color.rgb = COLOR_TEXT_LIGHT
        r2 = p.add_run()
        r2.text = sscore
        r2.font.bold = True
        r2.font.size = Pt(9.5)
        r2.font.color.rgb = scol

    p_1note = tf_1.add_paragraph()
    p_1note.text = "\nAssessment proves he knows core Python & SQL, but has blind spots in API architecture."
    p_1note.font.name = FONT_BODY
    p_1note.font.size = Pt(9)
    p_1note.font.color.rgb = COLOR_TEXT_MUTED

    # Column 2: Current Job Match (71%) & Explainability
    add_card(slide, Inches(4.8), top_y, col_w, col_h, bg_color=COLOR_CARD_ALT, border_color=COLOR_AMBER)
    tb_2 = slide.shapes.add_textbox(Inches(4.95), top_y + Inches(0.15), col_w - Inches(0.3), col_h - Inches(0.3))
    tf_2 = tb_2.text_frame
    tf_2.word_wrap = True

    p_2h = tf_2.paragraphs[0]
    p_2h.text = "2. CURRENT MATCH: 71%"
    p_2h.font.name = FONT_HEADING
    p_2h.font.size = Pt(11)
    p_2h.font.bold = True
    p_2h.font.color.rgb = COLOR_AMBER

    p_2b = tf_2.add_paragraph()
    p_2b.text = "71%"
    p_2b.font.name = FONT_HEADING
    p_2b.font.size = Pt(36)
    p_2b.font.bold = True
    p_2b.font.color.rgb = COLOR_AMBER
    p_2b.alignment = PP_ALIGN.CENTER
    p_2b.space_before = Pt(4)

    p_2m = tf_2.add_paragraph()
    p_2m.text = "Role: Junior Backend Dev (TechNova)"
    p_2m.font.name = FONT_BODY
    p_2m.font.size = Pt(9.5)
    p_2m.font.color.rgb = COLOR_TEXT_LIGHT
    p_2m.alignment = PP_ALIGN.CENTER
    p_2m.space_after = Pt(8)

    p_2e = tf_2.add_paragraph()
    p_2e.text = "SkillBridge Explainability:"
    p_2e.font.name = FONT_HEADING
    p_2e.font.size = Pt(10)
    p_2e.font.bold = True
    p_2e.font.color.rgb = COLOR_TEXT_WHITE

    p_2e1 = tf_2.add_paragraph()
    p_2e1.text = "✓ Strong: Python (85%) & SQL (78%) fully satisfy job requirements."
    p_2e1.font.name = FONT_BODY
    p_2e1.font.size = Pt(9)
    p_2e1.font.color.rgb = COLOR_EMERALD
    p_2e1.space_before = Pt(3)

    p_2e2 = tf_2.add_paragraph()
    p_2e2.text = "⚠ Holding Score Back: REST APIs (42/65) and Git (35/50) reduce fit by 21%."
    p_2e2.font.name = FONT_BODY
    p_2e2.font.size = Pt(9)
    p_2e2.font.color.rgb = COLOR_ROSE
    p_2e2.space_before = Pt(3)

    # Column 3: Simulator & Projected 92%
    add_card(slide, Inches(8.8), top_y, col_w, col_h, bg_color=COLOR_CARD_BG, border_color=COLOR_EMERALD)
    tb_3 = slide.shapes.add_textbox(Inches(8.95), top_y + Inches(0.15), col_w - Inches(0.3), col_h - Inches(0.3))
    tf_3 = tb_3.text_frame
    tf_3.word_wrap = True

    p_3h = tf_3.paragraphs[0]
    p_3h.text = "3. ROADMAP & SIMULATOR: 92%"
    p_3h.font.name = FONT_HEADING
    p_3h.font.size = Pt(11)
    p_3h.font.bold = True
    p_3h.font.color.rgb = COLOR_EMERALD

    p_3b = tf_3.add_paragraph()
    p_3b.text = "92%"
    p_3b.font.name = FONT_HEADING
    p_3b.font.size = Pt(36)
    p_3b.font.bold = True
    p_3b.font.color.rgb = COLOR_EMERALD
    p_3b.alignment = PP_ALIGN.CENTER
    p_3b.space_before = Pt(4)

    p_3m = tf_3.add_paragraph()
    p_3m.text = "Projected Match Upon Upskilling"
    p_3m.font.name = FONT_BODY
    p_3m.font.size = Pt(9.5)
    p_3m.font.color.rgb = COLOR_TEXT_LIGHT
    p_3m.alignment = PP_ALIGN.CENTER
    p_3m.space_after = Pt(8)

    p_3r = tf_3.add_paragraph()
    p_3r.text = "What-If Simulator Projection:"
    p_3r.font.name = FONT_HEADING
    p_3r.font.size = Pt(10)
    p_3r.font.bold = True
    p_3r.font.color.rgb = COLOR_TEXT_WHITE

    p_3r1 = tf_3.add_paragraph()
    p_3r1.text = "• Slide REST API from 42 → 65"
    p_3r1.font.name = FONT_BODY
    p_3r1.font.size = Pt(9)
    p_3r1.font.color.rgb = COLOR_TEXT_LIGHT
    p_3r1.space_before = Pt(3)

    p_3r2 = tf_3.add_paragraph()
    p_3r2.text = "• Slide Git from 35 → 55"
    p_3r2.font.name = FONT_BODY
    p_3r2.font.size = Pt(9)
    p_3r2.font.color.rgb = COLOR_TEXT_LIGHT
    p_3r2.space_before = Pt(2)

    p_3r3 = tf_3.add_paragraph()
    p_3r3.text = "• 4-Step Personalized Roadmap: Learn → Practice → Build Project → Reassess"
    p_3r3.font.name = FONT_BODY
    p_3r3.font.size = Pt(9)
    p_3r3.font.color.rgb = COLOR_CYAN
    p_3r3.space_before = Pt(3)

    p_3r4 = tf_3.add_paragraph()
    p_3r4.text = "\nProjected match rises from 71% → 92%, making Arjun more competitive for the role."
    p_3r4.font.name = FONT_HEADING
    p_3r4.font.size = Pt(9.5)
    p_3r4.font.bold = True
    p_3r4.font.color.rgb = COLOR_EMERALD

    # Disclaimer Note at bottom of slide
    tb_disc = slide.shapes.add_textbox(Inches(0.8), Inches(6.52), Inches(11.7), Inches(0.4))
    tf_disc = tb_disc.text_frame
    p_disc = tf_disc.paragraphs[0]
    p_disc.text = "* Projected based on simulated skill improvement — not a hiring guarantee."
    p_disc.font.name = FONT_MONO
    p_disc.font.size = Pt(9.5)
    p_disc.font.bold = True
    p_disc.font.color.rgb = COLOR_AMBER


def build_slide_5_uniqueness(prs):
    """Slide 5: Why is it different?"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)
    add_header(slide, "What Makes Us Different: Three Core Pillars",
               "Focusing on the three strongest capability differentiators.",
               "WHY IS IT DIFFERENT?")

    # 3 Core Pillar Cards
    pillars = [
        ("01 — PROVE", "Evidence Over Claims",
         "AI scenario assessments replace self-reported buzzwords with demonstrated capability scores.",
         COLOR_PRIMARY_LIGHT),
        ("02 — EXPLAIN", "Clear Reasoning Over Black Boxes",
         "Instead of an opaque '71% match', explain exactly WHY: itemized skill contributions & gaps.",
         COLOR_CYAN),
        ("03 — IMPROVE", "Actionable Guidance Over Dead Ends",
         "Show candidates what skills to improve and simulate match gains (71% → 92%) before studying.",
         COLOR_EMERALD),
    ]

    card_w = Inches(3.7)
    card_h = Inches(2.7)
    card_gap = Inches(0.3)
    start_x = Inches(0.8)
    top_y = Inches(1.9)

    for i, (pnum, ptitle, pdesc, col) in enumerate(pillars):
        x = start_x + i * (card_w + card_gap)
        add_card(slide, x, top_y, card_w, card_h, bg_color=COLOR_CARD_BG, border_color=col)

        tb = slide.shapes.add_textbox(x + Inches(0.2), top_y + Inches(0.2), card_w - Inches(0.4), card_h - Inches(0.4))
        tf = tb.text_frame
        tf.word_wrap = True

        p1 = tf.paragraphs[0]
        p1.text = pnum
        p1.font.name = FONT_MONO
        p1.font.size = Pt(13)
        p1.font.bold = True
        p1.font.color.rgb = col

        p2 = tf.add_paragraph()
        p2.text = ptitle
        p2.font.name = FONT_HEADING
        p2.font.size = Pt(13)
        p2.font.bold = True
        p2.font.color.rgb = COLOR_TEXT_WHITE
        p2.space_before = Pt(6)

        p3 = tf.add_paragraph()
        p3.text = pdesc
        p3.font.name = FONT_BODY
        p3.font.size = Pt(10)
        p3.font.color.rgb = COLOR_TEXT_MUTED
        p3.space_before = Pt(8)

    # Bottom Visual Transformation Card
    add_card(slide, Inches(0.8), Inches(4.85), Inches(11.7), Inches(1.85), bg_color=COLOR_CARD_ALT, border_color=COLOR_PRIMARY)
    tb_b = slide.shapes.add_textbox(Inches(1.0), Inches(5.0), Inches(11.3), Inches(1.55))
    tf_b = tb_b.text_frame
    tf_b.word_wrap = True

    p_bh = tf_b.paragraphs[0]
    p_bh.text = "THE REINFORCING PRODUCT LOOP"
    p_bh.font.name = FONT_MONO
    p_bh.font.size = Pt(10)
    p_bh.font.bold = True
    p_bh.font.color.rgb = COLOR_AMBER
    p_bh.alignment = PP_ALIGN.CENTER

    p_bt = tf_b.add_paragraph()
    p_bt.text = "71% BASELINE MATCH   ──►   [ + REST API & GIT UPSKILLING ]   ──►   92% PROJECTED MATCH"
    p_bt.font.name = FONT_HEADING
    p_bt.font.size = Pt(15)
    p_bt.font.bold = True
    p_bt.font.color.rgb = COLOR_TEXT_WHITE
    p_bt.alignment = PP_ALIGN.CENTER
    p_bt.space_before = Pt(6)

    p_bl = tf_b.add_paragraph()
    p_bl.text = "Assess  ──►  Match  ──►  Improve  ──►  Reassess"
    p_bl.font.name = FONT_MONO
    p_bl.font.size = Pt(12)
    p_bl.font.bold = True
    p_bl.font.color.rgb = COLOR_EMERALD
    p_bl.alignment = PP_ALIGN.CENTER
    p_bl.space_before = Pt(8)


def build_slide_6_technical_approach(prs):
    """Slide 6: How does it work technically?"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)
    add_header(slide, "Technical Architecture: Clean, Modular & Lightweight",
               "Structured 6-layer architecture with built-in fallback reliability.",
               "HOW DOES IT WORK TECHNICALLY?")

    # Left Side: Architecture Flow Cards (Stacked)
    layers = [
        ("USER LAYER", "Candidate Portal (Students & Job Seekers)  •  MSME Employer Portal (Founders & Hiring Teams)", COLOR_CYAN),
        ("WEB APPLICATION", "HTML5  •  CSS3  •  JavaScript (Vanilla)  •  Bootstrap 5.3 (Zero frontend bundle overhead)", COLOR_PRIMARY_LIGHT),
        ("FLASK BACKEND", "Python 3.12 Flask Application  •  RESTful Controllers  •  Role-Based Session Authentication", COLOR_TEXT_LIGHT),
        ("AI SERVICES CORE", "Resume Parsing  •  Scenario-Based Assessment  •  Job Description Analysis  •  Roadmap Generation", COLOR_EMERALD),
        ("MATCHING ENGINE", "Weighted Skill Matching (Important skills contribute more)  •  Skill Gaps Affecting the Match", COLOR_AMBER),
        ("PERSISTENCE LAYER", "Database (SQLite) with SQLAlchemy 2.0 ORM (Zero-configuration portable setup)", COLOR_TEXT_MUTED),
    ]

    top_y = Inches(1.85)
    card_h = Inches(0.68)
    gap_y = Inches(0.12)
    for i, (lname, ldesc, col) in enumerate(layers):
        y = top_y + i * (card_h + gap_y)
        add_card(slide, Inches(0.8), y, Inches(7.5), card_h)

        tb = slide.shapes.add_textbox(Inches(0.95), y + Inches(0.08), Inches(7.2), card_h - Inches(0.16))
        tf = tb.text_frame
        tf.word_wrap = True

        p = tf.paragraphs[0]
        r1 = p.add_run()
        r1.text = lname + ": "
        r1.font.name = FONT_HEADING
        r1.font.bold = True
        r1.font.size = Pt(10)
        r1.font.color.rgb = col

        r2 = p.add_run()
        r2.text = ldesc
        r2.font.name = FONT_BODY
        r2.font.size = Pt(9)
        r2.font.color.rgb = COLOR_TEXT_LIGHT

    # Right Side: Demo Reliability Box
    add_card(slide, Inches(8.6), Inches(1.85), Inches(3.9), Inches(4.7), bg_color=COLOR_CARD_ALT, border_color=COLOR_EMERALD)
    tb_r = slide.shapes.add_textbox(Inches(8.8), Inches(2.05), Inches(3.5), Inches(4.3))
    tf_r = tb_r.text_frame
    tf_r.word_wrap = True

    p_rh = tf_r.paragraphs[0]
    p_rh.text = "DEMO RELIABILITY DESIGN"
    p_rh.font.name = FONT_HEADING
    p_rh.font.size = Pt(12)
    p_rh.font.bold = True
    p_rh.font.color.rgb = COLOR_EMERALD

    p_rf = tf_r.add_paragraph()
    p_rf.text = "AI API  ──►  Local Fallback Mode"
    p_rf.font.name = FONT_MONO
    p_rf.font.size = Pt(10)
    p_rf.font.bold = True
    p_rf.font.color.rgb = COLOR_PRIMARY_LIGHT
    p_rf.space_before = Pt(6)
    p_rf.space_after = Pt(10)

    rel_points = [
        ("Graceful Fallback Logic:", "All external LLM calls are guarded by error handlers that switch to deterministic local rubrics if the API is unavailable."),
        ("Designed for Demo Stability:", "If Wi-Fi drops or API quota is reached during judging, the application remains functional with fallback responses."),
        ("Fast Local Processing:", "Core matching algorithm and pre-computed scoring execute locally for responsive results."),
        ("Self-Contained Portability:", "Runs locally out of the box with zero external database dependencies or Docker requirements.")
    ]
    for title, desc in rel_points:
        p = tf_r.add_paragraph()
        p.space_after = Pt(6)
        r1 = p.add_run()
        r1.text = "• " + title + " "
        r1.font.bold = True
        r1.font.size = Pt(9.5)
        r1.font.color.rgb = COLOR_TEXT_LIGHT
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(9)
        r2.font.color.rgb = COLOR_TEXT_MUTED


def build_slide_7_system_flow(prs):
    """Slide 7: How does the system flow?"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)
    add_header(slide, "Dual-Track System Flow: Where Youth & MSMEs Converge",
               "Two distinct user journeys converging at the centralized matching engine.",
               "HOW DOES THE SYSTEM FLOW?")

    col_w = Inches(3.6)
    col_h = Inches(4.7)
    top_y = Inches(1.9)

    # Lane 1: Candidate
    add_card(slide, Inches(0.8), top_y, col_w, col_h, bg_color=COLOR_CARD_BG, border_color=COLOR_CYAN)
    tb_c = slide.shapes.add_textbox(Inches(0.95), top_y + Inches(0.18), col_w - Inches(0.3), col_h - Inches(0.36))
    tf_c = tb_c.text_frame
    tf_c.word_wrap = True

    p_ch = tf_c.paragraphs[0]
    p_ch.text = "CANDIDATE JOURNEY"
    p_ch.font.name = FONT_HEADING
    p_ch.font.size = Pt(12)
    p_ch.font.bold = True
    p_ch.font.color.rgb = COLOR_CYAN
    p_ch.space_after = Pt(10)

    c_steps = [
        "1. Upload Resume (PDF / TXT)",
        "2. AI Extracts Claimed Skills",
        "3. Complete 5-Question Scenario Assessment",
        "4. View Assessed Skill Confidence Scores",
        "5. Review Ranked MSME Job Matches",
        "6. Inspect Skill Gaps Affecting the Match",
        "7. Follow 4-Step Personalized Roadmap",
        "8. Reassess to Unlock Higher Fit Score"
    ]
    for step in c_steps:
        p = tf_c.add_paragraph()
        p.text = step
        p.font.name = FONT_BODY
        p.font.size = Pt(9.5)
        p.font.color.rgb = COLOR_TEXT_LIGHT
        p.space_after = Pt(5)

    # Center Hub: Matching Engine
    add_card(slide, Inches(4.7), top_y, Inches(3.93), col_h, bg_color=COLOR_CARD_ALT, border_color=COLOR_EMERALD)
    tb_m = slide.shapes.add_textbox(Inches(4.85), top_y + Inches(0.18), Inches(3.63), col_h - Inches(0.36))
    tf_m = tb_m.text_frame
    tf_m.word_wrap = True

    p_mh = tf_m.paragraphs[0]
    p_mh.text = "MATCHING ENGINE"
    p_mh.font.name = FONT_HEADING
    p_mh.font.size = Pt(12)
    p_mh.font.bold = True
    p_mh.font.color.rgb = COLOR_EMERALD
    p_mh.alignment = PP_ALIGN.CENTER
    p_mh.space_after = Pt(10)

    m_points = [
        ("Weighted Skill Matching:", "Important job skills contribute more to the final match score."),
        ("Capability Matrix:", "Compares candidate assessed score against employer target level."),
        ("Skill Gaps Affecting Match:", "Clear attribution of points lost to missing or deficient skills."),
        ("Transparent Reasoning:", "Plain-language explanation of strengths and improvement areas."),
        ("What-If Simulator:", "Dynamically recomputes fit score as candidate adjusts skill sliders.")
    ]
    for title, desc in m_points:
        p = tf_m.add_paragraph()
        p.space_after = Pt(6)
        r1 = p.add_run()
        r1.text = "• " + title + " "
        r1.font.bold = True
        r1.font.size = Pt(9.5)
        r1.font.color.rgb = COLOR_TEXT_WHITE
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(9)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    # Lane 2: MSME Employer
    add_card(slide, Inches(8.93), top_y, col_w, col_h, bg_color=COLOR_CARD_BG, border_color=COLOR_AMBER)
    tb_e = slide.shapes.add_textbox(Inches(9.08), top_y + Inches(0.18), col_w - Inches(0.3), col_h - Inches(0.36))
    tf_e = tb_e.text_frame
    tf_e.word_wrap = True

    p_eh = tf_e.paragraphs[0]
    p_eh.text = "MSME EMPLOYER JOURNEY"
    p_eh.font.name = FONT_HEADING
    p_eh.font.size = Pt(12)
    p_eh.font.bold = True
    p_eh.font.color.rgb = COLOR_AMBER
    p_eh.space_after = Pt(10)

    e_steps = [
        "1. Sign In (e.g. Vikram Mehta, TechNova)",
        "2. Post Job Opening (Assisted by AI)",
        "3. Set Required Skills & Score Targets",
        "4. Assign Importance Weights (High / Medium)",
        "5. Review Candidates Ranked by Assessed Skill",
        "6. Inspect Candidate Evidence & Scorecards",
        "7. 1-Click Shortlist Suitable Applicants",
        "8. Evidence-Based Hiring Workflow"
    ]
    for step in e_steps:
        p = tf_e.add_paragraph()
        p.text = step
        p.font.name = FONT_BODY
        p.font.size = Pt(9.5)
        p.font.color.rgb = COLOR_TEXT_LIGHT
        p.space_after = Pt(5)


def build_slide_8_matching_logic(prs):
    """Slide 8: How does matching actually work?"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)
    add_header(slide, "Explainable Matching: How the Score is Calculated",
               "A transparent scorecard showing exactly why a candidate matched at 71%.",
               "HOW DOES MATCHING ACTUALLY WORK?")

    # Left Table: Skill Scorecard
    table_shape = slide.shapes.add_table(5, 4, Inches(0.8), Inches(1.9), Inches(7.5), Inches(3.2))
    table = table_shape.table

    table.columns[0].width = Inches(1.8)
    table.columns[1].width = Inches(1.6)
    table.columns[2].width = Inches(1.6)
    table.columns[3].width = Inches(2.5)

    headers = ["Skill", "Job Required", "Arjun's Score", "Status & Attribution"]
    for j, h in enumerate(headers):
        cell = table.cell(0, j)
        cell.fill.solid()
        cell.fill.fore_color.rgb = RGBColor(24, 33, 47)
        p = cell.text_frame.paragraphs[0]
        p.text = h
        p.font.name = FONT_HEADING
        p.font.size = Pt(10)
        p.font.bold = True
        p.font.color.rgb = COLOR_TEXT_WHITE
        p.alignment = PP_ALIGN.CENTER if j > 0 else PP_ALIGN.LEFT

    rows_data = [
        ("Python", "70 / 100", "80 / 100", "✓ Exceeds (+Full 35% credit)"),
        ("SQL Database", "65 / 100", "70 / 100", "✓ Exceeds (+Full 25% credit)"),
        ("REST APIs", "65 / 100", "42 / 100", "⚠ Partial Gap (Lost 9 points)"),
        ("Git / VCS", "50 / 100", "35 / 100", "⚠ Partial Gap (Lost 5 points)"),
    ]
    for i, row in enumerate(rows_data):
        for j, val in enumerate(row):
            cell = table.cell(i + 1, j)
            cell.fill.solid()
            cell.fill.fore_color.rgb = RGBColor(30, 41, 59) if i % 2 == 0 else RGBColor(24, 33, 47)
            p = cell.text_frame.paragraphs[0]
            p.text = val
            p.font.name = FONT_BODY
            p.font.size = Pt(9.5)
            if j == 0:
                p.font.bold = True
                p.font.color.rgb = COLOR_TEXT_WHITE
            elif j == 3:
                p.font.bold = True
                p.font.color.rgb = COLOR_EMERALD if "✓" in val else COLOR_AMBER
            else:
                p.font.color.rgb = COLOR_TEXT_LIGHT
            p.alignment = PP_ALIGN.CENTER if j > 0 else PP_ALIGN.LEFT

    # Under Table Note
    tb_un = slide.shapes.add_textbox(Inches(0.8), Inches(5.3), Inches(7.5), Inches(1.3))
    tf_un = tb_un.text_frame
    tf_un.word_wrap = True
    p_un1 = tf_un.paragraphs[0]
    p_un1.text = "How the Match Is Calculated:"
    p_un1.font.name = FONT_HEADING
    p_un1.font.size = Pt(9.5)
    p_un1.font.bold = True
    p_un1.font.color.rgb = COLOR_PRIMARY_LIGHT

    p_un2 = tf_un.add_paragraph()
    p_un2.text = "Match Score = Sum( Skill Weight × min(1.0, Candidate Score / Required Score) ) - Missing Skill Penalties"
    p_un2.font.name = FONT_MONO
    p_un2.font.size = Pt(9)
    p_un2.font.color.rgb = COLOR_TEXT_MUTED
    p_un2.space_before = Pt(2)

    p_un3 = tf_un.add_paragraph()
    p_un3.text = "Important skills contribute more to the final score; deficits below required levels reduce the match proportionally."
    p_un3.font.name = FONT_BODY
    p_un3.font.size = Pt(8.5)
    p_un3.font.color.rgb = COLOR_TEXT_DIM
    p_un3.space_before = Pt(2)

    # Right Card: The Big Result & Explanation
    add_card(slide, Inches(8.6), Inches(1.9), Inches(3.9), Inches(4.7), bg_color=COLOR_CARD_ALT, border_color=COLOR_AMBER)
    tb_r = slide.shapes.add_textbox(Inches(8.8), Inches(2.1), Inches(3.5), Inches(4.3))
    tf_r = tb_r.text_frame
    tf_r.word_wrap = True

    p_rh = tf_r.paragraphs[0]
    p_rh.text = "CURRENT MATCH SCORE"
    p_rh.font.name = FONT_HEADING
    p_rh.font.size = Pt(11)
    p_rh.font.bold = True
    p_rh.font.color.rgb = COLOR_AMBER
    p_rh.alignment = PP_ALIGN.CENTER

    p_rb = tf_r.add_paragraph()
    p_rb.text = "71%"
    p_rb.font.name = FONT_HEADING
    p_rb.font.size = Pt(44)
    p_rb.font.bold = True
    p_rb.font.color.rgb = COLOR_AMBER
    p_rb.alignment = PP_ALIGN.CENTER
    p_rb.space_before = Pt(4)

    p_why = tf_r.add_paragraph()
    p_why.text = "WHY 71%?"
    p_why.font.name = FONT_HEADING
    p_why.font.size = Pt(11)
    p_why.font.bold = True
    p_why.font.color.rgb = COLOR_TEXT_WHITE
    p_why.space_before = Pt(8)

    p_w1 = tf_r.add_paragraph()
    p_w1.text = "✓ Python (80) & SQL (70) provide 60.0% full credit."
    p_w1.font.name = FONT_BODY
    p_w1.font.size = Pt(9.5)
    p_w1.font.color.rgb = COLOR_EMERALD
    p_w1.space_before = Pt(4)

    p_w2 = tf_r.add_paragraph()
    p_w2.text = "⚠ REST API (42/65) gives only 16.1% out of 25%."
    p_w2.font.name = FONT_BODY
    p_w2.font.size = Pt(9.5)
    p_w2.font.color.rgb = COLOR_AMBER
    p_w2.space_before = Pt(3)

    p_w3 = tf_r.add_paragraph()
    p_w3.text = "⚠ Git (35/50) gives only 10.5% out of 15%."
    p_w3.font.name = FONT_BODY
    p_w3.font.size = Pt(9.5)
    p_w3.font.color.rgb = COLOR_ROSE
    p_w3.space_before = Pt(3)

    p_action = tf_r.add_paragraph()
    p_action.text = "\nClear Action: Raising REST API to 65 projects match to 86%; adding Git to 55 projects match to 92%!"
    p_action.font.name = FONT_HEADING
    p_action.font.size = Pt(9.5)
    p_action.font.bold = True
    p_action.font.color.rgb = COLOR_TEXT_WHITE


def build_slide_9_feasibility(prs):
    """Slide 9: Can we actually build this?"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)
    add_header(slide, "\"Can we actually build this?\"  --  YES.",
               "The MVP uses proven, lightweight technologies; future scale is clearly defined.",
               "CAN WE ACTUALLY BUILD THIS?")

    col_w = Inches(5.65)
    col_h = Inches(4.7)
    top_y = Inches(1.9)

    # Left: Built Today for the Hackathon
    add_card(slide, Inches(0.8), top_y, col_w, col_h, bg_color=COLOR_CARD_BG, border_color=COLOR_EMERALD)
    tb_l = slide.shapes.add_textbox(Inches(1.05), top_y + Inches(0.2), col_w - Inches(0.5), col_h - Inches(0.4))
    tf_l = tb_l.text_frame
    tf_l.word_wrap = True

    p_lh = tf_l.paragraphs[0]
    p_lh.text = "BUILT FOR THE HACKATHON (WORKING MVP)"
    p_lh.font.name = FONT_HEADING
    p_lh.font.size = Pt(12)
    p_lh.font.bold = True
    p_lh.font.color.rgb = COLOR_EMERALD

    p_lt = tf_l.add_paragraph()
    p_lt.text = "Stack: Python 3.12 • Flask • SQLite • HTML/CSS/JS • OpenAI API"
    p_lt.font.name = FONT_MONO
    p_lt.font.size = Pt(9)
    p_lt.font.color.rgb = COLOR_PRIMARY_LIGHT
    p_lt.space_before = Pt(3)
    p_lt.space_after = Pt(8)

    mvp_items = [
        ("Candidate & MSME Portals:", "Full session authentication with 1-click demo personas."),
        ("AI Assessment Service:", "Case-insensitive 5-question scenario checks with automated grading."),
        ("Weighted Matching Engine:", "Transparent capability fit algorithm based on skill weights."),
        ("What-If Simulator:", "Live dynamic slider recalculation (+21% projected match gain)."),
        ("Actionable Roadmap:", "4-step personalized curriculum targeting exact candidate deficits."),
        ("Fallback Demo Mode:", "Designed with validation and fallback handling if external APIs drop.")
    ]
    for title, desc in mvp_items:
        p = tf_l.add_paragraph()
        p.space_after = Pt(5)
        r1 = p.add_run()
        r1.text = "• " + title + " "
        r1.font.bold = True
        r1.font.size = Pt(9.5)
        r1.font.color.rgb = COLOR_TEXT_WHITE
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(9)
        r2.font.color.rgb = COLOR_TEXT_LIGHT

    # Right: Production Roadmap (Future Scale)
    add_card(slide, Inches(6.85), top_y, col_w, col_h, bg_color=COLOR_CARD_ALT, border_color=COLOR_CARD_BORDER)
    tb_r = slide.shapes.add_textbox(Inches(7.1), top_y + Inches(0.2), col_w - Inches(0.5), col_h - Inches(0.4))
    tf_r = tb_r.text_frame
    tf_r.word_wrap = True

    p_rh = tf_r.paragraphs[0]
    p_rh.text = "FUTURE PRODUCTION ROADMAP (SCALE)"
    p_rh.font.name = FONT_HEADING
    p_rh.font.size = Pt(12)
    p_rh.font.bold = True
    p_rh.font.color.rgb = COLOR_TEXT_MUTED

    p_rt = tf_r.add_paragraph()
    p_rt.text = "Planned enhancements for post-hackathon deployment"
    p_rt.font.name = FONT_BODY
    p_rt.font.size = Pt(9)
    p_rt.font.color.rgb = COLOR_TEXT_DIM
    p_rt.space_before = Pt(3)
    p_rt.space_after = Pt(8)

    future_items = [
        ("Sandboxed Code Execution:", "Dockerized runtime for live code tests and repository analysis."),
        ("Verifiable Micro-Credentials:", "Digitally signed certificates compatible with DigiLocker / NSDC."),
        ("Skill Similarity Analysis:", "Map related skill terms and technologies across job descriptions."),
        ("Scalable Backend Design:", "Future migration to PostgreSQL and caching as platform user base expands."),
        ("AI Voice Screenings:", "Conversational voice agents for brief initial communication checks.")
    ]
    for title, desc in future_items:
        p = tf_r.add_paragraph()
        p.space_after = Pt(5)
        r1 = p.add_run()
        r1.text = "• " + title + " "
        r1.font.bold = True
        r1.font.size = Pt(9.5)
        r1.font.color.rgb = COLOR_TEXT_MUTED
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(9)
        r2.font.color.rgb = COLOR_TEXT_DIM

    p_fnote = tf_r.add_paragraph()
    p_fnote.text = "\nHonest Scope: In our prototype, scores are transparently labeled 'AI-Assessed Skill Confidence' — we do not claim university accreditation."
    p_fnote.font.name = FONT_BODY
    p_fnote.font.size = Pt(8.5)
    p_fnote.font.color.rgb = COLOR_TEXT_MUTED


def build_slide_10_risks(prs):
    """Slide 6 (Old Slide 10): Realistic Challenges & Practical Mitigations - 2x2 Easy-to-Explain Cards"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)
    add_header(slide, "Common Challenges & Practical Defenses",
               "Direct, engineered solutions to the four most common questions in AI-based hiring.")

    cards_data = [
        {
            "num": "01",
            "tag": "EXAGGERATED RESUMES",
            "question": "“Can't candidates just put buzzwords on a resume?”",
            "sol_title": "Test, Don't Trust",
            "sol_desc": "Resume claims are treated strictly as unverified hypotheses. A skill is never credited until proven in a hands-on scenario assessment.",
            "col": COLOR_AMBER
        },
        {
            "num": "02",
            "tag": "CHEATING & CHATGPT",
            "question": "“Can't candidates copy-paste questions into AI?”",
            "sol_title": "90s Timed Scenario Solving",
            "sol_desc": "Fast 90-second countdowns per question with practical code-debugging scenarios testing conceptual logic, not textbook recall.",
            "col": COLOR_ROSE
        },
        {
            "num": "03",
            "tag": "GRADING CONSISTENCY",
            "question": "“Does AI grade every candidate fairly and equally?”",
            "sol_title": "Standardized Rubrics",
            "sol_desc": "Assessments follow fixed scoring rubrics and deterministic evaluation rules. Every candidate is judged against the exact same benchmark.",
            "col": COLOR_CYAN
        },
        {
            "num": "04",
            "tag": "COLLEGE & HIRING BIAS",
            "question": "“Do Tier-3 students still face brand bias?”",
            "sol_title": "100% Blind Capability Matching",
            "sol_desc": "College tier, photo, gender, and background are excluded from candidate ranking. Hiring fit is driven entirely by demonstrated ability.",
            "col": COLOR_EMERALD
        }
    ]

    card_w = Inches(5.65)
    card_h = Inches(2.40)
    col_xs = [Inches(0.8), Inches(6.85)]
    row_ys = [Inches(1.85), Inches(4.50)]

    for idx, data in enumerate(cards_data):
        cx = col_xs[idx % 2]
        cy = row_ys[idx // 2]

        # Outer Card
        add_card(slide, cx, cy, card_w, card_h, bg_color=COLOR_CARD_BG, border_color=data["col"])

        tb = slide.shapes.add_textbox(cx + Inches(0.24), cy + Inches(0.18), card_w - Inches(0.48), card_h - Inches(0.36))
        tf = tb.text_frame
        tf.word_wrap = True
        tf.margin_left = tf.margin_top = tf.margin_right = tf.margin_bottom = 0

        # Header: Tag + Number
        p_h = tf.paragraphs[0]
        p_h.text = f"{data['num']}  •  {data['tag']}"
        p_h.font.name = FONT_MONO
        p_h.font.size = Pt(10)
        p_h.font.bold = True
        p_h.font.color.rgb = data["col"]

        # Judge Question
        p_q = tf.add_paragraph()
        p_q.text = data["question"]
        p_q.font.name = FONT_HEADING
        p_q.font.size = Pt(13)
        p_q.font.bold = True
        p_q.font.color.rgb = COLOR_TEXT_WHITE
        p_q.space_before = Pt(3)
        p_q.space_after = Pt(7)

        # Solution Title with checkmark
        p_sol = tf.add_paragraph()
        r_check = p_sol.add_run()
        r_check.text = "✓ OUR DEFENSE: " + data["sol_title"] + "\n"
        r_check.font.bold = True
        r_check.font.size = Pt(10.5)
        r_check.font.color.rgb = COLOR_EMERALD if data["col"] != COLOR_EMERALD else COLOR_PRIMARY_LIGHT

        # Solution Description
        r_desc = p_sol.add_run()
        r_desc.text = data["sol_desc"]
        r_desc.font.size = Pt(9.5)
        r_desc.font.color.rgb = COLOR_TEXT_LIGHT


def build_slide_11_impact(prs):
    """Slide 11: Who benefits and why does it matter?"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)
    add_header(slide, "Practical Impact Across the Workforce Ecosystem",
               "Observable, grounded benefits for candidates, employers, and the wider workforce.",
               "WHO BENEFITS AND WHY DOES IT MATTER?")

    col_w = Inches(3.7)
    col_h = Inches(4.7)
    top_y = Inches(1.9)

    # Column 1: For Youth
    add_card(slide, Inches(0.8), top_y, col_w, col_h, bg_color=COLOR_CARD_BG, border_color=COLOR_CYAN)
    tb_1 = slide.shapes.add_textbox(Inches(0.95), top_y + Inches(0.18), col_w - Inches(0.3), col_h - Inches(0.36))
    tf_1 = tb_1.text_frame
    tf_1.word_wrap = True

    p_1h = tf_1.paragraphs[0]
    p_1h.text = "FOR SKILLED YOUTH"
    p_1h.font.name = FONT_HEADING
    p_1h.font.size = Pt(12)
    p_1h.font.bold = True
    p_1h.font.color.rgb = COLOR_CYAN
    p_1h.space_after = Pt(10)

    y_points = [
        ("Understand actual strengths:", "Objective skill verification that proves capability beyond self-reported resumes."),
        ("Identify skill gaps:", "Clear diagnostic feedback replacing ghosting and silent rejections."),
        ("Know what to learn next:", "Actionable 4-week roadmap directly linked to live job vacancies."),
        ("Find more suitable opportunities:", "Apply with clarity on how your assessed skills match employer requirements.")
    ]
    for title, desc in y_points:
        p = tf_1.add_paragraph()
        p.space_after = Pt(7)
        r1 = p.add_run()
        r1.text = "• " + title + " "
        r1.font.bold = True
        r1.font.size = Pt(10)
        r1.font.color.rgb = COLOR_TEXT_WHITE
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(9.5)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    # Column 2: For MSMEs
    add_card(slide, Inches(4.8), top_y, col_w, col_h, bg_color=COLOR_CARD_BG, border_color=COLOR_AMBER)
    tb_2 = slide.shapes.add_textbox(Inches(4.95), top_y + Inches(0.18), col_w - Inches(0.3), col_h - Inches(0.36))
    tf_2 = tb_2.text_frame
    tf_2.word_wrap = True

    p_2h = tf_2.paragraphs[0]
    p_2h.text = "FOR MSMES & STARTUPS"
    p_2h.font.name = FONT_HEADING
    p_2h.font.size = Pt(12)
    p_2h.font.bold = True
    p_2h.font.color.rgb = COLOR_AMBER
    p_2h.space_after = Pt(10)

    m_points = [
        ("Reduce manual screening effort:", "Pre-ranked applicant pipeline filtered by demonstrated competence."),
        ("Compare candidates more clearly:", "Evaluate applicants on standardized skill scorecards instead of buzzwords."),
        ("View assessed skill evidence:", "Inspect practical capability checks before scheduling formal interviews."),
        ("Support faster shortlisting:", "Lightweight technology stack with low infrastructure requirements.")
    ]
    for title, desc in m_points:
        p = tf_2.add_paragraph()
        p.space_after = Pt(7)
        r1 = p.add_run()
        r1.text = "• " + title + " "
        r1.font.bold = True
        r1.font.size = Pt(10)
        r1.font.color.rgb = COLOR_TEXT_WHITE
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(9.5)
        r2.font.color.rgb = COLOR_TEXT_MUTED

    # Column 3: The Bigger Picture
    add_card(slide, Inches(8.8), top_y, col_w, col_h, bg_color=COLOR_CARD_ALT, border_color=COLOR_EMERALD)
    tb_3 = slide.shapes.add_textbox(Inches(8.95), top_y + Inches(0.18), col_w - Inches(0.3), col_h - Inches(0.36))
    tf_3 = tb_3.text_frame
    tf_3.word_wrap = True

    p_3h = tf_3.paragraphs[0]
    p_3h.text = "WIDER WORKFORCE IMPACT"
    p_3h.font.name = FONT_HEADING
    p_3h.font.size = Pt(12)
    p_3h.font.bold = True
    p_3h.font.color.rgb = COLOR_EMERALD
    p_3h.space_after = Pt(10)

    b_points = [
        ("Supporting Skill-First Hiring:", "Encouraging a practical shift from degree-centric credentials toward demonstrated ability."),
        ("Tier-2 & Tier-3 Inclusion:", "Connecting capable graduates from regional institutions directly to open MSME roles."),
        ("Reduce Skill Mismatch:", "Aligning candidate learning directly with actual unfilled vacancies in small businesses."),
        ("Encourage Continuous Upskilling:", "Providing a repeatable cycle where assessments lead to concrete skill improvement.")
    ]
    for title, desc in b_points:
        p = tf_3.add_paragraph()
        p.space_after = Pt(7)
        r1 = p.add_run()
        r1.text = "• " + title + " "
        r1.font.bold = True
        r1.font.size = Pt(10)
        r1.font.color.rgb = COLOR_TEXT_WHITE
        r2 = p.add_run()
        r2.text = desc
        r2.font.size = Pt(9.5)
        r2.font.color.rgb = COLOR_TEXT_MUTED


def build_slide_12_closing(prs):
    """Slide 12: Memorable Ending / Summary"""
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    apply_slide_bg(slide)

    # Big Banner Name
    name_box = slide.shapes.add_textbox(Inches(1.0), Inches(1.15), Inches(11.33), Inches(1.0))
    tf_name = name_box.text_frame
    p_name = tf_name.paragraphs[0]
    p_name.text = "SkillBridge AI"
    p_name.font.name = FONT_HEADING
    p_name.font.size = Pt(48)
    p_name.font.bold = True
    p_name.font.color.rgb = COLOR_TEXT_WHITE
    p_name.alignment = PP_ALIGN.CENTER

    # Tagline
    tagline_box = slide.shapes.add_textbox(Inches(1.0), Inches(2.25), Inches(11.33), Inches(0.55))
    tf_tagline = tagline_box.text_frame
    p_tagline = tf_tagline.paragraphs[0]
    p_tagline.text = "Prove your skills. Find your fit. Become job-ready."
    p_tagline.font.name = FONT_HEADING
    p_tagline.font.size = Pt(22)
    p_tagline.font.bold = True
    p_tagline.font.color.rgb = COLOR_EMERALD
    p_tagline.alignment = PP_ALIGN.CENTER

    # Core Product Loop Center Box
    add_card(slide, Inches(1.5), Inches(3.05), Inches(10.33), Inches(1.65), bg_color=COLOR_CARD_BG, border_color=COLOR_PRIMARY)
    tb_c = slide.shapes.add_textbox(Inches(1.7), Inches(3.18), Inches(9.93), Inches(1.35))
    tf_c = tb_c.text_frame
    tf_c.word_wrap = True

    p_ch = tf_c.paragraphs[0]
    p_ch.text = "THE REINFORCING WORKFORCE LOOP"
    p_ch.font.name = FONT_MONO
    p_ch.font.size = Pt(11)
    p_ch.font.bold = True
    p_ch.font.color.rgb = COLOR_AMBER
    p_ch.alignment = PP_ALIGN.CENTER

    p_cb = tf_c.add_paragraph()
    p_cb.text = "ASSESS   ──►   MATCH   ──►   IMPROVE   ──►   REASSESS"
    p_cb.font.name = FONT_MONO
    p_cb.font.size = Pt(17)
    p_cb.font.bold = True
    p_cb.font.color.rgb = COLOR_TEXT_WHITE
    p_cb.alignment = PP_ALIGN.CENTER
    p_cb.space_before = Pt(6)

    p_ce = tf_c.add_paragraph()
    p_ce.text = "Candidate (Arjun: 71% ──► 92% Projected)   •   SkillBridge AI Platform   •   MSME Employer (TechNova)"
    p_ce.font.name = FONT_BODY
    p_ce.font.size = Pt(10)
    p_ce.font.color.rgb = COLOR_TEXT_MUTED
    p_ce.alignment = PP_ALIGN.CENTER
    p_ce.space_before = Pt(4)

    p_cdisc = tf_c.add_paragraph()
    p_cdisc.text = "* Projected fit based on simulated skill improvements — not a hiring guarantee."
    p_cdisc.font.name = FONT_BODY
    p_cdisc.font.size = Pt(8.5)
    p_cdisc.font.color.rgb = COLOR_TEXT_DIM
    p_cdisc.alignment = PP_ALIGN.CENTER
    p_cdisc.space_before = Pt(2)

    # Live Demo Invitation Box
    add_card(slide, Inches(1.5), Inches(4.95), Inches(10.33), Inches(1.55), bg_color=COLOR_CARD_ALT, border_color=COLOR_EMERALD)
    tb_d = slide.shapes.add_textbox(Inches(1.7), Inches(5.1), Inches(9.93), Inches(1.25))
    tf_d = tb_d.text_frame
    tf_d.word_wrap = True

    p_dh = tf_d.paragraphs[0]
    p_dh.text = "READY FOR LIVE DEMONSTRATION"
    p_dh.font.name = FONT_HEADING
    p_dh.font.size = Pt(14)
    p_dh.font.bold = True
    p_dh.font.color.rgb = COLOR_EMERALD
    p_dh.alignment = PP_ALIGN.CENTER

    p_db = tf_d.add_paragraph()
    p_db.text = "We invite the judges to inspect the working local prototype:\n1-Click Demo Login  •  Live AI Skill Assessment  •  Interactive What-If Simulator (71% → 92% Projected)"
    p_db.font.name = FONT_BODY
    p_db.font.size = Pt(11)
    p_db.font.color.rgb = COLOR_TEXT_LIGHT
    p_db.alignment = PP_ALIGN.CENTER
    p_db.space_before = Pt(4)


def main():
    print("[SkillBridge AI] Initializing 16:9 Widescreen Final v2 Presentation...")
    prs = Presentation()
    
    # 16:9 Widescreen Dimensions
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    print("  -> Building Slide 1: What is SkillBridge AI? (Title & Value Prop)...")
    build_slide_1_title(prs)

    print("  -> Building Slide 2: What problem are we solving? (The Proof Gap)...")
    build_slide_2_problem(prs)

    print("  -> Building Slide 3: What is our solution? (7-Stage Pipeline)...")
    build_slide_3_solution(prs)

    print("  -> Building Slide 4: How it works for one candidate? (Arjun's 71% -> 92% Story)...")
    build_slide_4_human_story(prs)

    print("  -> Building Slide 5 (Old 8): How does matching actually work? (Scorecard & Formula)...")
    build_slide_8_matching_logic(prs)

    print("  -> Building Slide 6 (Old 10): What could go wrong? (Realistic Risks & Mitigations)...")
    build_slide_10_risks(prs)

    print("  -> Building Slide 7 (Old 12): Memorable Ending / Summary (Live Demo Hand-off)...")
    build_slide_12_closing(prs)

    print(f"\nTotal Slides Built: {len(prs.slides)}")

    targets = [
        "SkillBridge_AI_Hackathon_Presentation_Final_v3.pptx",
        "SkillBridge_AI_Hackathon_Presentation_Final_v2.pptx",
        "SkillBridge_AI_Hackathon_Presentation_Final.pptx",
        "SkillBridge_AI_Hackathon_Presentation.pptx"
    ]
    for target in targets:
        try:
            out_path = os.path.abspath(target)
            prs.save(out_path)
            print(f"  [SUCCESS] Saved presentation to: {target}")
        except PermissionError:
            print(f"  [NOTICE] {target} is currently open in WPS Office/PowerPoint. (Saved to unlocked targets)")
        except Exception as e:
            print(f"  [ERROR] Could not save {target}: {e}")


if __name__ == "__main__":
    main()
