import os
import io
import json
from app import app, db
from models import User, Skill, Job, JobSkill, Application, Assessment

def run_e2e():
    print("==================================================")
    print("STARTING FULL END-TO-END VERIFICATION FLOW")
    print("==================================================")

    client = app.test_client()

    # 1. Test Demo Candidate Login
    print("\n[Step 1] Testing Demo Candidate 1-Click Login...")
    res = client.get('/demo-login/candidate', follow_redirects=True)
    assert res.status_code == 200
    assert b"Aditya Sen" in res.data
    print("  -> Logged in as Aditya Sen (Demo Candidate)")

    # 2. Test Candidate Dashboard
    print("\n[Step 2] Testing Candidate Dashboard Metrics...")
    res = client.get('/candidate/dashboard')
    assert res.status_code == 200
    assert b"Job Readiness Score" in res.data
    assert b"My Skills" in res.data
    assert b"Recommended Jobs" in res.data
    print("  -> Dashboard loaded with live readiness gauge and recommendations")

    # 3. Test Taking an Assessment
    print("\n[Step 3] Testing AI Skill Assessment (Python)...")
    res = client.get('/candidate/assessment/Python')
    assert res.status_code == 200
    assert b"Python Skill Verification" in res.data
    
    # Submit assessment
    res = client.post('/candidate/assessment/Python/submit', data={
        "question_1": "1",
        "question_2": "1",
        "question_3": "1",
        "question_4": "1",
        "question_5": "0"  # 4 out of 5 correct
    })
    assert res.status_code == 200
    assert b"Assessment Result" in res.data
    assert b"Intermediate" in res.data or b"Advanced" in res.data
    print("  -> Assessment graded and recorded with verified capability badge")

    # 4. Test Resume Upload & AI Skill Extraction
    print("\n[Step 4] Testing Resume Upload & AI Skill Extraction...")
    sample_resume = (
        "ADITYA SEN\nEmail: demo.candidate@example.com\n"
        "Education: B.Tech in Computer Science, 2024\n"
        "Experience: Backend Intern at Tech Solutions (6 months)\n"
        "Skills: Python, SQL, Flask, REST APIs, Git, Docker, Linux\n"
        "Projects: Built RESTful E-Commerce Microservice with SQLite"
    )
    data = {
        'resume': (io.BytesIO(sample_resume.encode('utf-8')), 'test_resume.txt')
    }
    res = client.post('/candidate/upload-resume', data=data, content_type='multipart/form-data', follow_redirects=True)
    assert res.status_code == 200
    assert b"AI Skill Extraction Complete" in res.data
    print("  -> Resume parsed with technical skills, education, and experience")

    # Save extracted skills
    res = client.post('/candidate/save-extracted-skills', data={
        'skill_name': ['Python', 'SQL', 'Flask', 'Docker', 'Linux'],
        'skill_level': ['Intermediate', 'Intermediate', 'Intermediate', 'Basic', 'Basic']
    }, follow_redirects=True)
    assert res.status_code == 200
    print("  -> Extracted skills successfully saved to candidate profile")

    # 5. Test Job Matching & Job Detail
    print("\n[Step 5] Testing Job Detail & Explainable Match Breakdown...")
    with app.app_context():
        job = Job.query.filter_by(title="Junior Backend Developer").first()
        job_id = job.id

    res = client.get(f'/candidate/jobs/{job_id}')
    assert res.status_code == 200
    assert b"Capability Matrix Comparison" in res.data
    assert b"Why You Match" in res.data
    assert b"What You're Missing" in res.data
    print("  -> Side-by-side skill matrix rendered with explainability callouts")

    # 6. Test Personalized Roadmap
    print("\n[Step 6] Testing Personalized 4-Step Upskilling Roadmap...")
    res = client.get(f'/candidate/roadmap/{job_id}')
    assert res.status_code == 200
    assert b"Your Path to Job Readiness" in res.data
    assert b"Step-by-Step Personalized Upskilling Milestones" in res.data
    print("  -> 4-step progressive roadmap generated focusing on exact gaps")

    # 7. Test Signature Feature: Job Readiness Simulator
    print("\n[Step 7] Testing Signature Feature: Job Readiness Simulator...")
    res = client.get(f'/candidate/simulation/{job_id}')
    assert res.status_code == 200
    assert b"Job Readiness Simulator" in res.data
    assert b"Current Match" in res.data
    assert b"Projected Match" in res.data

    # Test AJAX Slider Recalculation (REST API: 42 -> 65, Git: 35 -> 55)
    res = client.post('/api/simulate-match', json={
        "job_id": job_id,
        "simulated_scores": {"rest api": 65, "git": 55}
    })
    assert res.status_code == 200
    sim_data = json.loads(res.data)
    assert sim_data["match_score"] >= 88
    print(f"  -> Simulator recalculated match score: {sim_data['match_score']}% (Projected gain: +18-20%)")

    # 8. Test Applying to Job
    print("\n[Step 8] Testing Application Submission...")
    res = client.post(f'/candidate/apply/{job_id}', follow_redirects=True)
    assert res.status_code == 200
    print("  -> Application submitted with verified capability profile")

    # 9. Test Switching to MSME Employer
    print("\n[Step 9] Testing MSME Employer 1-Click Login...")
    res = client.get('/demo-login/employer', follow_redirects=True)
    assert res.status_code == 200
    assert b"TechNova Solutions" in res.data
    assert b"Active Job Openings" in res.data
    print("  -> Logged in as Vikram Mehta at TechNova Solutions")

    # 10. Test Candidate Ranking
    print("\n[Step 10] Testing Employer Candidate Ranking...")
    res = client.get(f'/employer/jobs/{job_id}/candidates')
    assert res.status_code == 200
    assert b"Ranked Candidates" in res.data
    assert b"Rahul Sharma" in res.data
    assert b"Aditya Sen" in res.data
    print("  -> Candidates ranked in sorted order by explainable capability fit")

    # 11. Test Employer Candidate Detail & Shortlisting
    print("\n[Step 11] Testing Employer Candidate Detail & Status Update...")
    with app.app_context():
        cand = User.query.filter_by(email="demo.candidate@example.com").first()
        app_rec = Application.query.filter_by(user_id=cand.id, job_id=job_id).first()
        app_id = app_rec.id

    res = client.get(f'/employer/candidates/{cand.id}/job/{job_id}')
    assert res.status_code == 200
    assert b"AI Candidate Capability Summary" in res.data

    # Update status to Shortlisted
    res = client.post(f'/employer/application/{app_id}/status', data={"status": "Shortlisted"}, follow_redirects=True)
    assert res.status_code == 200
    assert b"Shortlisted" in res.data
    print("  -> Application successfully updated to 'Shortlisted'")

    # 12. Test AI Job Creator
    print("\n[Step 12] Testing Employer AI Job Creation...")
    new_job_desc = "Looking for a Full Stack React & Python Developer with SQL, REST APIs and Git."
    res = client.post('/employer/jobs/create', data={
        "title": "Full Stack React Developer",
        "location": "Chennai / Remote",
        "experience_level": "1 - 3 Years",
        "description": new_job_desc,
        "skill_name": ["Python", "React", "SQL", "REST API", "Git"],
        "required_score": ["75", "70", "65", "65", "55"],
        "skill_weight": ["1.5", "1.5", "1.2", "1.2", "1.0"]
    }, follow_redirects=True)
    assert res.status_code == 200
    print("  -> New job published with structured AI capability weights")

    print("\n==================================================")
    print("ALL 12 END-TO-END DEMO FLOWS PASSED SUCCESSFULLY!")
    print("==================================================")

if __name__ == "__main__":
    run_e2e()
