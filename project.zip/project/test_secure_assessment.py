import os
import json
import unittest
from datetime import datetime, timezone, timedelta

from app import app, db
from models import (
    User, Skill, Job, Assessment, AssessmentAttempt, AttemptAnswer, IntegrityEvent
)
from services.assessment_service import assessment_service


class TestSecureAssessment(unittest.TestCase):
    def setUp(self):
        self.app = app
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()

        with self.app.app_context():
            # Login demo candidate
            self.client.get('/demo-login/candidate', follow_redirects=True)
            self.candidate = User.query.filter_by(role='candidate').first()

    def test_01_start_screen_and_consent_requirement(self):
        """Test assessment start screen and rules consent gating."""
        # 1. View start screen
        res = self.client.get('/candidate/assessment/Python')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Python Skill Verification", res.data)
        self.assertIn(b"Assessment Protocol", res.data)
        self.assertIn(b"rules_consent", res.data)

        # 2. Try starting without consent
        res = self.client.post('/assessment/Python/begin', data={}, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"You must review and agree to the assessment protocol rules", res.data)

        # 3. Start with consent
        res = self.client.post('/assessment/Python/begin', data={'rules_consent': '1'}, follow_redirects=False)
        self.assertEqual(res.status_code, 302)
        self.assertIn('/assessment/attempt/', res.headers['Location'])

    def test_02_server_side_answer_hiding(self):
        """Test that answer keys and explanations are never exposed to candidate during test."""
        with self.app.app_context():
            candidate = User.query.filter_by(role='candidate').first()
            attempt = assessment_service.create_attempt(candidate, 'Python')
            attempt_id = attempt.id

        # Fetch question page
        res = self.client.get(f'/assessment/attempt/{attempt_id}/question')
        self.assertEqual(res.status_code, 200)

        # Verify question is displayed
        self.assertIn(b"Question 1 of 5", res.data)
        self.assertIn(b"selected_option", res.data)

        # Ensure correct_option and explanation are NOT in payload
        with self.app.app_context():
            att = db.session.get(AssessmentAttempt, attempt_id)
            payload = assessment_service.get_current_question_payload(att)
            self.assertNotIn('correct_option', payload)
            self.assertNotIn('explanation', payload)
            self.assertIn('question_text', payload)
            self.assertIn('options', payload)
            self.assertIn('difficulty', payload)
            self.assertEqual(len(payload['options']), 4)

    def test_03_tamper_resistance_and_ownership(self):
        """Test unauthorized user cannot access or submit to another user's attempt."""
        with self.app.app_context():
            # Create attempt for candidate
            candidate = User.query.filter_by(role='candidate').first()
            attempt = assessment_service.create_attempt(candidate, 'SQL')
            attempt_id = attempt.id

        # Log in as employer
        self.client.get('/demo-login/employer', follow_redirects=True)

        # Employer tries to view or answer candidate's attempt
        res = self.client.get(f'/assessment/attempt/{attempt_id}/question')
        # Employer required decorator redirects or aborts 403
        self.assertTrue(res.status_code in (302, 403))

    def test_04_answer_locking_and_duplicate_rejection(self):
        """Test that submitting an answer locks it and prevents tampering."""
        with self.app.app_context():
            candidate = User.query.filter_by(role='candidate').first()
            attempt = assessment_service.create_attempt(candidate, 'Git')
            attempt_id = attempt.id

        # Submit answer to question 1
        res = self.client.post(f'/assessment/attempt/{attempt_id}/answer', data={
            'question_index': '1',
            'selected_option': '1'
        }, follow_redirects=False)
        self.assertEqual(res.status_code, 302)

        # Try submitting answer again to question 1
        with self.app.app_context():
            att = db.session.get(AssessmentAttempt, attempt_id)
            initial_count = att.answers.count()
            # Attempt to resubmit same question
            assessment_service.submit_attempt_answer(att, 1, 2)
            self.assertEqual(att.answers.count(), initial_count, "Duplicate submission must not create new answer")

    def test_05_integrity_events_and_scoring(self):
        """Test anti-cheat signals: tab switch, blur, fullscreen exit, and copy attempts."""
        with self.app.app_context():
            candidate = User.query.filter_by(role='candidate').first()
            attempt = assessment_service.create_attempt(candidate, 'Flask')
            attempt_id = attempt.id
            self.assertEqual(attempt.integrity_score, 100)
            self.assertEqual(attempt.integrity_status, 'normal')

        # Send TAB_SWITCH event
        res = self.client.post(
            f'/assessment/attempt/{attempt_id}/integrity-event',
            data=json.dumps({'event_type': 'TAB_SWITCH', 'metadata': {'time': '10s'}}),
            content_type='application/json'
        )
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertEqual(data['integrity_score'], 88)
        self.assertEqual(data['integrity_status'], 'normal')

        # Send multiple events to trigger 'review' status
        self.client.post(
            f'/assessment/attempt/{attempt_id}/integrity-event',
            data=json.dumps({'event_type': 'FULLSCREEN_EXIT', 'metadata': {}}),
            content_type='application/json'
        )
        self.client.post(
            f'/assessment/attempt/{attempt_id}/integrity-event',
            data=json.dumps({'event_type': 'TAB_SWITCH', 'metadata': {}}),
            content_type='application/json'
        )
        res = self.client.post(
            f'/assessment/attempt/{attempt_id}/integrity-event',
            data=json.dumps({'event_type': 'COPY_ATTEMPT', 'metadata': {}}),
            content_type='application/json'
        )
        data = res.get_json()
        self.assertLessEqual(data['integrity_score'], 70)
        self.assertEqual(data['integrity_status'], 'review')

    def test_06_adaptive_difficulty_progression(self):
        """Test that correct answers promote difficulty and incorrect answers demote."""
        with self.app.app_context():
            candidate = User.query.filter_by(role='candidate').first()
            attempt = assessment_service.create_attempt(candidate, 'Python')

            # Initial difficulty is medium
            self.assertEqual(attempt.current_difficulty, 'medium')

            # Submit correct answer for Q1
            q1 = attempt.assigned_questions[0]
            correct_opt = q1['correct_option']
            res = assessment_service.submit_attempt_answer(attempt, 1, correct_opt)
            # Should escalate to hard
            self.assertEqual(attempt.current_difficulty, 'hard')

            # Submit wrong answer for Q2
            q2 = attempt.assigned_questions[1]
            q2_correct = q2['correct_option']
            wrong_opt = (q2_correct + 1) % len(q2['options'])
            res = assessment_service.submit_attempt_answer(attempt, 2, wrong_opt)
            # Should demote back to medium
            self.assertEqual(attempt.current_difficulty, 'medium')

    def test_07_full_assessment_flow_and_result_review(self):
        """Test completing all 5 questions, score finalization, and solution review unlocking."""
        with self.app.app_context():
            candidate = User.query.filter_by(role='candidate').first()
            candidate_id = candidate.id
            attempt = assessment_service.create_attempt(candidate, 'REST API')
            attempt_id = attempt.id

        # Answer all 5 questions
        for q_idx in range(1, 6):
            res = self.client.post(f'/assessment/attempt/{attempt_id}/answer', data={
                'question_index': str(q_idx),
                'selected_option': '0'
            }, follow_redirects=True)
            self.assertEqual(res.status_code, 200)

        # Final result page
        res = self.client.get(f'/assessment/attempt/{attempt_id}/result')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"REST API Assessment Result", res.data)
        self.assertIn(b"AI Skill Confidence", res.data)
        self.assertIn(b"Assessment Integrity", res.data)
        self.assertIn(b"Difficulty Adaptation:", res.data)
        self.assertIn(b"Question & Solution Review", res.data)

        # Check DB records
        with self.app.app_context():
            att = db.session.get(AssessmentAttempt, attempt_id)
            self.assertEqual(att.status, 'completed')
            self.assertIsNotNone(att.completed_at)

            # Check linked Assessment record
            assessment = Assessment.query.filter_by(user_id=candidate_id, skill_name='REST API').order_by(Assessment.created_at.desc()).first()
            self.assertIsNotNone(assessment)
            self.assertIn(assessment.confidence_level, ['High', 'Moderate', 'Developing'])
            self.assertIsNotNone(assessment.adaptive_path)

    def test_08_employer_view_shows_verified_assessment_summary(self):
        """Test that employer view displays verified assessment, integrity status, and confidence."""
        # Log in as employer
        self.client.get('/demo-login/employer', follow_redirects=True)

        with self.app.app_context():
            candidate = User.query.filter_by(role='candidate').first()
            job = Job.query.first()
            job_id = job.id
            cand_id = candidate.id

        res = self.client.get(f'/employer/candidates/{cand_id}/job/{job_id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Verified Assessment", res.data)
        self.assertIn(b"Integrity Overview", res.data)
        self.assertIn(b"Mean Assessed Score", res.data)
        self.assertIn(b"AI Skill Confidence", res.data)
        self.assertIn(b"Assessment Integrity", res.data)


if __name__ == '__main__':
    unittest.main()
