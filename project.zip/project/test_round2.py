import unittest
import json
from app import app, db
from models import User, Job, Skill, Notification, CareerProgress, Application
from services.matching_service import matching_service
from services.ai_service import ai_service
from seed_data import reset_demo_candidate, seed_database


class TestRound2Features(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.client = app.test_client()
        with app.app_context():
            reset_demo_candidate()

    def test_feature1_career_readiness_dashboard(self):
        with app.app_context():
            candidate = User.query.filter_by(email='demo.candidate@example.com').first()
            self.assertIsNotNone(candidate)
            target_job = Job.query.filter_by(title='Junior Backend Developer').first()
            self.assertIsNotNone(target_job)

            # Test calculation service
            readiness = matching_service.calculate_readiness_breakdown(candidate, target_job)
            self.assertIn('overall_score', readiness)
            self.assertIn('pillars', readiness)
            self.assertIn('strongest_skills', readiness)
            self.assertIn('skills_holding_back', readiness)
            self.assertIn('next_best_action', readiness)

            # Check 4 pillars
            pillars = readiness['pillars']
            self.assertIn('technical_skills', pillars)
            self.assertIn('role_fit', pillars)
            self.assertIn('assessment_confidence', pillars)
            self.assertIn('skill_evidence', pillars)

            # Check career progress records
            progress_items = CareerProgress.query.filter_by(user_id=candidate.id).all()
            self.assertGreaterEqual(len(progress_items), 1)

        # Login and check candidate dashboard UI
        self.client.get('/demo-login/candidate', follow_redirects=True)
        res = self.client.get('/candidate/dashboard')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"SkillBridge Job Readiness Score", res.data)
        self.assertIn(b"Technical Skills", res.data)
        self.assertIn(b"Role Fit", res.data)
        self.assertIn(b"Assessment Confidence", res.data)
        self.assertIn(b"Skill Evidence", res.data)
        self.assertIn(b"Next Best Action", res.data)
        self.assertIn(b"Career Progress", res.data)

    def test_feature2_smart_notifications(self):
        with app.app_context():
            candidate = User.query.filter_by(email='demo.candidate@example.com').first()
            self.assertIsNotNone(candidate)
            cand_id = candidate.id
            # Ensure candidate has notifications
            unread_before = Notification.query.filter_by(user_id=cand_id, is_read=False).count()
            self.assertGreaterEqual(unread_before, 1)

            # Create a test notification
            test_notif = Notification(
                user_id=cand_id,
                title="Test Alert",
                message="Testing notification dispatch system",
                type="skill_gap",
                link="/candidate/dashboard"
            )
            db.session.add(test_notif)
            db.session.commit()
            test_notif_id = test_notif.id

        # Candidate login
        self.client.get('/demo-login/candidate', follow_redirects=True)

        # 1. Test unread count API
        res = self.client.get('/api/notifications/unread-count')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertIn('unread_count', data)
        self.assertGreaterEqual(data['unread_count'], 1)

        # 2. Test Notification Center view
        res = self.client.get('/notifications')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Notification Center", res.data)
        self.assertIn(b"Test Alert", res.data)

        # 3. Test mark single notification as read
        res = self.client.get(f'/notifications/mark-read/{test_notif_id}', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        with app.app_context():
            updated = db.session.get(Notification, test_notif_id)
            self.assertTrue(updated.is_read)

        # 4. Test mark all as read
        res = self.client.get('/notifications/mark-all-read', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        with app.app_context():
            remaining_unread = Notification.query.filter_by(user_id=cand_id, is_read=False).count()
            self.assertEqual(remaining_unread, 0)

    def test_feature3_employer_ai_interview_assistant(self):
        # 1. Test AI question generator service
        questions = ai_service.generate_interview_questions(
            candidate_name="Arjun Patel",
            job_title="Junior Backend Developer",
            strengths=["Python", "SQL"],
            gaps=["REST API Design", "Git & Version Control"]
        )
        self.assertIsInstance(questions, list)
        self.assertGreaterEqual(len(questions), 3)
        self.assertIn("question", questions[0])
        self.assertIn("skill_target", questions[0])

        # Login as employer to authorize API call
        self.client.get('/demo-login/employer', follow_redirects=True)

        # 2. Test AI answer evaluation endpoint
        eval_payload = {
            "question": "How would you design a REST API with rate limiting?",
            "answer": "I would use Redis with a sliding window counter token bucket algorithm and return 429 Too Many Requests.",
            "job_title": "Junior Backend Developer"
        }
        res = self.client.post(
            '/api/evaluate-interview-answer',
            data=json.dumps(eval_payload),
            content_type='application/json'
        )
        self.assertEqual(res.status_code, 200)
        eval_data = json.loads(res.data)
        self.assertIn('score', eval_data)
        self.assertIn('rating', eval_data)
        self.assertIn('strengths', eval_data)
        self.assertIn('improvements', eval_data)
        self.assertIn('disclaimer', eval_data)

        # 3. Test Employer Candidate Detail page rendering
        with app.app_context():
            candidate = User.query.filter_by(email='demo.candidate@example.com').first()
            job = Job.query.filter_by(title='Junior Backend Developer').first()
            cand_id = candidate.id
            job_id = job.id

        res = self.client.get(f'/employer/candidates/{cand_id}/job/{job_id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"AI Interview Assistant", res.data)
        self.assertIn(b"Live AI Answer Evaluation Form", res.data)

    def test_feature4_employer_candidate_comparison(self):
        with app.app_context():
            job = Job.query.filter_by(title='Junior Backend Developer').first()
            job_id = job.id

        # Login employer
        self.client.get('/demo-login/employer', follow_redirects=True)

        # Access comparison page
        res = self.client.get(f'/employer/jobs/{job_id}/compare')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"Candidate Comparison Matrix", res.data)
        self.assertIn(b"AI Candidate Comparison Synthesis", res.data)
        self.assertIn(b"Non-discriminatory evaluation", res.data)
        self.assertIn(b"Capability Matrix: Side-by-Side", res.data)

        # Test comparison AI service directly
        sample_candidates = [
            {"name": "Candidate A", "match_score": 85, "strengths": ["Python"], "gaps": ["Docker"]},
            {"name": "Candidate B", "match_score": 75, "strengths": ["Git"], "gaps": ["REST API"]}
        ]
        comparison_res = ai_service.generate_candidate_comparison("Backend Developer", sample_candidates)
        self.assertIn("summary", comparison_res)
        self.assertIn("rankings", comparison_res)

    def test_simulator_improvement_priorities(self):
        with app.app_context():
            candidate = User.query.filter_by(email='demo.candidate@example.com').first()
            job = Job.query.filter_by(title='Junior Backend Developer').first()
            job_id = job.id

            priorities = matching_service.calculate_skill_improvement_priorities(candidate, job)
            self.assertIsInstance(priorities, list)
            if priorities:
                self.assertIn('skill_name', priorities[0])
                self.assertIn('delta', priorities[0])
                self.assertIn('target_score', priorities[0])

        # Candidate simulation view
        self.client.get('/demo-login/candidate', follow_redirects=True)
        res = self.client.get(f'/candidate/simulation/{job_id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b"What Should I Improve First?", res.data)
        self.assertIn(b"ROI Ranking", res.data)


if __name__ == '__main__':
    unittest.main()
