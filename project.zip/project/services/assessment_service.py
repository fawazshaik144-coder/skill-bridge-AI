import json
import random
from datetime import datetime, timedelta, timezone
from models import (
    db, Skill, Assessment, AssessmentQuestion, AssessmentAttempt,
    AttemptAnswer, IntegrityEvent, CareerProgress, Notification
)
from services.ai_service import ai_service


class AssessmentService:
    def __init__(self):
        self.question_bank = self._build_question_bank()

    # =========================================================================
    # 1. SCENARIO QUESTION BANK BY DIFFICULTY (EASY / MEDIUM / HARD)
    # =========================================================================
    def _build_question_bank(self):
        return {
            "python": {
                "easy": [
                    {
                        "id": 101,
                        "type": "code_output",
                        "category": "Data Structures & Mutability",
                        "question": "What is the expected output of calling append_to(1) then append_to(2) when def append_to(element, target_list=[]): uses a default mutable argument?",
                        "code_snippet": "def append_to(element, target_list=[]):\n    target_list.append(element)\n    return target_list\n\nprint(append_to(1))\nprint(append_to(2))",
                        "options": [
                            "[1] then [2]",
                            "[1] then [1, 2]",
                            "[1] then []",
                            "TypeError: default parameter mutated"
                        ],
                        "correct_option": 1,
                        "explanation": "Default argument values in Python are evaluated once at function definition time, so mutable default arguments like lists are shared across all calls."
                    },
                    {
                        "id": 102,
                        "type": "mcq",
                        "category": "Memory & Built-in Types",
                        "question": "Which statement accurately characterizes why a Python tuple can be used as a dictionary key while a list cannot?",
                        "code_snippet": "",
                        "options": [
                            "Tuples execute faster because they use GPU registers",
                            "Tuples are immutable and hashable (if their items are hashable), while lists are mutable and unhashable",
                            "Tuples cannot contain heterogeneous data types",
                            "Lists are restricted to integer keys only"
                        ],
                        "correct_option": 1,
                        "explanation": "Dictionary keys require a deterministic, immutable hash value throughout their lifecycle; mutable lists cannot be hashed."
                    }
                ],
                "medium": [
                    {
                        "id": 103,
                        "type": "bug_fix",
                        "category": "Exception Handling & Resources",
                        "question": "Identify the critical flaw in using a bare 'except:' block without closing a file descriptor when reading large files:",
                        "code_snippet": "try:\n    f = open('data.csv', 'r')\n    records = [line.strip() for line in f]\n    avg = 100 / len(records)\nexcept:\n    print('Failed')\n    return None",
                        "options": [
                            "The list comprehension syntax is invalid in Python 3",
                            "A bare except catches BaseException (including KeyboardInterrupt) and leaks open file descriptors upon failure",
                            "Division by length automatically triggers an OverflowError",
                            "strip() cannot be invoked on raw file lines"
                        ],
                        "correct_option": 1,
                        "explanation": "A bare 'except:' catches system signals and leaks file descriptors; targeted exceptions with 'with open(...) as f:' must be used."
                    },
                    {
                        "id": 104,
                        "type": "conceptual",
                        "category": "OOP & Encapsulation",
                        "question": "In a Python class, what is the primary architectural purpose of the '@property' decorator?",
                        "code_snippet": "",
                        "options": [
                            "It executes the getter asynchronously in a background thread",
                            "It exposes getter/setter validation logic while maintaining standard dot-notation attribute access",
                            "It serializes class instances into a JSON dictionary string",
                            "It enforces compile-time C++ static typing"
                        ],
                        "correct_option": 1,
                        "explanation": "@property preserves backward-compatible attribute access while allowing data validation and computed properties."
                    }
                ],
                "hard": [
                    {
                        "id": 105,
                        "type": "scenario",
                        "category": "Memory & Lazy Evaluation",
                        "question": "You need to process a 15GB log file on an MSME server with only 2GB RAM. Which architectural approach prevents MemoryError?",
                        "code_snippet": "",
                        "options": [
                            "Read all lines using file.readlines() and process with multiprocessing",
                            "Use a Python generator with 'yield' to lazily stream line-by-line in O(1) memory space",
                            "Load the entire file into a Pandas DataFrame with chunksize=0",
                            "Read the entire file into a bytearray"
                        ],
                        "correct_option": 1,
                        "explanation": "Generators produce items lazily on-demand, enabling processing of multi-gigabyte files in continuous streams without consuming memory."
                    },
                    {
                        "id": 106,
                        "type": "scenario",
                        "category": "Concurrency & GIL",
                        "question": "A backend service has a CPU-bound image compression task. Why does Python's threading module fail to utilize multiple CPU cores, and what is the standard fix?",
                        "code_snippet": "",
                        "options": [
                            "Python threads are simulated in user-space; use asyncio instead",
                            "The Global Interpreter Lock (GIL) permits only one thread to execute Python bytecode at a time; use multiprocessing or native extensions",
                            "Operating systems limit Python processes to 1 core; modify kernel flags",
                            "Threading works on multiple cores only if NumPy is installed"
                        ],
                        "correct_option": 1,
                        "explanation": "The GIL prevents multi-core parallelism for CPU-bound Python threads; multiprocessing spawns distinct processes with separate GIL instances."
                    }
                ]
            },
            "rest api": {
                "easy": [
                    {
                        "id": 201,
                        "type": "mcq",
                        "category": "HTTP Status Codes",
                        "question": "Which HTTP status code should a RESTful endpoint return when a new user record is successfully persisted in the database?",
                        "code_snippet": "",
                        "options": [
                            "200 OK",
                            "201 Created",
                            "204 No Content",
                            "202 Accepted"
                        ],
                        "correct_option": 1,
                        "explanation": "201 Created signals that a new resource has been persisted, ideally providing a Location header referencing the resource."
                    },
                    {
                        "id": 202,
                        "type": "mcq",
                        "category": "HTTP Methods & Safety",
                        "question": "Which HTTP method is considered 'safe' according to RFC specifications (intended only for retrieval without modifying server state)?",
                        "code_snippet": "",
                        "options": [
                            "POST",
                            "GET",
                            "PATCH",
                            "DELETE"
                        ],
                        "correct_option": 1,
                        "explanation": "GET and HEAD are defined as safe methods because their execution does not create, mutate, or delete server resource state."
                    }
                ],
                "medium": [
                    {
                        "id": 203,
                        "type": "conceptual",
                        "category": "HTTP Verbs & Idempotence",
                        "question": "Why is PUT defined as idempotent in REST architecture, whereas standard non-conditional POST is not?",
                        "code_snippet": "",
                        "options": [
                            "PUT runs faster on HTTP/2 multiplexing",
                            "Executing an identical PUT request multiple times leaves the target resource in the exact same state as executing it once",
                            "PUT automatically encrypts payloads with AES-256",
                            "PUT can only modify single fields, not entire entities"
                        ],
                        "correct_option": 1,
                        "explanation": "An idempotent method yields identical server-state outcomes regardless of whether it is invoked once or repeated ten times."
                    },
                    {
                        "id": 204,
                        "type": "scenario",
                        "category": "Stateless Authentication",
                        "question": "When designing a stateless REST API, how should client authentication be conveyed in requests?",
                        "code_snippet": "",
                        "options": [
                            "By passing credentials in the URL query string '?auth=pass'",
                            "Via standard HTTP Authorization header using Bearer tokens (e.g. JWT or API keys)",
                            "By keeping an open stateful TCP socket to the session cache",
                            "By storing passwords in plaintext in the User-Agent header"
                        ],
                        "correct_option": 1,
                        "explanation": "Stateless APIs transmit signed bearer tokens in standard HTTP Authorization headers on every discrete request."
                    }
                ],
                "hard": [
                    {
                        "id": 205,
                        "type": "scenario",
                        "category": "Concurrency & Idempotency",
                        "question": "When a customer double-clicks 'Pay Now', two simultaneous POST requests reach /api/payments. How should the backend ensure the card is charged exactly once?",
                        "code_snippet": "",
                        "options": [
                            "Disable the submit button in frontend JavaScript and hope network does not retry",
                            "Require an 'Idempotency-Key' header cached in Redis with an atomic transaction so duplicate requests return the cached response",
                            "Rely on SQLite table auto-increment IDs",
                            "Delay every POST request by 5 seconds to let the first one finish"
                        ],
                        "correct_option": 1,
                        "explanation": "An Idempotency-Key combined with atomic distributed locking (e.g. Redis) prevents duplicate execution of critical non-idempotent operations."
                    },
                    {
                        "id": 206,
                        "type": "scenario",
                        "category": "Pagination & Scalability",
                        "question": "Why does 'OFFSET 1000000 LIMIT 20' degrade severely on relational databases, and what pattern solves it for high-scale REST APIs?",
                        "code_snippet": "",
                        "options": [
                            "OFFSET creates a memory leak in JSON parsers",
                            "The database must scan and discard 1,000,000 index rows before returning 20; use keyset/cursor-based pagination instead",
                            "Databases cannot index numbers greater than 65535",
                            "REST APIs cannot return more than 100 records per IP address"
                        ],
                        "correct_option": 1,
                        "explanation": "Offset pagination scans and discards preceding rows; cursor-based pagination uses indexed column boundaries to jump directly in O(1) time."
                    }
                ]
            },
            "sql": {
                "easy": [
                    {
                        "id": 301,
                        "type": "mcq",
                        "category": "Joins & Set Operations",
                        "question": "What is the key difference between INNER JOIN and LEFT OUTER JOIN?",
                        "code_snippet": "",
                        "options": [
                            "INNER JOIN returns all rows from left table; LEFT JOIN only matches exact primary keys",
                            "INNER JOIN returns only rows matching on both tables; LEFT OUTER JOIN returns all rows from left table with matching rows or NULLs from right table",
                            "LEFT JOIN executes without indexes; INNER JOIN requires foreign keys",
                            "There is no difference in modern ANSI SQL"
                        ],
                        "correct_option": 1,
                        "explanation": "INNER JOIN excludes unmatched rows, while LEFT OUTER JOIN guarantees all rows from the primary left table are preserved."
                    },
                    {
                        "id": 302,
                        "type": "conceptual",
                        "category": "Null Logic",
                        "question": "In SQL three-valued logic, what is the evaluation of 'WHERE department = NULL'?",
                        "code_snippet": "",
                        "options": [
                            "TRUE",
                            "UNKNOWN (treated as False in WHERE filtering; IS NULL must be used)",
                            "FALSE",
                            "Syntax Error"
                        ],
                        "correct_option": 1,
                        "explanation": "In SQL, comparisons with NULL evaluate to UNKNOWN; IS NULL or IS NOT NULL must be used to test nullability."
                    }
                ],
                "medium": [
                    {
                        "id": 303,
                        "type": "code_output",
                        "category": "Aggregation & Filtering",
                        "question": "Which SQL clause must be used to filter groups created by 'GROUP BY department' with aggregate condition 'COUNT(*) > 5'?",
                        "code_snippet": "SELECT department, COUNT(*) \nFROM employees \nGROUP BY department \n/* WHICH CLAUSE GOES HERE? */",
                        "options": [
                            "WHERE COUNT(*) > 5",
                            "HAVING COUNT(*) > 5",
                            "FILTER BY COUNT(*) > 5",
                            "ORDER BY COUNT(*) > 5"
                        ],
                        "correct_option": 1,
                        "explanation": "WHERE filters individual rows before aggregation occurs; HAVING filters aggregated groups after the GROUP BY calculation."
                    },
                    {
                        "id": 304,
                        "type": "conceptual",
                        "category": "Indexing Tradeoffs",
                        "question": "What is the primary architectural tradeoff when adding multiple B-Tree indexes to an active SQL table?",
                        "code_snippet": "",
                        "options": [
                            "Read queries speed up, but INSERT, UPDATE, and DELETE operations slow down due to index maintenance overhead",
                            "Storage drops dramatically, but SELECT queries slow down",
                            "Database connections are limited to 10 per index",
                            "Foreign key constraints are disabled automatically"
                        ],
                        "correct_option": 0,
                        "explanation": "Indexes accelerate targeted reads at the cost of additional disk footprint and write-amplification during mutations."
                    }
                ],
                "hard": [
                    {
                        "id": 305,
                        "type": "scenario",
                        "category": "ACID & Concurrency",
                        "question": "Under SQL READ COMMITTED isolation level, what concurrency anomaly can still occur that REPEATABLE READ prevents?",
                        "code_snippet": "",
                        "options": [
                            "Dirty Read (reading uncommitted data from aborted transaction)",
                            "Non-Repeatable Read (re-reading the same row within a transaction produces modified values because another transaction committed)",
                            "Divide by zero errors",
                            "Deadlocks are permanently impossible"
                        ],
                        "correct_option": 1,
                        "explanation": "READ COMMITTED prevents dirty reads, but allows non-repeatable reads if a concurrent transaction commits updates between queries."
                    },
                    {
                        "id": 306,
                        "type": "scenario",
                        "category": "Query Optimization",
                        "question": "A query with 'WHERE department_id = 4 AND YEAR(created_at) = 2024' is slow despite an index on (department_id, created_at). What is the cause?",
                        "code_snippet": "",
                        "options": [
                            "SQL cannot use composite indexes with more than 1 column",
                            "Applying the YEAR() function on created_at makes it non-sargable, preventing direct B-tree range seek",
                            "The table must be partitioned across multiple disks",
                            "Numbers in WHERE clauses must be passed as strings"
                        ],
                        "correct_option": 1,
                        "explanation": "Wrapping an indexed column inside a function prevents index range seeks; rewrite as date range boundaries."
                    }
                ]
            },
            "git": {
                "easy": [
                    {
                        "id": 401,
                        "type": "mcq",
                        "category": "Staging & Index",
                        "question": "What is the purpose of the Git staging area (also known as the index)?",
                        "code_snippet": "",
                        "options": [
                            "A remote repository hosted on GitHub",
                            "An intermediate preparation area where file changes are organized and reviewed before finalizing them into a commit",
                            "A temporary stash that is discarded every time the terminal closes",
                            "The local garbage collection folder"
                        ],
                        "correct_option": 1,
                        "explanation": "The staging area lets developers selectively assemble and review precise hunks or files before committing."
                    },
                    {
                        "id": 402,
                        "type": "mcq",
                        "category": "Branching Basics",
                        "question": "Which command creates a new branch named 'feature-auth' and immediately switches your working tree to it?",
                        "code_snippet": "",
                        "options": [
                            "git branch feature-auth",
                            "git checkout -b feature-auth (or git switch -c feature-auth)",
                            "git commit -m 'feature-auth'",
                            "git stash branch feature-auth"
                        ],
                        "correct_option": 1,
                        "explanation": "git checkout -b <name> or git switch -c <name> atomically creates and checks out the new branch."
                    }
                ],
                "medium": [
                    {
                        "id": 403,
                        "type": "mcq",
                        "category": "Merge vs Rebase",
                        "question": "What is the primary difference between 'git merge' and 'git rebase'?",
                        "code_snippet": "",
                        "options": [
                            "Merge deletes commits; rebase retains deleted branch heads",
                            "Merge creates a 2-parent merge commit preserving exact history; rebase replays your commits on top of another base, creating a linear history",
                            "Rebase can only be used on the main/production branch",
                            "Merge converts local branches into remote tags"
                        ],
                        "correct_option": 1,
                        "explanation": "Merge records a non-destructive merge commit, while rebase moves the feature branch commits onto the tip of the target branch."
                    },
                    {
                        "id": 404,
                        "type": "scenario",
                        "category": "Conflict Resolution",
                        "question": "You pull changes from origin/main and encounter a merge conflict. What is the correct sequence to resolve it?",
                        "code_snippet": "",
                        "options": [
                            "Delete the .git directory and clone fresh",
                            "Inspect conflict markers in affected files, edit to resolve differences, run 'git add <file>', and commit the resolution",
                            "Run 'git push --force' to overwrite the remote branch",
                            "Run 'git reset --hard HEAD~5'"
                        ],
                        "correct_option": 1,
                        "explanation": "Merge conflicts require editing the conflicted files to remove markers, staging with 'git add', and finalizing with 'git commit'."
                    }
                ],
                "hard": [
                    {
                        "id": 405,
                        "type": "scenario",
                        "category": "History Recovery",
                        "question": "A developer accidentally runs 'git reset --hard HEAD~3' and loses commits that were not on any other branch. How can they be recovered?",
                        "code_snippet": "",
                        "options": [
                            "The commits are permanently destroyed from disk",
                            "Use 'git reflog' to identify the commit hash prior to the reset, then run 'git reset --hard <hash>'",
                            "Clone the repository to another directory",
                            "Re-type the code from memory"
                        ],
                        "correct_option": 1,
                        "explanation": "Git reflog records reference updates locally, keeping unreachable commits accessible before garbage collection."
                    },
                    {
                        "id": 406,
                        "type": "scenario",
                        "category": "Force Push Safety",
                        "question": "Why is 'git push --force-with-lease' strongly preferred over 'git push --force' on collaborative branches?",
                        "code_snippet": "",
                        "options": [
                            "It compresses commits to save network bandwidth",
                            "It refuses to overwrite remote commits if another teammate pushed new work to that branch since you last fetched",
                            "It prompts for two-factor authentication on every commit",
                            "It executes automated unit tests before uploading"
                        ],
                        "correct_option": 1,
                        "explanation": "--force-with-lease guards against blindly overwriting someone else's work if the remote ref has moved since your last fetch."
                    }
                ]
            },
            "flask": {
                "easy": [
                    {
                        "id": 501,
                        "type": "mcq",
                        "category": "Routing & Views",
                        "question": "How does Flask map an incoming HTTP URL request to a Python view function?",
                        "code_snippet": "",
                        "options": [
                            "Through an XML configuration file",
                            "Using the '@app.route('/path')' function decorator",
                            "By parsing file names in the directory",
                            "Using Python class metaclasses only"
                        ],
                        "correct_option": 1,
                        "explanation": "Flask maps URLs to handler functions declaratively via '@app.route()' decorator syntax."
                    },
                    {
                        "id": 502,
                        "type": "mcq",
                        "category": "Request Context",
                        "question": "Where do you access query string parameters (e.g. '?page=2') in a Flask view function?",
                        "code_snippet": "",
                        "options": [
                            "flask.session['page']",
                            "flask.request.args.get('page')",
                            "flask.request.form.get('page')",
                            "os.environ.get('page')"
                        ],
                        "correct_option": 1,
                        "explanation": "request.args contains parsed URL query string parameters; request.form holds POST body form data."
                    }
                ],
                "medium": [
                    {
                        "id": 503,
                        "type": "scenario",
                        "category": "Database Transactions",
                        "question": "In Flask-SQLAlchemy, why must an application call 'db.session.rollback()' inside an exception handler if a query fails?",
                        "code_snippet": "",
                        "options": [
                            "To delete the database file from disk",
                            "To abort the failed transaction state so subsequent queries in the request or connection pool do not raise InvalidRequestError",
                            "To restart the WSGI server process",
                            "To send an email to the server administrator"
                        ],
                        "correct_option": 1,
                        "explanation": "If an error occurs inside a transaction, the connection is placed in an aborted state until explicit rollback."
                    },
                    {
                        "id": 504,
                        "type": "conceptual",
                        "category": "Template Security (XSS)",
                        "question": "How does Flask's Jinja2 template engine protect against Cross-Site Scripting (XSS) by default?",
                        "code_snippet": "",
                        "options": [
                            "By blocking all JavaScript files from loading",
                            "By automatically HTML-escaping variables rendered inside {{ var }} unless explicitly marked safe",
                            "By running an antivirus scan on every page request",
                            "By encrypting HTML source code with SSL"
                        ],
                        "correct_option": 1,
                        "explanation": "Jinja2 auto-escapes HTML entities (<, >, &, \") by default to prevent injected script execution."
                    }
                ],
                "hard": [
                    {
                        "id": 505,
                        "type": "scenario",
                        "category": "Application Factory & Blueprints",
                        "question": "Why is the Application Factory pattern (create_app()) combined with Blueprints recommended for production Flask apps?",
                        "code_snippet": "",
                        "options": [
                            "It allows running Flask without installing Python",
                            "It prevents circular imports, isolates routes into modular feature packages, and allows instantiating isolated app configurations for testing",
                            "It forces all database queries to execute in memory",
                            "It converts Flask apps to mobile apps automatically"
                        ],
                        "correct_option": 1,
                        "explanation": "Application factories avoid global state, allow clean unit testing with distinct configs, and structure large apps into cohesive Blueprints."
                    },
                    {
                        "id": 506,
                        "type": "scenario",
                        "category": "Production Concurrency",
                        "question": "Why should a production Flask app never run with 'app.run(debug=True)', and how is it deployed?",
                        "code_snippet": "",
                        "options": [
                            "Debug mode disables the database; use a local batch script",
                            "The built-in development server is single-threaded and insecure; production uses a WSGI server (Gunicorn/uWSGI) managing multiple worker processes behind a reverse proxy",
                            "Flask cannot handle more than 5 users without an enterprise license",
                            "HTML pages do not render without Gunicorn"
                        ],
                        "correct_option": 1,
                        "explanation": "Development Werkzeug server lacks worker supervision, security hardening, and concurrency; WSGI servers manage multi-process workers safely."
                    }
                ]
            },
            "generic": {
                "easy": [
                    {
                        "id": 901,
                        "type": "mcq",
                        "category": "Architecture & Clean Code",
                        "question": "What is the primary benefit of enforcing modular separation of concerns in software architecture?",
                        "code_snippet": "",
                        "options": [
                            "It reduces code readability by spreading logic across files",
                            "It isolates domain responsibilities, making systems easier to test, refactor, and maintain without unintended side effects",
                            "It guarantees zero compile warnings in all programming languages",
                            "It automatically compresses database storage"
                        ],
                        "correct_option": 1,
                        "explanation": "Modular separation decouples distinct capabilities, minimizing blast radius during updates and enabling isolated testing."
                    }
                ],
                "medium": [
                    {
                        "id": 902,
                        "type": "scenario",
                        "category": "Performance Profiling",
                        "question": "When an application begins experiencing high latency under load, what should be inspected first before refactoring business logic?",
                        "code_snippet": "",
                        "options": [
                            "Operating system font caches",
                            "Database query execution plans, unindexed table scans, and network I/O bottlenecks",
                            "The color scheme of the terminal prompt",
                            "The length of variable names in source code"
                        ],
                        "correct_option": 1,
                        "explanation": "I/O bound operations (database queries, network round-trips) are the most common source of high latency in web applications."
                    }
                ],
                "hard": [
                    {
                        "id": 903,
                        "type": "scenario",
                        "category": "Resilience & Circuit Breakers",
                        "question": "In a distributed system where Service A calls external Service B, how does a Circuit Breaker pattern prevent cascading system failures?",
                        "code_snippet": "",
                        "options": [
                            "It shuts down Service A completely when an error occurs",
                            "It detects continuous failures in Service B, temporarily opens the circuit to fail fast or return fallbacks, and prevents thread exhaustion",
                            "It automatically increases database connection limits indefinitely",
                            "It converts HTTP requests to SMS text messages"
                        ],
                        "correct_option": 1,
                        "explanation": "Circuit breakers fail fast when a downstream dependency is degraded, preventing thread pool depletion and cascading system collapse."
                    }
                ]
            }
        }

    def _normalize_skill_key(self, skill_name):
        s = skill_name.strip().lower()
        if "python" in s:
            return "python"
        elif "rest" in s or "api" in s:
            return "rest api"
        elif "sql" in s or "database" in s:
            return "sql"
        elif "git" in s or "version" in s:
            return "git"
        elif "flask" in s:
            return "flask"
        return "generic"

    def get_bank_questions(self, skill_name, difficulty="medium"):
        key = self._normalize_skill_key(skill_name)
        skill_dict = self.question_bank.get(key, self.question_bank["generic"])
        diff_questions = skill_dict.get(difficulty, [])
        if not diff_questions:
            # Fallback across difficulties
            for d in ["medium", "easy", "hard"]:
                if skill_dict.get(d):
                    return skill_dict[d]
        return diff_questions

    # =========================================================================
    # 2. ASSESSMENT ATTEMPT CREATION & INITIAL QUESTION ASSIGNMENT
    # =========================================================================
    def create_attempt(self, user, skill_name, question_time_limit=60):
        """
        Creates a secure, server-controlled assessment attempt.
        Binds to user, sets expiry, and initializes the first question (Medium).
        """
        key = self._normalize_skill_key(skill_name)
        now = datetime.now(timezone.utc)
        # 15-minute maximum total attempt window
        expires_at = now + timedelta(minutes=15)

        # Select initial question (Medium difficulty)
        medium_pool = self.get_bank_questions(skill_name, "medium")
        if not medium_pool:
            medium_pool = self.get_bank_questions(skill_name, "easy")

        selected_q = random.choice(medium_pool)
        prepared_q = self._prepare_question_for_attempt(selected_q, "medium")

        attempt = AssessmentAttempt(
            user_id=user.id,
            skill_name=skill_name,
            started_at=now,
            expires_at=expires_at,
            status='active',
            integrity_score=100,
            integrity_status='normal',
            current_question_index=0,
            current_question_started_at=now,
            question_time_limit=question_time_limit,
            adaptive_path_json=json.dumps(["medium"]),
            assigned_questions_json=json.dumps([prepared_q])
        )
        db.session.add(attempt)
        db.session.commit()
        return attempt

    def _prepare_question_for_attempt(self, raw_q, difficulty):
        """
        Shuffles options deterministically for this attempt and remaps correct_option.
        The correct_option is stored ONLY server-side inside assigned_questions_json.
        """
        options = list(raw_q["options"])
        correct_text = options[raw_q["correct_option"]]
        random.shuffle(options)
        new_correct_idx = options.index(correct_text)

        return {
            "id": raw_q["id"],
            "question": raw_q["question"],
            "code_snippet": raw_q.get("code_snippet", ""),
            "options": options,
            "correct_option": new_correct_idx,
            "difficulty": difficulty,
            "category": raw_q.get("category", "Core Capability"),
            "explanation": raw_q.get("explanation", "")
        }

    # =========================================================================
    # 3. GET CURRENT QUESTION PAYLOAD (NEVER EXPOSE ANSWER KEYS)
    # =========================================================================
    def get_current_question_payload(self, attempt):
        """
        Extracts the current question for the client.
        CRITICAL: NEVER exposes correct_option or explanation to the client.
        """
        assigned = attempt.assigned_questions
        idx = attempt.current_question_index
        if idx >= len(assigned):
            return None

        current_q = assigned[idx]
        now = datetime.now(timezone.utc)
        elapsed = (now - attempt.current_question_started_at.replace(tzinfo=timezone.utc)).total_seconds()
        time_remaining = max(0, int(attempt.question_time_limit - elapsed))

        return {
            "attempt_id": attempt.id,
            "skill_name": attempt.skill_name,
            "question_index": idx + 1,
            "total_questions": 5,
            "question_text": current_q["question"],
            "code_snippet": current_q.get("code_snippet", ""),
            "options": current_q["options"],
            "difficulty": current_q.get("difficulty", "medium"),
            "category": current_q.get("category", "Core Capability"),
            "time_limit": attempt.question_time_limit,
            "time_remaining": time_remaining,
            "integrity_score": attempt.integrity_score,
            "integrity_status": attempt.integrity_status
        }

    # =========================================================================
    # 4. SUBMIT ANSWER, SERVER TIMER VALIDATION, & ADAPTIVE DIFFICULTY
    # =========================================================================
    def submit_attempt_answer(self, attempt, question_index, selected_option):
        """
        Validates the submitted answer server-side:
        - Rejects duplicate answers (locks after submission)
        - Enforces server-side timer
        - Evaluates correctness
        - Chooses next question adaptively
        - Finalizes attempt when all 5 questions are complete
        """
        if attempt.status != 'active':
            return {"error": "This assessment attempt is no longer active.", "status": attempt.status, "completed": True, "is_finished": True}

        # The assessment interface is 1-indexed (Questions 1 through 5)
        target_idx = (question_index - 1) if question_index >= 1 else question_index

        # If target_idx is already past or answered, it is a duplicate attempt
        existing_answer = AttemptAnswer.query.filter_by(
            attempt_id=attempt.id,
            question_index=target_idx
        ).first()
        if existing_answer or target_idx < attempt.current_question_index:
            self.record_integrity_event(attempt, 'DUPLICATE_SUBMISSION', {'index': target_idx})
            return {"error": "This question has already been answered and locked.", "completed": False, "is_finished": False}

        if target_idx != attempt.current_question_index:
            return {"error": f"Invalid question sequence. Expected question {attempt.current_question_index + 1}.", "completed": False, "is_finished": False}

        assigned = attempt.assigned_questions
        current_q = assigned[target_idx]

        # Server-side timer validation
        now = datetime.now(timezone.utc)
        elapsed = (now - attempt.current_question_started_at.replace(tzinfo=timezone.utc)).total_seconds()
        
        # 5-second grace period for network latency
        is_expired = elapsed > (attempt.question_time_limit + 5.0)
        
        is_correct = False
        if is_expired:
            self.record_integrity_event(attempt, attempt.user_id, 'TIME_EXPIRED', {'elapsed': elapsed})
            user_ans_val = None
        else:
            try:
                user_ans_val = int(selected_option) if selected_option is not None else None
            except (ValueError, TypeError):
                user_ans_val = None
            is_correct = (user_ans_val is not None and user_ans_val == current_q["correct_option"])

        # Save immutable AttemptAnswer record
        answer_record = AttemptAnswer(
            attempt_id=attempt.id,
            question_id=current_q["id"],
            question_index=target_idx,
            user_answer=user_ans_val,
            is_correct=is_correct,
            difficulty=current_q.get("difficulty", "medium"),
            time_taken_seconds=min(int(elapsed), attempt.question_time_limit),
            answered_at=now
        )
        db.session.add(answer_record)

        # Advance question index
        next_idx = target_idx + 1
        attempt.current_question_index = next_idx

        # Adaptive difficulty logic for next question
        current_diff = current_q.get("difficulty", "medium")
        if is_correct:
            next_diff = "hard" if current_diff in ["medium", "hard"] else "medium"
        else:
            next_diff = "easy" if current_diff in ["easy", "medium"] else "medium"

        adaptive_path = attempt.adaptive_path
        adaptive_path.append(next_diff if next_idx < 5 else current_diff)
        attempt.adaptive_path_json = json.dumps(adaptive_path)

        if next_idx < 5:
            # Select and assign next question adaptively
            next_q = self._select_next_adaptive_question(attempt, next_diff)
            assigned.append(next_q)
            attempt.assigned_questions_json = json.dumps(assigned)
            attempt.current_question_started_at = now
            db.session.commit()
            return {
                "completed": False,
                "is_finished": False,
                "next_question_index": next_idx + 1,
                "total_questions": 5
            }
        else:
            # Assessment finished! Finalize attempt
            final_assessment, eval_result = self.finalize_attempt(attempt)
            db.session.commit()
            return {
                "completed": True,
                "is_finished": True,
                "attempt_id": attempt.id,
                "score": attempt.score,
                "integrity_score": attempt.integrity_score,
                "integrity_status": attempt.integrity_status
            }

    def _select_next_adaptive_question(self, attempt, target_diff):
        """Picks a question from question bank with target difficulty not already assigned."""
        assigned_ids = [q["id"] for q in attempt.assigned_questions]
        pool = self.get_bank_questions(attempt.skill_name, target_diff)
        available = [q for q in pool if q["id"] not in assigned_ids]
        
        if not available:
            # Fallback to any difficulty not yet assigned
            for alt_diff in ["medium", "hard", "easy"]:
                alt_pool = self.get_bank_questions(attempt.skill_name, alt_diff)
                available = [q for q in alt_pool if q["id"] not in assigned_ids]
                if available:
                    break

        if available:
            chosen = random.choice(available)
        else:
            # Last resort generic question
            chosen = self.question_bank["generic"]["medium"][0]

        return self._prepare_question_for_attempt(chosen, target_diff)

    # =========================================================================
    # 5. INTEGRITY EVENT RECORDING
    # =========================================================================
    def record_integrity_event(self, attempt, *args, **kwargs):
        """
        Records an integrity signal with proportional score deductions.
        Can be called as:
          record_integrity_event(attempt, 'TAB_SWITCH', metadata)
          record_integrity_event(attempt, user_id, 'TAB_SWITCH', metadata)
        """
        user_id = attempt.user_id
        event_type = "UNKNOWN"
        metadata = None

        if len(args) == 1:
            event_type = args[0]
            metadata = kwargs.get('metadata')
        elif len(args) == 2:
            if isinstance(args[0], int):
                user_id = args[0]
                event_type = args[1]
                metadata = kwargs.get('metadata')
            else:
                event_type = args[0]
                metadata = args[1]
        elif len(args) >= 3:
            user_id = args[0]
            event_type = args[1]
            metadata = args[2]
        else:
            event_type = kwargs.get('event_type', 'UNKNOWN')
            metadata = kwargs.get('metadata')
            user_id = kwargs.get('user_id', attempt.user_id)

        deductions = {
            'TAB_SWITCH': 12,
            'FULLSCREEN_EXIT': 10,
            'WINDOW_BLUR': 5,
            'COPY_ATTEMPT': 8,
            'PASTE_ATTEMPT': 8,
            'TIME_EXPIRED': 10,
            'DUPLICATE_SUBMISSION': 15
        }
        penalty = deductions.get(event_type, 5)
        new_score = max(25, attempt.integrity_score - penalty)
        attempt.integrity_score = new_score
        attempt.integrity_status = "normal" if new_score >= 70 else "review"

        event = IntegrityEvent(
            attempt_id=attempt.id,
            user_id=user_id,
            event_type=event_type,
            timestamp=datetime.now(timezone.utc),
            metadata_json=json.dumps(metadata) if metadata else None
        )
        db.session.add(event)
        return event

    # =========================================================================
    # 6. FINALIZE ATTEMPT & SYNC PROFILE / CAREER PROGRESS
    # =========================================================================
    def finalize_attempt(self, attempt):
        """
        Calculates final score based on difficulty-weighted performance.
        Creates Assessment record, updates Skill, dispatches CareerProgress & Notification.
        """
        answers = attempt.answers.all()
        total_q = len(answers)
        correct_count = sum(1 for a in answers if a.is_correct)
        
        # Difficulty weighted score points
        # Easy correct: 14 pts, Medium: 18 pts, Hard: 22 pts + 20 baseline points
        weighted_points = 20
        strong_categories = []
        weak_categories = []

        assigned_map = {q["id"]: q for q in attempt.assigned_questions}
        answers_dict = {}

        for a in answers:
            answers_dict[str(a.question_id)] = a.user_answer
            q_info = assigned_map.get(a.question_id, {})
            cat = q_info.get("category", "Core Capability")
            
            if a.is_correct:
                if a.difficulty == "hard":
                    weighted_points += 22
                elif a.difficulty == "medium":
                    weighted_points += 18
                else:
                    weighted_points += 14
                if cat not in strong_categories:
                    strong_categories.append(cat)
            else:
                if cat not in weak_categories:
                    weak_categories.append(cat)

        # Fallback calibrated score table if less than 5 answers
        score_table = {5: 92, 4: 82, 3: 72, 2: 55, 1: 38, 0: 25}
        if total_q == 5:
            final_score = min(95, max(25, weighted_points))
        else:
            final_score = score_table.get(correct_count, 50)

        # Level bracket
        if final_score >= 85:
            level = "Advanced"
        elif final_score >= 70:
            level = "Intermediate"
        elif final_score >= 40:
            level = "Basic"
        else:
            level = "Beginner"

        if not strong_categories:
            strong_categories = ["Core Syntax & Fundamentals"]
        if not weak_categories:
            weak_categories = ["Distributed Scale & Edge Cases"]

        attempt.status = 'completed'
        attempt.completed_at = datetime.now(timezone.utc)
        attempt.score = final_score

        # Create Assessment record for compatibility
        assessment = Assessment(
            user_id=attempt.user_id,
            skill=attempt.skill_name,
            score=final_score,
            level=level,
            questions_json=json.dumps(attempt.assigned_questions),
            answers_json=json.dumps(answers_dict),
            strong_areas=json.dumps(strong_categories),
            weak_areas=json.dumps(weak_categories),
            integrity_score=attempt.integrity_score,
            integrity_status=attempt.integrity_status,
            confidence_level=attempt.confidence_level,
            adaptive_path_json=attempt.adaptive_path_json
        )
        db.session.add(assessment)
        db.session.flush()
        attempt.assessment_id = assessment.id

        # Update candidate's Skill record
        clean_skill_name = attempt.skill_name.strip()
        skill = Skill.query.filter(
            Skill.user_id == attempt.user_id,
            db.func.lower(Skill.name) == clean_skill_name.lower()
        ).first()
        if not skill:
            skill = Skill(
                user_id=attempt.user_id,
                name=clean_skill_name,
                claimed_level=level
            )
            db.session.add(skill)

        skill.verified = True
        skill.assessed_score = final_score
        skill.assessed_level = level
        skill.last_assessed_at = datetime.now(timezone.utc)

        # Dispatch CareerProgress & Notification
        try:
            db.session.add(CareerProgress(
                user_id=attempt.user_id,
                milestone_title=f"Verified Skill: {attempt.skill_name} ({final_score}/100)",
                milestone_type="reassessment",
                readiness_score=final_score,
                match_score=final_score,
                description=f"Adaptive assessment completed with {attempt.integrity_status.title()} integrity ({attempt.integrity_score}/100). {correct_count}/5 questions correct.",
                is_completed=True
            ))
            db.session.add(Notification(
                user_id=attempt.user_id,
                type="reassessment",
                title=f"Adaptive Assessment Complete: {attempt.skill_name}",
                message=f"You earned {final_score}/100 ({level}) with {attempt.confidence_level} confidence. Assessment Integrity: {attempt.integrity_score}/100 ({attempt.integrity_status.title()}).",
                link=f"/assessment/attempt/{attempt.id}/result",
                is_read=False
            ))
        except Exception as e:
            print(f"[AssessmentService] Notice dispatch error: {e}")

        eval_result = {
            "score": final_score,
            "level": level,
            "correct_count": correct_count,
            "total_questions": total_q,
            "strong_areas": strong_categories,
            "weak_areas": weak_categories,
            "summary": f"Demonstrated {level} proficiency in {attempt.skill_name}."
        }
        return assessment, eval_result

    # =========================================================================
    # 7. BACKWARD COMPATIBILITY METHODS
    # =========================================================================
    def get_or_create_questions(self, user, skill_name):
        """Legacy helper for test backward compatibility"""
        skill = Skill.query.filter_by(user_id=user.id, name=skill_name).first()
        claimed_level = skill.claimed_level if skill else "Intermediate"
        return ai_service.generate_assessment_questions(skill_name, claimed_level)

    def grade_and_record_assessment(self, user, skill_name, questions, answers_dict):
        """Legacy helper for test backward compatibility"""
        eval_result = ai_service.evaluate_assessment(skill_name, questions, answers_dict)
        
        assessment = Assessment(
            user_id=user.id,
            skill=skill_name,
            score=eval_result["score"],
            level=eval_result["level"],
            questions_json=json.dumps(questions),
            answers_json=json.dumps(answers_dict),
            strong_areas=json.dumps(eval_result["strong_areas"]),
            weak_areas=json.dumps(eval_result["weak_areas"]),
            integrity_score=95,
            integrity_status='normal',
            confidence_level='High',
            adaptive_path_json=json.dumps(["medium", "medium", "hard", "medium", "hard"])
        )
        db.session.add(assessment)

        clean_skill_name = skill_name.strip()
        skill = Skill.query.filter(
            Skill.user_id == user.id,
            db.func.lower(Skill.name) == clean_skill_name.lower()
        ).first()
        if not skill:
            skill = Skill(
                user_id=user.id,
                name=clean_skill_name,
                claimed_level=eval_result["level"]
            )
            db.session.add(skill)

        skill.verified = True
        skill.assessed_score = eval_result["score"]
        skill.assessed_level = eval_result["level"]
        skill.last_assessed_at = datetime.now(timezone.utc)
        db.session.commit()
        return assessment, eval_result


# Global singleton instance
assessment_service = AssessmentService()
