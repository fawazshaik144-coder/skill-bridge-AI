from services.ai_service import ai_service

class MatchingService:
    @staticmethod
    def calculate_skill_ratio(cand_score, req_score):
        """
        Calculates normalized fulfillment ratio.
        If cand_score >= req_score, fulfillment blends meeting the requirement (base 0.72)
        with extra excellence points (0.28 * cand_score / 100).
        If cand_score < req_score, applies a calibrated capability curve (ratio^1.85)
        reflecting that low scores represent critical job performance deficiencies.
        """
        if req_score <= 0:
            return 1.0
        
        base = 0.72
        cand_excellence = base + (1.0 - base) * (min(100, cand_score) / 100.0)
        
        if cand_score >= req_score:
            return min(1.0, cand_excellence)
        
        ratio = max(0.0, cand_score / req_score)
        curve = (ratio ** 1.85) * cand_excellence
        return max(0.0, min(1.0, curve))

    def calculate_job_match(self, candidate, job, simulated_skills=None):
        """
        Calculates explainable capability match between candidate and job.
        simulated_skills can be a dict {skill_name: score} to test "What If I Improve?".
        """
        # Build candidate's skill lookup
        candidate_skills = candidate.get_skill_map() if hasattr(candidate, 'get_skill_map') else {}
        
        comparison_table = []
        strong_matches = []
        skill_gaps = []
        
        total_weighted_points = 0.0
        total_weight = 0.0

        for req in job.required_skills:
            req_name = req.skill_name.strip()
            req_name_lower = req_name.lower()
            req_score = req.required_score
            weight = req.weight if req.weight > 0 else 1.0
            
            # Check if this skill is being simulated
            if simulated_skills and req_name_lower in simulated_skills:
                cand_score = int(simulated_skills[req_name_lower])
                verified = True
                claimed_level = "Simulated"
            elif req_name_lower in candidate_skills:
                sk = candidate_skills[req_name_lower]
                cand_score = sk.effective_score()
                verified = sk.verified
                claimed_level = sk.assessed_level or sk.claimed_level
            else:
                cand_score = 0
                verified = False
                claimed_level = "None"

            # Calculate ratio
            ratio = self.calculate_skill_ratio(cand_score, req_score)
            points = ratio * weight
            total_weighted_points += points
            total_weight += weight

            # Status classification
            diff = cand_score - req_score
            if cand_score >= req_score:
                status = "Strong Match"
                badge_class = "success"
                icon = "✓"
                strong_matches.append({
                    "name": req_name,
                    "required": req_score,
                    "candidate_score": cand_score,
                    "status": status,
                    "icon": icon,
                    "weight": weight
                })
            elif cand_score >= (req_score * 0.65):
                status = "Moderate Gap"
                badge_class = "warning"
                icon = "⚠"
                skill_gaps.append({
                    "name": req_name,
                    "required": req_score,
                    "candidate_score": cand_score,
                    "gap": req_score - cand_score,
                    "status": status,
                    "icon": icon,
                    "weight": weight
                })
            else:
                status = "Critical Gap"
                badge_class = "danger"
                icon = "✕"
                skill_gaps.append({
                    "name": req_name,
                    "required": req_score,
                    "candidate_score": cand_score,
                    "gap": req_score - cand_score,
                    "status": status,
                    "icon": icon,
                    "weight": weight
                })

            comparison_table.append({
                "name": req_name,
                "required": req_score,
                "candidate_score": cand_score,
                "verified": verified,
                "claimed_level": claimed_level,
                "status": status,
                "badge_class": badge_class,
                "icon": icon,
                "weight": weight,
                "percentage": int(ratio * 100)
            })

        # Calculate final match score
        if total_weight > 0:
            raw_match = (total_weighted_points / total_weight) * 100
            match_score = int(round(raw_match))
        else:
            match_score = 50

        # Bound match score between 10% and 99% (or 100% if perfect)
        match_score = max(10, min(100, match_score))

        # Sort gaps by weight and gap size for prioritization
        skill_gaps.sort(key=lambda x: (x["weight"] * x.get("gap", 20)), reverse=True)

        # Generate AI explanation
        explanation_data = ai_service.explain_job_match(
            candidate_skills,
            [{"name": r.skill_name, "required": r.required_score} for r in job.required_skills],
            match_score,
            strong_matches,
            skill_gaps
        )

        return {
            "match_score": match_score,
            "strong_matches": strong_matches,
            "skill_gaps": skill_gaps,
            "comparison_table": comparison_table,
            "ai_explanation": explanation_data["explanation"],
            "strong_summary": explanation_data["strong_summary"],
            "gap_summary": explanation_data["gap_summary"]
        }

    def calculate_candidate_readiness(self, candidate, sample_jobs=None):
        """
        Calculates the candidate's Job Readiness Score (e.g. 82%).
        Blends verified skill depth, assessment completion, and target role alignment.
        """
        skills = candidate.skills.all() if hasattr(candidate, 'skills') else []
        if not skills:
            return 35

        verified_skills = [s for s in skills if s.verified]
        avg_verified_score = (
            sum(s.assessed_score for s in verified_skills) / len(verified_skills)
            if verified_skills else 45
        )

        verification_ratio = len(verified_skills) / max(len(skills), 1)

        # Formula: 60% assessed score + 40% verification proportion
        readiness = int((avg_verified_score * 0.70) + (verification_ratio * 30))
        return max(20, min(95, readiness))

    def calculate_skill_improvement_priorities(self, candidate, job):
        """
        Calculates the individual impact of closing each skill gap for 'What should I improve first?'.
        Returns list of gaps sorted by impact (+15%, +6%, etc.).
        """
        baseline_res = self.calculate_job_match(candidate, job)
        baseline_score = baseline_res['match_score']
        gaps = baseline_res['skill_gaps']

        priorities = []
        for gap in gaps:
            req_target = min(100, gap['required'] + 5)
            # Test simulating JUST this single skill
            sim_single = {gap['name'].lower(): req_target}
            single_res = self.calculate_job_match(candidate, job, simulated_skills=sim_single)
            delta = single_res['match_score'] - baseline_score
            delta = max(1, delta)  # at least +1%

            priorities.append({
                'skill_name': gap['name'],
                'current_score': gap['candidate_score'],
                'required_score': gap['required'],
                'target_score': req_target,
                'delta': delta,
                'weight': gap.get('weight', 1.0),
                'status': gap.get('status', 'Gap'),
                'is_top_recommendation': False
            })

        priorities.sort(key=lambda x: (x['delta'], x['weight']), reverse=True)
        if priorities:
            priorities[0]['is_top_recommendation'] = True

        return priorities

    def calculate_readiness_breakdown(self, candidate, target_job=None):
        """
        Feature 1: Comprehensive SkillBridge Readiness Score & Breakdown.
        Returns overall score, 4 core pillars, strongest skills, skills holding back,
        and Next Best Action.
        """
        skills = candidate.skills.all() if hasattr(candidate, 'skills') else []
        verified_skills = [s for s in skills if s.verified]

        # 1. Technical Skills Pillar (average of top verified skills, or effective scores)
        if verified_skills:
            sorted_v = sorted(verified_skills, key=lambda s: s.assessed_score, reverse=True)
            tech_score = int(sum(s.assessed_score for s in sorted_v[:3]) / min(3, len(sorted_v)))
        elif skills:
            tech_score = int(sum(s.effective_score() for s in skills) / len(skills))
        else:
            tech_score = 40

        # 2. Role Fit Pillar
        if target_job:
            match_res = self.calculate_job_match(candidate, target_job)
            role_fit_score = match_res['match_score']
            gaps = match_res['skill_gaps']
        else:
            role_fit_score = 70
            gaps = []

        # 3. Assessment Confidence Pillar
        if skills:
            verif_count = len(verified_skills)
            total_count = len(skills)
            conf_ratio = verif_count / total_count
            conf_score = int(40 + (conf_ratio * 45))
        else:
            conf_score = 30

        # 4. Skill Evidence Pillar (resume, profile details, completed assessments)
        evidence_score = 50
        if getattr(candidate, 'resume_text', None):
            evidence_score += 15
        if getattr(candidate, 'education', None):
            evidence_score += 10
        if len(verified_skills) >= 3:
            evidence_score += 15
        evidence_score = min(95, evidence_score)

        # Overall SkillBridge Readiness Score: Weighted blend
        overall_score = int(
            (tech_score * 0.35) +
            (role_fit_score * 0.35) +
            (conf_score * 0.15) +
            (evidence_score * 0.15)
        )
        overall_score = max(25, min(95, overall_score))

        # Strongest Skills
        strongest = [s for s in skills if s.effective_score() >= 65]
        strongest.sort(key=lambda s: s.effective_score(), reverse=True)

        # Skills Holding You Back (Required vs Current for target job)
        holding_back = []
        if gaps:
            for g in gaps:
                holding_back.append({
                    'name': g['name'],
                    'current': g['candidate_score'],
                    'required': g['required'],
                    'gap_points': g['required'] - g['candidate_score'],
                    'priority': 'Critical' if g['candidate_score'] < (g['required'] * 0.65) else 'High Priority',
                    'weight': g.get('weight', 1.0)
                })
        elif target_job:
            for req in target_job.required_skills:
                sk_map = candidate.get_skill_map() if hasattr(candidate, 'get_skill_map') else {}
                cand_sk = sk_map.get(req.skill_name.lower())
                c_score = cand_sk.effective_score() if cand_sk else 0
                if c_score < req.required_score:
                    holding_back.append({
                        'name': req.skill_name,
                        'current': c_score,
                        'required': req.required_score,
                        'gap_points': req.required_score - c_score,
                        'priority': 'High Priority',
                        'weight': req.weight
                    })

        # Next Best Action: based on priorities
        if target_job and gaps:
            priorities = self.calculate_skill_improvement_priorities(candidate, target_job)
            top_priority = priorities[0] if priorities else None
            if top_priority:
                next_best_action = {
                    'title': f"Complete {top_priority['skill_name']} Sprint",
                    'skill_name': top_priority['skill_name'],
                    'current_score': top_priority['current_score'],
                    'target_score': top_priority['target_score'],
                    'projected_boost': f"+{top_priority['delta']}%",
                    'delta_num': top_priority['delta'],
                    'time_estimate': '2-Week Sprint',
                    'reason': f"Closing your {top_priority['skill_name']} gap will boost your projected match from {role_fit_score}% to {role_fit_score + top_priority['delta']}%.",
                    'roadmap_url_job_id': target_job.id
                }
            else:
                next_best_action = {
                    'title': "Complete REST API Sprint",
                    'skill_name': "REST API",
                    'projected_boost': "+15%",
                    'delta_num': 15,
                    'time_estimate': '2-Week Sprint',
                    'reason': "Highest ROI upskilling target for your backend engineering path.",
                    'roadmap_url_job_id': target_job.id
                }
        else:
            next_best_action = {
                'title': "Verify Claimed Skills with AI Assessment",
                'skill_name': "Assessment",
                'projected_boost': "+10%",
                'delta_num': 10,
                'time_estimate': '15 Minutes',
                'reason': "Validating unverified skills increases recruiter confidence.",
                'roadmap_url_job_id': None
            }

        return {
            'overall_score': overall_score,
            'pillars': {
                'technical_skills': tech_score,
                'role_fit': role_fit_score,
                'assessment_confidence': conf_score,
                'skill_evidence': evidence_score
            },
            'strongest_skills': strongest,
            'skills_holding_back': holding_back,
            'next_best_action': next_best_action
        }


# Global singleton instance
matching_service = MatchingService()
